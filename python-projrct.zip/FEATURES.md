# Netlify Deployer - New Features

This document describes the new features added to the Netlify Deployer application.

## Automated Testing Integration

Run tests before deploying to ensure your site is working correctly.

- Supports popular testing frameworks (npm, yarn, react, vue, angular, etc.)
- Configure custom test commands
- Option to prevent deployment if tests fail
- Integrated with the deployment workflow

## Deployment Scheduling

Schedule deployments for specific times to automate your workflow.

- Set one-time or recurring deployments
- Configure build options for scheduled deployments
- View countdown timers for upcoming deployments
- Manage all scheduled deployments from one interface

## Project Templates

Save and reuse project configurations to streamline your workflow.

- Save current configuration as a template
- Load templates with one click
- Manage multiple templates
- Templates include all deployment settings

## Environment Variable Manager

Securely manage environment variables for your Netlify sites.

- Store variables securely with encryption
- Mark sensitive variables for special handling
- Import/export from .env files
- Generate Netlify CLI scripts for deployment

## Webhook Notifications

Send notifications to external services when deployment events occur.

- Configure custom webhook endpoints
- Trigger notifications for deployment events (start, success, failure)
- Trigger notifications for build events (start, success, failure)
- Add custom headers to webhook requests
- Manage multiple webhook configurations

## Coming Soon Features

The following features are currently in development:

### Analytics Dashboard
- View metrics and performance data for your sites
- Monitor traffic, build times, and deployment frequency
- Generate reports for stakeholders

### One-click Rollback
- Easily restore previous deployments
- View deployment history with rollback options
- Quick recovery from problematic deployments

### Multi-site Management
- Control multiple sites from one interface
- Batch operations across sites
- Compare configurations between sites

### A/B Testing Support
- Deploy different versions simultaneously
- Track performance of variants
- Automatically promote winning variants

### Deployment Preview Links
- Generate shareable preview URLs
- Collaborate with team members before going live
- Preview branches and pull requests 