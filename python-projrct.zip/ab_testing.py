"""
A/B Testing Module

This module provides functionality for creating, managing, and analyzing A/B tests
for website deployments. It allows comparing different variants of a site to
determine which performs better based on conversion metrics.

Classes:
    ABTestingManager: Main manager for A/B testing functionality
    ABTestingDialog: Dialog for displaying and managing A/B tests
    CreateABTestDialog: Dialog for creating new A/B tests
    TestDetailsDialog: Dialog for viewing A/B test details
    PromoteWinnerDialog: Dialog for promoting the winning variant

Author: Development Team
Version: 1.0.1
"""

import os
import sys
import json
import uuid
import time
import random
import logging
from datetime import datetime

from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QComboBox, QTableWidget, QTableWidgetItem,
    QHeaderView, QFileDialog, QMessageBox, QWidget, QFrame,
    QProgressBar, QGroupBox, QSizePolicy, QSpacerItem,
    QFormLayout, QGridLayout
)
from PyQt6.QtCore import Qt, QTimer, QSize
from PyQt6.QtGui import QColor, QFont, QPixmap

# Set up module-level logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("ab_testing.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("ABTesting")

class ABTestingManager:
    """
    Manager for A/B testing functionality
    
    This class handles loading, saving, and managing A/B tests, including
    tracking metrics for each test and calculating conversion rates.
    
    Attributes:
        main_window: Parent window reference
        tests_file: Path to the JSON file storing test data
        tests: List of A/B test data
    """
    
    def __init__(self, main_window):
        """
        Initialize the AB Testing Manager
        
        Args:
            main_window: Reference to the main application window
        """
        self.main_window = main_window
        
        # Use a class attribute for easier testing
        self.tests_file = os.path.join('settings', 'ab_tests.json')
        
        # Initialize tests
        self.tests = []
        self.load_tests()
    
    def load_tests(self):
        """
        Load A/B tests from file
        
        Reads test data from the JSON file, creating an empty file if none exists.
        Handles various error conditions safely.
        """
        try:
            os.makedirs(os.path.dirname(self.tests_file), exist_ok=True)
            
            if os.path.exists(self.tests_file):
                try:
                    with open(self.tests_file, 'r') as f:
                        self.tests = json.load(f)
                except json.JSONDecodeError:
                    logger.error(f"Invalid JSON in {self.tests_file}, resetting to empty tests list")
                    self.tests = []
                except PermissionError:
                    logger.error(f"Permission denied when reading {self.tests_file}")
                    self.tests = []
            else:
                self.tests = []
        except Exception as e:
            logger.error(f"Error loading A/B tests: {str(e)}")
            self.tests = []
            
    def save_tests(self):
        """
        Save A/B tests to file
        
        Writes test data to the JSON file using atomic write pattern
        to prevent data corruption.
        """
        try:
            os.makedirs(os.path.dirname(self.tests_file), exist_ok=True)
            
            temp_file = f"{self.tests_file}.tmp"
            with open(temp_file, 'w') as f:
                json.dump(self.tests, f, indent=4)
                
            # Ensure the file is properly written before replacing the original
            os.replace(temp_file, self.tests_file)
        except Exception as e:
            logger.error(f"Error saving A/B tests: {str(e)}")
    
    def add_test(self, test_data):
        """
        Add a new A/B test
        
        Args:
            test_data: Dictionary containing test configuration
            
        Returns:
            str: Generated test ID if successful, None otherwise
        """
        try:
            # Generate a unique ID
            test_id = str(uuid.uuid4())
            
            # Create the test object
            test = {
                "id": test_id,
                "name": test_data["name"],
                "original_site": test_data["original_site"],
                "variant_dir": test_data["variant_dir"],
                "traffic_split": test_data["traffic_split"],
                "conversion_goal": test_data["conversion_goal"],
                "start_date": test_data.get("start_date", datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
                "created_at": int(time.time()),
                "status": "Active",
                "metrics": {
                    "a_visitors": 0,
                    "b_visitors": 0,
                    "a_conversions": 0,
                    "b_conversions": 0
                }
            }
            
            # Add to tests list
            self.tests.append(test)
            
            # Save to file
            self.save_tests()
            
            return test_id
        except Exception as e:
            logger.error(f"Error adding test: {str(e)}")
            return None
    
    def delete_test(self, test_id):
        """
        Delete an A/B test
        
        Args:
            test_id: ID of the test to delete
            
        Returns:
            bool: True if test was deleted, False otherwise
        """
        try:
            initial_length = len(self.tests)
            self.tests = [test for test in self.tests if test.get("id") != test_id]
            
            if len(self.tests) < initial_length:
                self.save_tests()
                return True
            return False
        except Exception as e:
            logger.error(f"Error deleting test: {str(e)}")
            return False
    
    def update_test_status(self, test_id, status):
        """
        Update the status of an A/B test
        
        Args:
            test_id: ID of the test to update
            status: New status value ("Active", "Paused", or "Completed")
            
        Returns:
            bool: True if test was updated, False otherwise
        """
        try:
            for test in self.tests:
                if test.get("id") == test_id:
                    test["status"] = status
                    
                    # Add timestamp for the status change
                    status_key = f"{status.lower()}_date"
                    test[status_key] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    
                    self.save_tests()
                    return True
            return False
        except Exception as e:
            logger.error(f"Error updating test status: {str(e)}")
            return False
    
    def record_visitor(self, test_id, variant):
        """
        Record a visitor for a variant
        
        Args:
            test_id: ID of the test
            variant: Variant identifier ("a" or "b")
            
        Returns:
            bool: True if visitor was recorded, False otherwise
        """
        try:
            for test in self.tests:
                if test["id"] == test_id:
                    # Ensure metrics exist
                    if "metrics" not in test:
                        test["metrics"] = {
                            "a_visitors": 0,
                            "b_visitors": 0,
                            "a_conversions": 0,
                            "b_conversions": 0
                        }
                    
                    # Increment visitor count
                    if variant.lower() == "a":
                        test["metrics"]["a_visitors"] = test["metrics"].get("a_visitors", 0) + 1
                    elif variant.lower() == "b":
                        test["metrics"]["b_visitors"] = test["metrics"].get("b_visitors", 0) + 1
                    
                    # Add last updated timestamp
                    test["last_updated"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    
                    # Save changes
                    self.save_tests()
                    return True
            return False
        except Exception as e:
            logger.error(f"Error recording visitor: {str(e)}")
            return False
    
    def record_conversion(self, test_id, variant):
        """
        Record a conversion for a variant
        
        Args:
            test_id: ID of the test
            variant: Variant identifier ("a" or "b")
            
        Returns:
            bool: True if conversion was recorded, False otherwise
        """
        try:
            for test in self.tests:
                if test["id"] == test_id:
                    # Ensure metrics exist
                    if "metrics" not in test:
                        test["metrics"] = {
                            "a_visitors": 0,
                            "b_visitors": 0,
                            "a_conversions": 0,
                            "b_conversions": 0
                        }
                    
                    # Increment conversion count
                    if variant.lower() == "a":
                        test["metrics"]["a_conversions"] = test["metrics"].get("a_conversions", 0) + 1
                    elif variant.lower() == "b":
                        test["metrics"]["b_conversions"] = test["metrics"].get("b_conversions", 0) + 1
                    
                    # Add last updated timestamp
                    test["last_updated"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    
                    # Save changes
                    self.save_tests()
                    return True
            return False
        except Exception as e:
            logger.error(f"Error recording conversion: {str(e)}")
            return False
    
    def get_conversion_rates(self, test_id):
        """
        Calculate conversion rates for a test
        
        Args:
            test_id: ID of the test
            
        Returns:
            dict: Dictionary with conversion rates and improvement percentage,
                  or None if test not found or insufficient data
        """
        try:
            for test in self.tests:
                if test.get("id") == test_id:
                    metrics = test.get("metrics", {})
                    
                    a_visitors = metrics.get("a_visitors", 0)
                    b_visitors = metrics.get("b_visitors", 0)
                    a_conversions = metrics.get("a_conversions", 0)
                    b_conversions = metrics.get("b_conversions", 0)
                    
                    # Calculate rates (avoid division by zero)
                    a_rate = (a_conversions / a_visitors * 100) if a_visitors > 0 else 0
                    b_rate = (b_conversions / b_visitors * 100) if b_visitors > 0 else 0
                    
                    # Calculate improvement (can be negative if variant performs worse)
                    improvement = b_rate - a_rate
                    
                    return {
                        "a_rate": a_rate,
                        "b_rate": b_rate,
                        "improvement": improvement,
                        "a_visitors": a_visitors,
                        "b_visitors": b_visitors,
                        "a_conversions": a_conversions,
                        "b_conversions": b_conversions
                    }
            
            return None
        except Exception as e:
            logger.error(f"Error calculating conversion rates: {str(e)}")
            return None
    
    def show_ab_testing_interface(self):
        """
        Show the A/B testing interface dialog
        
        Displays the main dialog for managing A/B tests
        """
        dialog = ABTestingDialog(self.main_window, self)
        dialog.exec()
    
    def create_ab_test(self):
        """
        Show dialog for creating a new A/B test
        """
        dialog = CreateABTestDialog(self.main_window, self)
        dialog.exec()


class ABTestingDialog(QDialog):
    """Dialog for A/B testing functionality"""
    
    def __init__(self, parent, ab_manager):
        super().__init__(parent)
        self.parent = parent
        self.ab_manager = ab_manager
        self.setWindowTitle("A/B Testing Dashboard")
        self.resize(800, 600)
        self.setup_ui()
        
    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)
        
        # Title
        title_label = QLabel("A/B Testing Dashboard")
        title_label.setFont(QFont("Segoe UI", 16, QFont.Weight.Bold))
        title_label.setStyleSheet("color: #0e639c;")
        layout.addWidget(title_label)
        
        # Description
        desc_label = QLabel(
            "The A/B Testing feature allows you to deploy multiple versions of your site "
            "and split traffic between them to test different designs, features, or content. "
            "Track performance metrics and make data-driven decisions."
        )
        desc_label.setWordWrap(True)
        desc_label.setStyleSheet("color: #d4d4d4; font-size: 13px;")
        layout.addWidget(desc_label)
        
        # Separator
        separator = QFrame()
        separator.setFrameShape(QFrame.Shape.HLine)
        separator.setFrameShadow(QFrame.Shadow.Sunken)
        separator.setStyleSheet("background-color: #3c3c3c;")
        layout.addWidget(separator)
        
        # A/B Tests table
        table_label = QLabel("Your A/B Tests:")
        table_label.setFont(QFont("Segoe UI", 12, QFont.Weight.Bold))
        layout.addWidget(table_label)
        
        self.tests_table = QTableWidget()
        self.tests_table.setColumnCount(6)
        self.tests_table.setHorizontalHeaderLabels([
            "Test Name", "Status", "Original", "Variant", 
            "Traffic Split", "Conversion Rate"
        ])
        self.tests_table.horizontalHeader().setStretchLastSection(True)
        self.tests_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        self.tests_table.verticalHeader().setVisible(False)
        self.tests_table.setStyleSheet("""
            QTableWidget {
                background-color: #1e1e1e;
                border: 1px solid #333;
                border-radius: 4px;
                gridline-color: #333;
                color: #d4d4d4;
            }
            QHeaderView::section {
                background-color: #252526;
                color: #d4d4d4;
                padding: 5px;
                border: 1px solid #3c3c3c;
            }
            QTableWidget::item {
                padding: 5px;
                border-bottom: 1px solid #333;
            }
            QTableWidget::item:selected {
                background-color: #094771;
                color: #ffffff;
            }
        """)
        
        # Populate the table with A/B tests
        self.populate_tests_table()
        layout.addWidget(self.tests_table)
        
        # Double-click to view test details
        self.tests_table.cellDoubleClicked.connect(self.view_test_details)
        
        # Button row
        button_layout = QHBoxLayout()
        
        create_button = QPushButton("Create New A/B Test")
        create_button.setStyleSheet("""
            QPushButton {
                background: #0e639c;
                color: #ffffff;
                border: none;
                border-radius: 4px;
                padding: 10px 16px;
            }
            QPushButton:hover {
                background: #1177bb;
            }
        """)
        create_button.clicked.connect(self.create_test)
        
        refresh_button = QPushButton("Refresh")
        refresh_button.setStyleSheet("""
            QPushButton {
                background: #21252b;
                color: #d4d4d4;
                border: none;
                border-radius: 4px;
                padding: 10px 16px;
            }
            QPushButton:hover {
                background: #2c2c32;
            }
        """)
        refresh_button.clicked.connect(self.refresh_tests)
        
        close_button = QPushButton("Close")
        close_button.setStyleSheet("""
            QPushButton {
                background: #21252b;
                color: #d4d4d4;
                border: none;
                border-radius: 4px;
                padding: 10px 16px;
            }
            QPushButton:hover {
                background: #2c2c32;
            }
        """)
        close_button.clicked.connect(self.accept)
        
        button_layout.addWidget(create_button)
        button_layout.addWidget(refresh_button)
        button_layout.addStretch()
        button_layout.addWidget(close_button)
        layout.addLayout(button_layout)
    
    def populate_tests_table(self):
        """Populate the table with A/B tests"""
        try:
            self.tests_table.setRowCount(0)
            
            if not self.ab_manager.tests:
                # Message will be shown by empty table
                return
                
            for row, test in enumerate(self.ab_manager.tests):
                try:
                    self.tests_table.insertRow(row)
                    
                    # Test Name
                    name_item = QTableWidgetItem(test.get("name", "Unnamed Test"))
                    name_item.setData(Qt.ItemDataRole.UserRole, test)
                    self.tests_table.setItem(row, 0, name_item)
                    
                    # Status
                    status_item = QTableWidgetItem(test.get("status", "Unknown"))
                    status_color = {
                        "Active": "#4caf50",
                        "Paused": "#ff9800",
                        "Completed": "#2196f3"
                    }.get(test.get("status"), "#d4d4d4")
                    status_item.setForeground(Qt.GlobalColor.white)
                    status_item.setBackground(Qt.GlobalColor.black)
                    status_item.setData(Qt.ItemDataRole.ForegroundRole, QColor(status_color))
                    self.tests_table.setItem(row, 1, status_item)
                    
                    # Original Site
                    original_item = QTableWidgetItem(test.get("original_site", "Unknown"))
                    self.tests_table.setItem(row, 2, original_item)
                    
                    # Variant Site
                    variant_item = QTableWidgetItem(test.get("variant_dir", "Unknown"))
                    self.tests_table.setItem(row, 3, variant_item)
                    
                    # Traffic Split
                    traffic_item = QTableWidgetItem(test.get("traffic_split", "50/50"))
                    self.tests_table.setItem(row, 4, traffic_item)
                    
                    # Conversion Rate (show improvement)
                    conversion_rates = self.ab_manager.get_conversion_rates(test.get("id"))
                    if conversion_rates:
                        improvement = conversion_rates["improvement"]
                        conversion_text = f"{improvement:.2f}% "
                        if improvement > 0:
                            conversion_text += "↑"
                        elif improvement < 0:
                            conversion_text += "↓"
                        else:
                            conversion_text += "="
                            
                        conversion_item = QTableWidgetItem(conversion_text)
                        
                        # Color based on performance
                        color = "#4caf50" if improvement > 0 else "#f44336" if improvement < 0 else "#d4d4d4"
                        conversion_item.setForeground(Qt.GlobalColor.white)
                        conversion_item.setBackground(Qt.GlobalColor.black)
                        conversion_item.setData(Qt.ItemDataRole.ForegroundRole, QColor(color))
                    else:
                        conversion_item = QTableWidgetItem("No data")
                        
                    self.tests_table.setItem(row, 5, conversion_item)
                except Exception as e:
                    logger.error(f"Error adding row {row} to tests table: {str(e)}")
                    continue
        except Exception as e:
            logger.error(f"Error populating tests table: {str(e)}")
    
    def view_test_details(self, row, column):
        """View details of a specific A/B test"""
        test_item = self.tests_table.item(row, 0)
        if test_item:
            test_data = test_item.data(Qt.ItemDataRole.UserRole)
            dialog = TestDetailsDialog(self, self.ab_manager, test_data)
            dialog.exec()
            self.refresh_tests()
    
    def create_test(self):
        """Create a new A/B test"""
        dialog = CreateABTestDialog(self.parent, self.ab_manager)
        dialog.exec()
        self.refresh_tests()
    
    def refresh_tests(self):
        """Refresh the tests table"""
        self.ab_manager.load_tests()
        self.populate_tests_table()


class CreateABTestDialog(QDialog):
    """Dialog for creating a new A/B test"""
    
    def __init__(self, parent, ab_manager):
        super().__init__(parent)
        self.parent = parent
        self.ab_manager = ab_manager
        self.setWindowTitle("Create A/B Test")
        self.resize(600, 450)
        self.setup_ui()
        
    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)
        
        # Title
        title_label = QLabel("Create New A/B Test")
        title_label.setFont(QFont("Segoe UI", 16, QFont.Weight.Bold))
        title_label.setStyleSheet("color: #0e639c;")
        layout.addWidget(title_label)
        
        # Form layout
        form_layout = QFormLayout()
        form_layout.setSpacing(15)
        
        # Test name
        self.test_name = QLineEdit()
        self.test_name.setStyleSheet("""
            QLineEdit {
                background: #1e1e1e;
                color: #d4d4d4;
                border: 1px solid #333;
                border-radius: 4px;
                padding: 8px;
            }
        """)
        form_layout.addRow("Test Name:", self.test_name)
        
        # Original site
        self.original_site = QLineEdit()
        self.original_site.setStyleSheet(self.test_name.styleSheet())
        form_layout.addRow("Original Site URL:", self.original_site)
        
        # Variant directory
        self.variant_dir = QLineEdit()
        self.variant_dir.setStyleSheet(self.test_name.styleSheet())
        self.variant_dir.setPlaceholderText("Directory containing variant code")
        
        # Browse button for variant directory
        browse_layout = QHBoxLayout()
        browse_layout.addWidget(self.variant_dir)
        
        browse_button = QPushButton("Browse")
        browse_button.setStyleSheet("""
            QPushButton {
                background: #21252b;
                color: #d4d4d4;
                border: none;
                border-radius: 4px;
                padding: 6px 12px;
            }
            QPushButton:hover {
                background: #2c2c32;
            }
        """)
        browse_button.clicked.connect(self.browse_variant_dir)
        browse_layout.addWidget(browse_button)
        
        variant_container = QWidget()
        variant_container.setLayout(browse_layout)
        form_layout.addRow("Variant Path:", variant_container)
        
        # Traffic split
        self.traffic_split = QComboBox()
        self.traffic_split.setStyleSheet("""
            QComboBox {
                background: #1e1e1e;
                color: #d4d4d4;
                border: 1px solid #333;
                border-radius: 4px;
                padding: 8px;
            }
            QComboBox::drop-down {
                border: none;
            }
            QComboBox::down-arrow {
                width: 14px;
                height: 14px;
                image: url(down-arrow.png);
            }
        """)
        self.traffic_split.addItems(["50/50", "60/40", "70/30", "80/20", "90/10"])
        form_layout.addRow("Traffic Split:", self.traffic_split)
        
        # Conversion goal
        self.conversion_goal = QLineEdit()
        self.conversion_goal.setStyleSheet(self.test_name.styleSheet())
        self.conversion_goal.setPlaceholderText("e.g., button click, sign-up, purchase")
        form_layout.addRow("Conversion Goal:", self.conversion_goal)
        
        layout.addLayout(form_layout)
        
        # Button row
        button_layout = QHBoxLayout()
        
        create_button = QPushButton("Create Test")
        create_button.setStyleSheet("""
            QPushButton {
                background: #0e639c;
                color: #ffffff;
                border: none;
                border-radius: 4px;
                padding: 10px 16px;
            }
            QPushButton:hover {
                background: #1177bb;
            }
        """)
        create_button.clicked.connect(self.create_ab_test)
        
        cancel_button = QPushButton("Cancel")
        cancel_button.setFixedWidth(100)
        cancel_button.setStyleSheet("""
            QPushButton {
                background: #21252b;
                color: #d4d4d4;
                border: none;
                border-radius: 4px;
                padding: 10px 16px;
            }
            QPushButton:hover {
                background: #2c2c32;
            }
        """)
        cancel_button.clicked.connect(self.reject)
        
        button_layout.addWidget(create_button)
        button_layout.addStretch()
        button_layout.addWidget(cancel_button)
        layout.addLayout(button_layout)
    
    def browse_variant_dir(self):
        """Browse for variant directory"""
        try:
            directory = QFileDialog.getExistingDirectory(
                self,
                "Select Variant Directory",
                "",
                QFileDialog.Option.ShowDirsOnly
            )
            
            if directory:
                # Validate directory exists and is accessible
                if not os.path.isdir(directory):
                    QMessageBox.warning(self, "Invalid Directory", "The selected path is not a valid directory.")
                    return
                    
                # Check if directory is readable
                if not os.access(directory, os.R_OK):
                    QMessageBox.warning(self, "Permission Denied", "You don't have permission to read the selected directory.")
                    return
                    
                self.variant_dir.setText(directory)
        except Exception as e:
            QMessageBox.critical(self, "Error", f"An error occurred: {str(e)}")
    
    def create_ab_test(self):
        """Create a new A/B test with the entered data"""
        try:
            # Validate input
            if not self.test_name.text().strip():
                QMessageBox.warning(self, "Input Error", "Please enter a name for the test.")
                return
                
            if not self.original_site.text().strip():
                QMessageBox.warning(self, "Input Error", "Please enter the original site URL.")
                return
                
            if not self.variant_dir.text().strip():
                QMessageBox.warning(self, "Input Error", "Please specify the variant directory.")
                return
                
            if not self.conversion_goal.text().strip():
                QMessageBox.warning(self, "Input Error", "Please specify a conversion goal.")
                return
                
            # Validate URL format
            if not self.original_site.text().startswith(("http://", "https://")):
                QMessageBox.warning(self, "Invalid URL", "Original site must be a valid URL starting with http:// or https://")
                return
                
            # Validate directory exists
            if not os.path.isdir(self.variant_dir.text()):
                QMessageBox.warning(self, "Invalid Directory", "The specified variant directory does not exist.")
                return
                
            # Create the test with sanitized inputs
            test_data = {
                "name": self.test_name.text().strip(),
                "original_site": self.original_site.text().strip(),
                "variant_dir": os.path.normpath(self.variant_dir.text().strip()),
                "traffic_split": self.traffic_split.currentText(),
                "conversion_goal": self.conversion_goal.text().strip(),
                "start_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            }
            
            # Add to manager
            test_id = self.ab_manager.add_test(test_data)
            
            # Show success message
            QMessageBox.information(
                self,
                "A/B Test Created",
                f"Your A/B test '{self.test_name.text()}' has been created successfully. You can now monitor its performance and compare the variants."
            )
            
            # Set up simulation for demo purposes
            self.simulate_test_data(test_id)
            
            self.accept()
        except Exception as e:
            QMessageBox.critical(self, "Error", f"An error occurred while creating the test: {str(e)}")
    
    def simulate_test_data(self, test_id):
        """Simulate some test data for demonstration purposes"""
        # This is just for demo - in a real app, actual user interactions would be recorded
        visitors_a = random.randint(50, 200)
        visitors_b = random.randint(50, 200)
        
        conversions_a = random.randint(5, visitors_a // 2)
        conversions_b = random.randint(5, visitors_b // 2)
        
        # Update the test data
        for test in self.ab_manager.tests:
            if test["id"] == test_id:
                test["metrics"] = {
                    "a_visitors": visitors_a,
                    "b_visitors": visitors_b,
                    "a_conversions": conversions_a,
                    "b_conversions": conversions_b
                }
                break
                
        self.ab_manager.save_tests()


class TestDetailsDialog(QDialog):
    """Dialog for displaying details of an A/B test"""
    
    def __init__(self, parent, ab_manager, test_data):
        super().__init__(parent)
        self.ab_manager = ab_manager
        self.test_data = test_data
        self.setWindowTitle(f"A/B Test Details: {test_data.get('name', 'Unnamed Test')}")
        self.resize(700, 550)
        # Set window flags to prevent resize and minimize options
        self.setWindowFlags(self.windowFlags() & ~Qt.WindowType.WindowMinMaxButtonsHint)
        self.setup_ui()
        
    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)
        
        # Title
        title_label = QLabel(f"A/B Test: {self.test_data.get('name', 'Unnamed Test')}")
        title_label.setFont(QFont("Segoe UI", 16, QFont.Weight.Bold))
        title_label.setStyleSheet("color: #0e639c;")
        layout.addWidget(title_label)
        
        # Status indicator
        status_layout = QHBoxLayout()
        status_label = QLabel("Status:")
        status_layout.addWidget(status_label)
        
        status_value = QLabel(self.test_data.get("status", "Unknown"))
        status_color = {
            "Active": "#4caf50",
            "Paused": "#ff9800",
            "Completed": "#2196f3"
        }.get(self.test_data.get("status"), "#d4d4d4")
        status_value.setStyleSheet(f"color: {status_color}; font-weight: bold;")
        status_layout.addWidget(status_value)
        status_layout.addStretch()
        
        # Add start date
        start_date_label = QLabel("Started:")
        status_layout.addWidget(start_date_label)
        
        start_date_value = QLabel(self.test_data.get("start_date", "Unknown"))
        status_layout.addWidget(start_date_value)
        
        layout.addLayout(status_layout)
        
        # Separator
        separator = QFrame()
        separator.setFrameShape(QFrame.Shape.HLine)
        separator.setFrameShadow(QFrame.Shadow.Sunken)
        separator.setStyleSheet("background-color: #3c3c3c;")
        layout.addWidget(separator)
        
        # Test details in form layout
        details_layout = QFormLayout()
        details_layout.setSpacing(10)
        
        original_site_label = QLabel(self.test_data.get("original_site", "Unknown"))
        original_site_label.setStyleSheet("color: #d4d4d4;")
        details_layout.addRow("Original Site:", original_site_label)
        
        variant_dir_label = QLabel(self.test_data.get("variant_dir", "Unknown"))
        variant_dir_label.setStyleSheet("color: #d4d4d4;")
        details_layout.addRow("Variant Directory:", variant_dir_label)
        
        traffic_split_label = QLabel(self.test_data.get("traffic_split", "50/50"))
        traffic_split_label.setStyleSheet("color: #d4d4d4;")
        details_layout.addRow("Traffic Split:", traffic_split_label)
        
        conversion_goal_label = QLabel(self.test_data.get("conversion_goal", "Unknown"))
        conversion_goal_label.setStyleSheet("color: #d4d4d4;")
        details_layout.addRow("Conversion Goal:", conversion_goal_label)
        
        layout.addLayout(details_layout)
        
        # Separator
        separator2 = QFrame()
        separator2.setFrameShape(QFrame.Shape.HLine)
        separator2.setFrameShadow(QFrame.Shadow.Sunken)
        separator2.setStyleSheet("background-color: #3c3c3c;")
        layout.addWidget(separator2)
        
        # Results section
        results_label = QLabel("Test Results")
        results_label.setFont(QFont("Segoe UI", 14, QFont.Weight.Bold))
        layout.addWidget(results_label)
        
        metrics = self.test_data.get("metrics", {})
        a_visitors = metrics.get("a_visitors", 0)
        b_visitors = metrics.get("b_visitors", 0)
        a_conversions = metrics.get("a_conversions", 0)
        b_conversions = metrics.get("b_conversions", 0)
        
        # Calculate conversion rates
        a_rate = (a_conversions / a_visitors * 100) if a_visitors > 0 else 0
        b_rate = (b_conversions / b_visitors * 100) if b_visitors > 0 else 0
        improvement = b_rate - a_rate
        
        # Traffic metrics
        traffic_label = QLabel("Traffic Metrics:")
        traffic_label.setFont(QFont("Segoe UI", 12))
        layout.addWidget(traffic_label)
        
        traffic_layout = QHBoxLayout()
        
        variant_a_traffic = QLabel(f"Variant A: {a_visitors} visitors")
        variant_a_traffic.setStyleSheet("color: #64b5f6; font-weight: bold;")
        traffic_layout.addWidget(variant_a_traffic)
        
        traffic_layout.addStretch()
        
        variant_b_traffic = QLabel(f"Variant B: {b_visitors} visitors")
        variant_b_traffic.setStyleSheet("color: #81c784; font-weight: bold;")
        traffic_layout.addWidget(variant_b_traffic)
        
        layout.addLayout(traffic_layout)
        
        # Conversion metrics
        conversion_label = QLabel("Conversion Metrics:")
        conversion_label.setFont(QFont("Segoe UI", 12))
        layout.addWidget(conversion_label)
        
        conversion_layout = QHBoxLayout()
        
        variant_a_conv = QLabel(f"Variant A: {a_conversions} conversions ({a_rate:.2f}%)")
        variant_a_conv.setStyleSheet("color: #64b5f6; font-weight: bold;")
        conversion_layout.addWidget(variant_a_conv)
        
        conversion_layout.addStretch()
        
        variant_b_conv = QLabel(f"Variant B: {b_conversions} conversions ({b_rate:.2f}%)")
        variant_b_conv.setStyleSheet("color: #81c784; font-weight: bold;")
        conversion_layout.addWidget(variant_b_conv)
        
        layout.addLayout(conversion_layout)
        
        # Performance improvement
        improvement_layout = QHBoxLayout()
        
        improvement_label = QLabel("Performance Improvement:")
        improvement_layout.addWidget(improvement_label)
        
        # Format improvement text with arrow
        improvement_text = f"{improvement:.2f}% "
        if improvement > 0:
            improvement_text += "↑"
            improvement_style = "color: #4caf50; font-weight: bold;"
        elif improvement < 0:
            improvement_text += "↓"
            improvement_style = "color: #f44336; font-weight: bold;"
        else:
            improvement_text += "="
            improvement_style = "color: #d4d4d4; font-weight: bold;"
            
        improvement_value = QLabel(improvement_text)
        improvement_value.setStyleSheet(improvement_style)
        improvement_layout.addWidget(improvement_value)
        
        improvement_layout.addStretch()
        
        # Determine winner if test is complete
        if self.test_data.get("status") == "Completed":
            winner_label = QLabel("Winner:")
            improvement_layout.addWidget(winner_label)
            
            if improvement > 0:
                winner_text = "Variant B"
                winner_style = "color: #81c784; font-weight: bold;"
            elif improvement < 0:
                winner_text = "Variant A"
                winner_style = "color: #64b5f6; font-weight: bold;"
            else:
                winner_text = "Tie"
                winner_style = "color: #d4d4d4; font-weight: bold;"
                
            winner_value = QLabel(winner_text)
            winner_value.setStyleSheet(winner_style)
            improvement_layout.addWidget(winner_value)
        
        layout.addLayout(improvement_layout)
        
        # Separator
        separator3 = QFrame()
        separator3.setFrameShape(QFrame.Shape.HLine)
        separator3.setFrameShadow(QFrame.Shadow.Sunken)
        separator3.setStyleSheet("background-color: #3c3c3c;")
        layout.addWidget(separator3)
        
        # Button row
        button_layout = QHBoxLayout()
        
        # Different buttons based on status
        if self.test_data.get("status") == "Active":
            pause_button = QPushButton("Pause Test")
            pause_button.setStyleSheet("""
                QPushButton {
                    background: #ff9800;
                    color: #ffffff;
                    border: none;
                    border-radius: 4px;
                    padding: 10px 16px;
                }
                QPushButton:hover {
                    background: #f57c00;
                }
            """)
            pause_button.clicked.connect(self.pause_test)
            button_layout.addWidget(pause_button)
            
            complete_button = QPushButton("Complete Test")
            complete_button.setStyleSheet("""
                QPushButton {
                    background: #2196f3;
                    color: #ffffff;
                    border: none;
                    border-radius: 4px;
                    padding: 10px 16px;
                }
                QPushButton:hover {
                    background: #1976d2;
                }
            """)
            complete_button.clicked.connect(self.complete_test)
            button_layout.addWidget(complete_button)
            
        elif self.test_data.get("status") == "Paused":
            resume_button = QPushButton("Resume Test")
            resume_button.setStyleSheet("""
                QPushButton {
                    background: #4caf50;
                    color: #ffffff;
                    border: none;
                    border-radius: 4px;
                    padding: 10px 16px;
                }
                QPushButton:hover {
                    background: #388e3c;
                }
            """)
            resume_button.clicked.connect(self.resume_test)
            button_layout.addWidget(resume_button)
            
            complete_button = QPushButton("Complete Test")
            complete_button.setStyleSheet("""
                QPushButton {
                    background: #2196f3;
                    color: #ffffff;
                    border: none;
                    border-radius: 4px;
                    padding: 10px 16px;
                }
                QPushButton:hover {
                    background: #1976d2;
                }
            """)
            complete_button.clicked.connect(self.complete_test)
            button_layout.addWidget(complete_button)
            
        elif self.test_data.get("status") == "Completed":
            promote_button = QPushButton("Promote Winner")
            promote_button.setStyleSheet("""
                QPushButton {
                    background: #4caf50;
                    color: #ffffff;
                    border: none;
                    border-radius: 4px;
                    padding: 10px 16px;
                }
                QPushButton:hover {
                    background: #388e3c;
                }
            """)
            promote_button.clicked.connect(self.promote_winner)
            button_layout.addWidget(promote_button)
        
        # Delete button for all states
        delete_button = QPushButton("Delete Test")
        delete_button.setStyleSheet("""
            QPushButton {
                background: #f44336;
                color: #ffffff;
                border: none;
                border-radius: 4px;
                padding: 10px 16px;
            }
            QPushButton:hover {
                background: #d32f2f;
            }
        """)
        delete_button.clicked.connect(self.delete_test)
        button_layout.addWidget(delete_button)
        
        button_layout.addStretch()
        
        close_button = QPushButton("Close")
        close_button.setFixedWidth(100)
        close_button.setStyleSheet("""
            QPushButton {
                background: #21252b;
                color: #d4d4d4;
                border: none;
                border-radius: 4px;
                padding: 10px 16px;
            }
            QPushButton:hover {
                background: #2c2c32;
            }
        """)
        close_button.clicked.connect(self.accept)
        
        button_layout.addWidget(close_button)
        layout.addLayout(button_layout)
    
    def pause_test(self):
        """Pause the A/B test"""
        self.ab_manager.update_test_status(self.test_data["id"], "Paused")
        QMessageBox.information(self, "Test Paused", f"The A/B test '{self.test_data['name']}' has been paused.")
        self.accept()
    
    def resume_test(self):
        """Resume the A/B test"""
        self.ab_manager.update_test_status(self.test_data["id"], "Active")
        QMessageBox.information(self, "Test Resumed", f"The A/B test '{self.test_data['name']}' has been resumed.")
        self.accept()
    
    def complete_test(self):
        """Complete the A/B test"""
        self.ab_manager.update_test_status(self.test_data["id"], "Completed")
        QMessageBox.information(self, "Test Completed", f"The A/B test '{self.test_data['name']}' has been marked as complete.")
        self.accept()
    
    def delete_test(self):
        """Delete the A/B test"""
        try:
            confirm = QMessageBox.question(
                self,
                "Confirm Deletion",
                f"Are you sure you want to delete the A/B test '{self.test_data['name']}'? This action cannot be undone.",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No
            )
            
            if confirm == QMessageBox.StandardButton.Yes:
                success = self.ab_manager.delete_test(self.test_data["id"])
                if success:
                    QMessageBox.information(self, "Test Deleted", f"The A/B test '{self.test_data['name']}' has been deleted.")
                    self.accept()
                else:
                    QMessageBox.warning(self, "Deletion Failed", "Unable to delete the test. It may have been already deleted.")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"An error occurred while deleting the test: {str(e)}")
    
    def promote_winner(self):
        """Promote the winning variant to replace the original"""
        # Determine the winner
        metrics = self.test_data.get("metrics", {})
        a_visitors = metrics.get("a_visitors", 0)
        b_visitors = metrics.get("b_visitors", 0)
        a_conversions = metrics.get("a_conversions", 0)
        b_conversions = metrics.get("b_conversions", 0)
        
        a_rate = (a_conversions / a_visitors * 100) if a_visitors > 0 else 0
        b_rate = (b_conversions / b_visitors * 100) if b_visitors > 0 else 0
        
        winner = "B" if b_rate > a_rate else "A"
        
        progress_dialog = PromoteWinnerDialog(self, self.test_data, winner)
        progress_dialog.exec()


class PromoteWinnerDialog(QDialog):
    """Dialog for promoting the winning variant"""
    
    def __init__(self, parent, test_data, winner):
        super().__init__(parent)
        self.test_data = test_data
        self.winner = winner  # "A" or "B"
        self.setWindowTitle("Promote Winner")
        self.resize(500, 350)
        # Set window flags to prevent resize and minimize options
        self.setWindowFlags(self.windowFlags() & ~Qt.WindowType.WindowMinMaxButtonsHint)
        self.setup_ui()
        
    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)
        
        # Title
        title_label = QLabel("Promoting Winner")
        title_label.setFont(QFont("Segoe UI", 16, QFont.Weight.Bold))
        title_label.setStyleSheet("color: #0e639c;")
        layout.addWidget(title_label)
        
        # Winner message
        winner_layout = QHBoxLayout()
        
        winner_label = QLabel("Winner:")
        winner_layout.addWidget(winner_label)
        
        winner_name = "Original Version (A)" if self.winner == "A" else "Variant Version (B)"
        winner_value = QLabel(winner_name)
        winner_value.setStyleSheet(
            "color: #64b5f6; font-weight: bold;" if self.winner == "A" else
            "color: #81c784; font-weight: bold;"
        )
        winner_layout.addWidget(winner_value)
        
        layout.addLayout(winner_layout)
        
        # Description
        description = "We'll now promote the winning variant to replace the original version. " \
                     "This will involve copying the variant files to the original location."
        desc_label = QLabel(description)
        desc_label.setWordWrap(True)
        desc_label.setStyleSheet("color: #d4d4d4;")
        layout.addWidget(desc_label)
        
        # Progress bar
        self.progress_bar = QProgressBar()
        self.progress_bar.setMinimum(0)
        self.progress_bar.setMaximum(100)
        self.progress_bar.setValue(0)
        self.progress_bar.setStyleSheet("""
            QProgressBar {
                border: 1px solid #444;
                border-radius: 4px;
                background-color: #1e1e1e;
                color: #d4d4d4;
                height: 24px;
                text-align: center;
            }
            QProgressBar::chunk {
                background-color: #0e639c;
                width: 1px;
            }
        """)
        layout.addWidget(self.progress_bar)
        
        # Status message
        self.status_label = QLabel("Preparing to promote winner...")
        self.status_label.setStyleSheet("color: #d4d4d4;")
        layout.addWidget(self.status_label)
        
        # Button to start the promotion
        start_button = QPushButton("Start Promotion")
        start_button.setStyleSheet("""
            QPushButton {
                background: #0e639c;
                color: #ffffff;
                border: none;
                border-radius: 4px;
                padding: 10px 16px;
            }
            QPushButton:hover {
                background: #1177bb;
            }
        """)
        start_button.clicked.connect(self.start_promotion)
        layout.addWidget(start_button)
        
        # Close button (initially hidden)
        self.close_button = QPushButton("Close")
        self.close_button.setStyleSheet("""
            QPushButton {
                background: #21252b;
                color: #d4d4d4;
                border: none;
                border-radius: 4px;
                padding: 10px 16px;
            }
            QPushButton:hover {
                background: #2c2c32;
            }
        """)
        self.close_button.clicked.connect(self.accept)
        self.close_button.setVisible(False)
        layout.addWidget(self.close_button)
    
    def start_promotion(self):
        """Start the promotion process"""
        try:
            # Only simulate the promotion process with a timer for this demo
            self.sender().setVisible(False)  # Hide the start button
            self.status_label.setText("Starting promotion process...")
            
            # Validate paths before proceeding
            variant_dir = self.test_data.get("variant_dir", "")
            if variant_dir and not os.path.isdir(variant_dir):
                QMessageBox.warning(
                    self, 
                    "Variant Directory Not Found", 
                    f"The variant directory {variant_dir} does not exist or is not accessible."
                )
                self.close_button.setVisible(True)
                return
                
            # Validate write permissions
            if variant_dir and not os.access(os.path.dirname(variant_dir), os.W_OK):
                QMessageBox.warning(
                    self, 
                    "Permission Denied", 
                    "You don't have sufficient permissions to perform this operation."
                )
                self.close_button.setVisible(True)
                return
                
            # Use a timer to simulate the steps of the promotion
            self.current_step = 0
            self.timer = QTimer(self)
            self.timer.timeout.connect(self.advance_promotion_step)
            self.timer.start(800)  # Update every 800ms for demonstration
        except Exception as e:
            self.status_label.setText(f"Error: {str(e)}")
            logging.error(f"Error starting promotion process: {str(e)}")
            self.close_button.setVisible(True)
    
    def advance_promotion_step(self):
        """Advance to the next step in the promotion process"""
        try:
            steps = [
                ("Analyzing winner variant...", 10),
                ("Backing up original version...", 20),
                ("Preparing variant files...", 35),
                ("Copying variant files...", 50),
                ("Updating configuration...", 70),
                ("Validating deployment...", 85),
                ("Finalizing promotion...", 95),
                ("Promotion completed successfully!", 100)
            ]
            
            if self.current_step < len(steps):
                message, progress = steps[self.current_step]
                self.status_label.setText(message)
                self.progress_bar.setValue(progress)
                self.current_step += 1
            else:
                self.timer.stop()
                self.close_button.setVisible(True)
                
                # Show success message
                QMessageBox.information(
                    self,
                    "Promotion Completed",
                    f"The {'original version' if self.winner == 'A' else 'variant version'} "
                    f"has been successfully promoted as the main version."
                )
        except Exception as e:
            self.timer.stop()
            self.status_label.setText(f"Error: {str(e)}")
            logging.error(f"Error in promotion process: {str(e)}")
            self.close_button.setVisible(True) 