#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Analytics Dashboard for Netlify Deployer
Provides visualization and insights for Netlify site analytics
"""

import os
import json
import requests
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple

from PyQt6.QtCore import Qt, pyqtSignal, QThread
from PyQt6.QtGui import QIcon, QPixmap
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, 
    QComboBox, QTabWidget, QWidget, QFormLayout, QMessageBox,
    QTableWidget, QTableWidgetItem, QHeaderView, QGroupBox,
    QSplitter, QApplication, QProgressBar, QDateEdit, QInputDialog, QLineEdit
)

try:
    import matplotlib
    matplotlib.use('QtAgg')  # Use the generic QtAgg backend which will auto-detect Qt version
    from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
    from matplotlib.figure import Figure
    MATPLOTLIB_AVAILABLE = True
except ImportError:
    MATPLOTLIB_AVAILABLE = False
    # Define a placeholder FigureCanvas class to avoid NameError
    class FigureCanvas:
        """Placeholder for FigureCanvas when matplotlib is not available"""
        def __init__(self, *args, **kwargs):
            pass

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("analytics_dashboard")

class AnalyticsClient:
    """Client for fetching analytics data from Netlify API"""
    
    BASE_URL = "https://api.netlify.com/api/v1"
    
    def __init__(self, token: str):
        self.token = token
        self.headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }
    
    def get_site_analytics(self, site_id: str) -> Dict[str, Any]:
        """Get analytics for a site"""
        response = requests.get(f"{self.BASE_URL}/sites/{site_id}/analytics", headers=self.headers)
        
        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"Failed to fetch analytics: {response.status_code} - {response.text}")
    
    def get_site_analytics_by_period(self, site_id: str, from_date: str, to_date: str) -> Dict[str, Any]:
        """Get analytics for a site within a specific time period"""
        params = {
            "from": from_date,
            "to": to_date
        }
        
        response = requests.get(
            f"{self.BASE_URL}/sites/{site_id}/analytics", 
            headers=self.headers,
            params=params
        )
        
        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"Failed to fetch analytics: {response.status_code} - {response.text}")
    
    def get_site_traffic_sources(self, site_id: str) -> Dict[str, Any]:
        """Get traffic sources for a site"""
        try:
            response = requests.get(
                f"{self.BASE_URL}/sites/{site_id}/analytics/sources", 
                headers=self.headers
            )
            
            if response.status_code == 200:
                return response.json()
            elif response.status_code == 404:
                logger.warning(f"Traffic sources data not available for site {site_id}")
                # Return empty data structure instead of raising an exception
                return {"sources": []}
            else:
                error_msg = f"Failed to fetch traffic sources: {response.status_code}"
                try:
                    error_data = response.json()
                    if 'message' in error_data:
                        error_msg += f" - {error_data['message']}"
                    else:
                        error_msg += f" - {response.text}"
                except:
                    error_msg += f" - {response.text}"
                
                logger.error(error_msg)
                raise Exception(error_msg)
        except requests.RequestException as e:
            logger.error(f"Network error fetching traffic sources: {str(e)}")
            raise Exception(f"Network error fetching traffic sources: {str(e)}")
    
    def get_site_browsers(self, site_id: str) -> Dict[str, Any]:
        """Get browser usage for a site"""
        try:
            response = requests.get(
                f"{self.BASE_URL}/sites/{site_id}/analytics/browsers", 
                headers=self.headers
            )
            
            if response.status_code == 200:
                return response.json()
            elif response.status_code == 404:
                logger.warning(f"Browser data not available for site {site_id}")
                # Return empty data structure instead of raising an exception
                return {"browsers": []}
            else:
                error_msg = f"Failed to fetch browser data: {response.status_code}"
                try:
                    error_data = response.json()
                    if 'message' in error_data:
                        error_msg += f" - {error_data['message']}"
                    else:
                        error_msg += f" - {response.text}"
                except:
                    error_msg += f" - {response.text}"
                
                logger.error(error_msg)
                raise Exception(error_msg)
        except requests.RequestException as e:
            logger.error(f"Network error fetching browser data: {str(e)}")
            raise Exception(f"Network error fetching browser data: {str(e)}")
    
    def get_site_locations(self, site_id: str) -> Dict[str, Any]:
        """Get visitor locations for a site"""
        response = requests.get(
            f"{self.BASE_URL}/sites/{site_id}/analytics/locations", 
            headers=self.headers
        )
        
        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"Failed to fetch location data: {response.status_code} - {response.text}")


class FetchAnalyticsWorker(QThread):
    """Worker thread for fetching analytics data"""
    
    analytics_fetched = pyqtSignal(dict)
    error = pyqtSignal(str)
    
    def __init__(self, token: str, site_id: str, from_date: Optional[str] = None, to_date: Optional[str] = None):
        super().__init__()
        self.token = token
        self.site_id = site_id
        self.from_date = from_date
        self.to_date = to_date
    
    def run(self):
        """Run the worker thread to fetch analytics data"""
        try:
            client = AnalyticsClient(self.token)
            
            if self.from_date and self.to_date:
                analytics = client.get_site_analytics_by_period(
                    self.site_id, self.from_date, self.to_date
                )
            else:
                analytics = client.get_site_analytics(self.site_id)
                
            self.analytics_fetched.emit(analytics)
        except Exception as e:
            self.error.emit(str(e))


class FetchTrafficSourcesWorker(QThread):
    """Worker thread for fetching traffic sources data"""
    
    sources_fetched = pyqtSignal(dict)
    error = pyqtSignal(str)
    
    def __init__(self, token: str, site_id: str):
        super().__init__()
        self.token = token
        self.site_id = site_id
    
    def run(self):
        """Run the worker thread to fetch traffic sources data"""
        try:
            client = AnalyticsClient(self.token)
            sources = client.get_site_traffic_sources(self.site_id)
            self.sources_fetched.emit(sources)
        except Exception as e:
            logger.error(f"Error fetching traffic sources: {str(e)}")
            self.error.emit(str(e))


class AnalyticsChart(FigureCanvas):
    """Canvas for displaying analytics charts"""
    
    def __init__(self, width=5, height=4, dpi=100):
        self.fig = Figure(figsize=(width, height), dpi=dpi)
        self.axes = self.fig.add_subplot(111)
        super().__init__(self.fig)
        self.fig.tight_layout()
    
    def plot_bar_chart(self, labels, values, title="", xlabel="", ylabel=""):
        """Plot a bar chart with the given data"""
        self.axes.clear()
        self.axes.bar(labels, values)
        self.axes.set_title(title)
        self.axes.set_xlabel(xlabel)
        self.axes.set_ylabel(ylabel)
        
        # Rotate x-axis labels if there are many
        if len(labels) > 5:
            self.axes.set_xticklabels(labels, rotation=45, ha='right')
        
        self.fig.tight_layout()
        self.draw()
    
    def plot_pie_chart(self, labels, values, title=""):
        """Plot a pie chart with the given data"""
        self.axes.clear()
        self.axes.pie(values, labels=labels, autopct='%1.1f%%')
        self.axes.set_title(title)
        self.axes.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle
        self.fig.tight_layout()
        self.draw()


class AnalyticsDashboard:
    """Analytics Dashboard for Netlify sites"""
    
    def __init__(self, main_window):
        self.main_window = main_window
        # Get the API token directly from the main window settings
        self.api_token = ""
        
        if hasattr(main_window, 'persistent_token'):
            self.api_token = main_window.persistent_token
            logger.info("Got API token from main_window.persistent_token")
        elif hasattr(main_window, 'settings') and 'persistent_token' in main_window.settings:
            self.api_token = main_window.settings['persistent_token']
            logger.info("Got API token from main_window.settings['persistent_token']")
        
        # Log token status (masked for security)
        if self.api_token:
            masked_token = self.api_token[:4] + "*" * (len(self.api_token) - 8) + self.api_token[-4:] if len(self.api_token) > 8 else "****"
            logger.info(f"API token initialized: {masked_token}")
        else:
            logger.warning("No API token found in main window")
    
    def show_dashboard(self, site_id=None, site_name=None):
        """Show the analytics dashboard dialog"""
        # Refresh the token right before showing the dashboard
        if hasattr(self.main_window, 'persistent_token'):
            self.api_token = self.main_window.persistent_token
            logger.info("Refreshed API token from main_window.persistent_token")
        elif hasattr(self.main_window, 'settings') and 'persistent_token' in self.main_window.settings:
            self.api_token = self.main_window.settings['persistent_token']
            logger.info("Refreshed API token from main_window.settings['persistent_token']")
            
        # Log token status again
        if self.api_token:
            masked_token = self.api_token[:4] + "*" * (len(self.api_token) - 8) + self.api_token[-4:] if len(self.api_token) > 8 else "****"
            logger.info(f"API token before showing dashboard: {masked_token}")
        else:
            logger.warning("No API token available when showing dashboard")
            
        dialog = AnalyticsDashboardDialog(self.main_window, self.api_token, site_id, site_name)
        dialog.exec()


class AnalyticsDashboardDialog(QDialog):
    """Dialog for displaying analytics dashboard"""
    
    def __init__(self, parent=None, api_token="", site_id=None, site_name=None):
        super().__init__(parent)
        self.api_token = api_token
        self.site_id = site_id
        self.site_name = site_name
        self.parent = parent
        
        # Try to get token from parent if not provided
        if not self.api_token and parent:
            if hasattr(parent, 'persistent_token'):
                self.api_token = parent.persistent_token
                logger.info("Got token from parent.persistent_token in dialog init")
            elif hasattr(parent, 'settings') and 'persistent_token' in parent.settings:
                self.api_token = parent.settings['persistent_token']
                logger.info("Got token from parent.settings in dialog init")
        
        self.setWindowTitle("Analytics Dashboard")
        self.resize(1000, 700)
        self.setup_ui()
        
        if site_id:
            self.load_analytics()
            
    def set_api_token(self, token):
        """Manually set the API token"""
        self.api_token = token
        logger.info("API token manually set in dialog")
        
        # If we already have the dialog open, reload sites
        if self.isVisible():
            self.load_sites()
    
    def setup_ui(self):
        """Set up the dialog UI"""
        layout = QVBoxLayout()
        self.setLayout(layout)
        
        # Site selection
        site_selection_layout = QHBoxLayout()
        site_label = QLabel("Site:")
        self.site_combo = QComboBox()
        self.site_combo.setMinimumWidth(300)
        self.refresh_sites_button = QPushButton("Refresh Sites")
        self.refresh_sites_button.clicked.connect(self.refresh_sites)
        
        site_selection_layout.addWidget(site_label)
        site_selection_layout.addWidget(self.site_combo)
        site_selection_layout.addWidget(self.refresh_sites_button)
        site_selection_layout.addStretch()
        
        # Date range selection
        date_range_layout = QHBoxLayout()
        from_label = QLabel("From:")
        self.from_date = QDateEdit()
        self.from_date.setDate(datetime.now().date() - timedelta(days=30))
        self.from_date.setCalendarPopup(True)
        
        to_label = QLabel("To:")
        self.to_date = QDateEdit()
        self.to_date.setDate(datetime.now().date())
        self.to_date.setCalendarPopup(True)
        
        self.apply_date_button = QPushButton("Apply")
        self.apply_date_button.clicked.connect(self.apply_date_range)
        
        date_range_layout.addWidget(from_label)
        date_range_layout.addWidget(self.from_date)
        date_range_layout.addWidget(to_label)
        date_range_layout.addWidget(self.to_date)
        date_range_layout.addWidget(self.apply_date_button)
        date_range_layout.addStretch()
        
        # Add top controls to layout
        controls_layout = QVBoxLayout()
        controls_layout.addLayout(site_selection_layout)
        controls_layout.addLayout(date_range_layout)
        layout.addLayout(controls_layout)
        
        # Tabs for different analytics views
        self.tabs = QTabWidget()
        layout.addWidget(self.tabs)
        
        # Overview tab
        self.overview_tab = QWidget()
        overview_layout = QVBoxLayout()
        self.overview_tab.setLayout(overview_layout)
        
        # Analytics overview
        analytics_overview_group = QGroupBox("Site Analytics Overview")
        analytics_overview_layout = QFormLayout()
        analytics_overview_group.setLayout(analytics_overview_layout)
        
        self.page_views_label = QLabel("0")
        analytics_overview_layout.addRow("Page Views:", self.page_views_label)
        
        self.unique_visitors_label = QLabel("0")
        analytics_overview_layout.addRow("Unique Visitors:", self.unique_visitors_label)
        
        self.bandwidth_label = QLabel("0 KB")
        analytics_overview_layout.addRow("Bandwidth Used:", self.bandwidth_label)
        
        overview_layout.addWidget(analytics_overview_group)
        
        # Page views table
        pages_group = QGroupBox("Top Pages")
        pages_layout = QVBoxLayout()
        pages_group.setLayout(pages_layout)
        
        self.pages_table = QTableWidget(0, 3)
        self.pages_table.setHorizontalHeaderLabels(["Page Path", "Views", "Unique Visitors"])
        self.pages_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        pages_layout.addWidget(self.pages_table)
        
        overview_layout.addWidget(pages_group)
        
        self.tabs.addTab(self.overview_tab, "Overview")
        
        # Traffic Sources tab
        if MATPLOTLIB_AVAILABLE:
            self.sources_tab = QWidget()
            sources_layout = QVBoxLayout()
            self.sources_tab.setLayout(sources_layout)
            
            # Traffic sources chart
            self.sources_chart = AnalyticsChart(width=8, height=5)
            sources_layout.addWidget(self.sources_chart)
            
            # Traffic sources table
            self.sources_table = QTableWidget(0, 2)
            self.sources_table.setHorizontalHeaderLabels(["Source", "Visits"])
            self.sources_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
            sources_layout.addWidget(self.sources_table)
            
            self.tabs.addTab(self.sources_tab, "Traffic Sources")
            
            # Browsers tab
            self.browsers_tab = QWidget()
            browsers_layout = QVBoxLayout()
            self.browsers_tab.setLayout(browsers_layout)
            
            # Browser usage chart
            self.browsers_chart = AnalyticsChart(width=8, height=5)
            browsers_layout.addWidget(self.browsers_chart)
            
            # Browser usage table
            self.browsers_table = QTableWidget(0, 2)
            self.browsers_table.setHorizontalHeaderLabels(["Browser", "Usage"])
            self.browsers_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
            browsers_layout.addWidget(self.browsers_table)
            
            self.tabs.addTab(self.browsers_tab, "Browsers")
        
        # Bottom buttons
        button_layout = QHBoxLayout()
        self.refresh_button = QPushButton("Refresh Analytics")
        self.refresh_button.clicked.connect(self.load_analytics)
        
        self.close_button = QPushButton("Close")
        self.close_button.clicked.connect(self.accept)
        
        button_layout.addWidget(self.refresh_button)
        button_layout.addStretch()
        button_layout.addWidget(self.close_button)
        
        layout.addLayout(button_layout)
        
        # Progress indicator
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        layout.addWidget(self.progress_bar)
        
        # Load sites
        self.load_sites()

    def load_sites(self):
        """Load sites into the combo box"""
        if not self.api_token:
            result = QMessageBox.warning(
                self,
                "API Token Required",
                "Please set your Netlify API token in Settings to use the Analytics Dashboard.\n\n"
                "Go to Configuration > Settings and enter your Netlify API token.\n\n"
                "Would you like to enter your API token now?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.Yes
            )
            
            if result == QMessageBox.StandardButton.Yes:
                self.show_token_input_dialog()
            else:
                self.close()
            return
            
        try:
            # Show progress bar
            self.progress_bar.setVisible(True)
            self.progress_bar.setValue(0)
            self.progress_bar.setRange(0, 0)  # Indeterminate progress
            
            # Disable UI during fetch
            self.setEnabled(False)
            QApplication.processEvents()
            
            # Fetch sites
            client = AnalyticsClient(self.api_token)
            response = requests.get(f"{client.BASE_URL}/sites", headers=client.headers)
            
            if response.status_code == 200:
                sites = response.json()
                
                # Populate combo box
                self.site_combo.clear()
                
                for site in sites:
                    self.site_combo.addItem(site.get("name", "Unknown"), site.get("id"))
                
                # Select site if specified
                if self.site_id:
                    for i in range(self.site_combo.count()):
                        if self.site_combo.itemData(i) == self.site_id:
                            self.site_combo.setCurrentIndex(i)
                            break
                
                # Connect signal after populating to avoid triggering load_analytics
                self.site_combo.currentIndexChanged.connect(self.site_changed)
            else:
                QMessageBox.critical(
                    self,
                    "Error",
                    f"Failed to fetch sites: {response.status_code} - {response.text}"
                )
        except Exception as e:
            QMessageBox.critical(
                self,
                "Error",
                f"Failed to fetch sites: {str(e)}"
            )
        finally:
            # Re-enable UI
            self.setEnabled(True)
            self.progress_bar.setVisible(False)
    
    def show_token_input_dialog(self):
        """Show dialog to input API token manually"""
        token, ok = QInputDialog.getText(
            self, 
            "Enter Netlify API Token", 
            "Please enter your Netlify API token:",
            QLineEdit.EchoMode.Password
        )
        
        if ok and token:
            self.api_token = token
            logger.info("API token manually entered by user")
            
            # If parent window exists, try to save the token
            if self.parent:
                if hasattr(self.parent, 'persistent_token'):
                    self.parent.persistent_token = token
                    logger.info("Saved token to parent.persistent_token")
                    
                    # Also save to settings if possible
                    if hasattr(self.parent, 'settings'):
                        self.parent.settings['persistent_token'] = token
                        logger.info("Saved token to parent.settings")
                        
                        # Try to save settings if the method exists
                        if hasattr(self.parent, 'save_settings'):
                            try:
                                self.parent.save_settings()
                                logger.info("Called parent.save_settings()")
                            except Exception as e:
                                logger.error(f"Error saving settings: {str(e)}")
                                
                        # Try to save persistent settings if the method exists
                        if hasattr(self.parent, 'save_persistent_settings'):
                            try:
                                self.parent.save_persistent_settings()
                                logger.info("Called parent.save_persistent_settings()")
                            except Exception as e:
                                logger.error(f"Error saving persistent settings: {str(e)}")
            
            # Reload sites with new token
            self.load_sites()
        else:
            self.close()
    
    def refresh_sites(self):
        """Refresh the sites list"""
        self.load_sites()
    
    def site_changed(self):
        """Handle site selection change"""
        self.site_id = self.site_combo.currentData()
        self.site_name = self.site_combo.currentText()
        self.load_analytics()
    
    def apply_date_range(self):
        """Apply the selected date range to analytics"""
        self.load_analytics()
    
    def load_analytics(self):
        """Load analytics data for the selected site"""
        if not self.site_id:
            return
        
        # Show progress bar
        self.progress_bar.setVisible(True)
        self.progress_bar.setValue(0)
        self.progress_bar.setRange(0, 0)  # Indeterminate progress
        
        # Disable UI during fetch
        self.setEnabled(False)
        QApplication.processEvents()
        
        # Get date range
        from_date = self.from_date.date().toString("yyyy-MM-dd")
        to_date = self.to_date.date().toString("yyyy-MM-dd")
        
        # Create and start worker thread
        self.analytics_worker = FetchAnalyticsWorker(
            self.api_token, self.site_id, from_date, to_date
        )
        self.analytics_worker.analytics_fetched.connect(self.handle_analytics_fetched)
        self.analytics_worker.error.connect(self.handle_fetch_error)
        self.analytics_worker.start()
        
        # Fetch traffic sources if matplotlib is available
        if MATPLOTLIB_AVAILABLE:
            self.sources_worker = FetchTrafficSourcesWorker(self.api_token, self.site_id)
            self.sources_worker.sources_fetched.connect(self.handle_sources_fetched)
            self.sources_worker.error.connect(self.handle_fetch_error)
            self.sources_worker.start()
    
    def handle_analytics_fetched(self, analytics):
        """Handle fetched analytics data"""
        # Check if analytics data is empty
        if not analytics:
            logger.warning(f"No analytics data available for site {self.site_id}")
            self.page_views_label.setText("0")
            self.unique_visitors_label.setText("0")
            self.bandwidth_label.setText("0 B")
            self.pages_table.setRowCount(0)
            
            # Re-enable UI if sources are not being fetched
            if not MATPLOTLIB_AVAILABLE:
                self.setEnabled(True)
                self.progress_bar.setVisible(False)
            return
            
        # Update overview
        self.page_views_label.setText(str(analytics.get("views", 0)))
        self.unique_visitors_label.setText(str(analytics.get("visitors", 0)))
        
        # Format bandwidth
        bandwidth = analytics.get("bandwidth", 0)
        if bandwidth < 1024:
            bandwidth_str = f"{bandwidth} B"
        elif bandwidth < 1024 * 1024:
            bandwidth_str = f"{bandwidth / 1024:.2f} KB"
        elif bandwidth < 1024 * 1024 * 1024:
            bandwidth_str = f"{bandwidth / (1024 * 1024):.2f} MB"
        else:
            bandwidth_str = f"{bandwidth / (1024 * 1024 * 1024):.2f} GB"
        
        self.bandwidth_label.setText(bandwidth_str)
        
        # Update pages table
        self.pages_table.setRowCount(0)
        
        pages = analytics.get("pages", [])
        self.pages_table.setRowCount(len(pages))
        
        for i, page in enumerate(pages):
            # Path
            path_item = QTableWidgetItem(page.get("path", ""))
            self.pages_table.setItem(i, 0, path_item)
            
            # Views
            views_item = QTableWidgetItem(str(page.get("views", 0)))
            self.pages_table.setItem(i, 1, views_item)
            
            # Unique visitors
            visitors_item = QTableWidgetItem(str(page.get("visitors", 0)))
            self.pages_table.setItem(i, 2, visitors_item)
        
        # Re-enable UI if sources are not being fetched
        if not MATPLOTLIB_AVAILABLE:
            self.setEnabled(True)
            self.progress_bar.setVisible(False)
    
    def handle_sources_fetched(self, sources_data):
        """Handle fetched traffic sources data"""
        # Re-enable UI
        self.setEnabled(True)
        self.progress_bar.setVisible(False)
        
        # Check if sources data is empty or missing
        if not sources_data or 'sources' not in sources_data or not sources_data.get('sources', []):
            logger.warning(f"No traffic sources data available for site {self.site_id}")
            # Show a message in the chart area
            if hasattr(self, 'sources_chart'):
                self.sources_chart.axes.clear()
                self.sources_chart.axes.text(0.5, 0.5, "No traffic sources data available", 
                                           horizontalalignment='center',
                                           verticalalignment='center',
                                           transform=self.sources_chart.axes.transAxes)
                self.sources_chart.draw()
            
            # Clear the table
            self.sources_table.setRowCount(0)
            return
        
        # Update sources table
        self.sources_table.setRowCount(0)
        
        sources = sources_data.get("sources", [])
        self.sources_table.setRowCount(len(sources))
        
        labels = []
        values = []
        
        for i, source in enumerate(sources):
            source_name = source.get("source", "Unknown")
            visits = source.get("visits", 0)
            
            # Add to table
            source_item = QTableWidgetItem(source_name)
            self.sources_table.setItem(i, 0, source_item)
            
            visits_item = QTableWidgetItem(str(visits))
            self.sources_table.setItem(i, 1, visits_item)
            
            # Add to chart data
            labels.append(source_name)
            values.append(visits)
        
        # Update chart
        if labels and values:
            self.sources_chart.plot_pie_chart(
                labels, values, title="Traffic Sources"
            )
    
    def handle_fetch_error(self, error_message):
        """Handle error when fetching data"""
        self.setEnabled(True)
        self.progress_bar.setVisible(False)
        
        # Check for specific error types and provide more helpful messages
        if "404" in error_message:
            error_title = "Analytics Not Available"
            error_text = (
                "Analytics data is not available for this site.\n\n"
                "This could be because:\n"
                "• The site is new and hasn't received traffic yet\n"
                "• Analytics features are not enabled for your Netlify account tier\n"
                "• The site ID is incorrect\n\n"
                "You can still use other features of the application."
            )
        elif "401" in error_message or "403" in error_message:
            error_title = "Authentication Error"
            error_text = (
                "Your API token doesn't have permission to access this data.\n\n"
                "Please check that:\n"
                "• Your API token is correct\n"
                "• Your token has the necessary permissions\n"
                "• You have access to this site in your Netlify account"
            )
        else:
            error_title = "Error Fetching Data"
            error_text = f"Failed to fetch data: {error_message}"
        
        QMessageBox.warning(
            self,
            error_title,
            error_text
        )
