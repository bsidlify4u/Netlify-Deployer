# --- Robust Import Handling and Python Version Check ---
import sys
if sys.version_info < (3, 8):
    print("[FATAL] Python 3.8 or higher is required.")
    sys.exit(1)
try:
    import requests
    from dotenv import load_dotenv
    from PyQt6.QtWidgets import (
        QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
        QPushButton, QLineEdit, QLabel, QProgressBar, QFileDialog,
        QMessageBox, QTextEdit, QFrame, QGraphicsDropShadowEffect,
        QDialog, QDialogButtonBox, QInputDialog, QTableWidget, QTableWidgetItem, QComboBox, QScrollArea, QCheckBox, QMenu, QGroupBox, QRadioButton, QListWidget, QListWidgetItem, QProgressDialog
    )
    from PyQt6.QtCore import Qt, QThread, pyqtSignal, QSize, QTimer, QPropertyAnimation, QPoint, QEasingCurve, QProcess, QEvent, QUrl
    from PyQt6.QtGui import QIcon, QColor, QPainter, QLinearGradient, QAction, QCursor, QClipboard, QPixmap, QDesktopServices
    from cryptography.fernet import Fernet, InvalidToken
    import base64
    from argon2 import PasswordHasher, exceptions as argon2_exceptions
except ImportError as e:
    print(f"[FATAL] Missing dependency: {e}. Please install all requirements from requirements.txt.")
    sys.exit(1)

# Import security features
try:
    from security_features import SecurityManager as EnhancedSecurityManager
    from tos_dialog import TermsOfServiceDialog
    SECURITY_FEATURES_AVAILABLE = True
except ImportError:
    SECURITY_FEATURES_AVAILABLE = False
    print("[WARNING] Enhanced security features not available. Some protection features will be disabled.")

# --- Global Exception Hook for User-Friendly Error Dialogs ---
def global_exception_hook(exctype, value, traceback):
    try:
        from PyQt6.QtWidgets import QMessageBox
        msg = f"Uncaught exception: {value}"
        QMessageBox.critical(None, "Fatal Error", msg)
    except Exception:
        print(f"Uncaught exception: {value}")
    sys.exit(1)

sys.excepthook = global_exception_hook

# Standard library imports
import os
import json
import time
import hashlib
from datetime import datetime, timedelta
import stat
import getpass
import platform
import subprocess
import csv

# Import styles from styles.py
from styles import (
    DESIGN, CARD_STYLE, PROGRESS_STYLE, GLASS_CARD_STYLE, GLASS_DIALOG_STYLE, SPINNER_STYLE, OUTPUT_SCROLLBAR_STYLE, OUTPUT_SYNTAX_STYLE
)

# Load environment variables with proper error handling
try:
    load_dotenv(override=True)  # Force override of existing env variables
    
    # API Constants with error handling
    NETLIFY_API_BASE = os.getenv('NETLIFY_API_BASE')
    if not NETLIFY_API_BASE:
        raise ValueError("NETLIFY_API_BASE environment variable not found")
    
    # Convert string env vars to integers with error handling
    try:
        API_RATE_LIMIT_PER_MINUTE = int(os.getenv('API_RATE_LIMIT_PER_MINUTE'))
        DEPLOY_RATE_LIMIT_PER_MINUTE = int(os.getenv('DEPLOY_RATE_LIMIT_PER_MINUTE'))
        DEPLOY_RATE_LIMIT_PER_DAY = int(os.getenv('DEPLOY_RATE_LIMIT_PER_DAY'))
    except ValueError as e:
        print(f"[ERROR] Invalid environment variable format: {e}")
        print("[INFO] Using default rate limit values")
    
    # Security settings
    MASTER_PASSWORD_HASH = os.getenv('MASTER_PASSWORD_HASH')
    if not MASTER_PASSWORD_HASH:
        raise ValueError("MASTER_PASSWORD_HASH must be set in .env file (use Argon2 hash, not plaintext)")
except Exception as e:
    print(f"[FATAL] Environment setup failed: {e}")
    sys.exit(1)

# Argon2 password hasher instance
ph = PasswordHasher()

# Load environment variables with password
def load_env_with_password():
    try:
        # Try to load from .env file
        load_dotenv(override=True)
        
        # Check if required environment variables exist
        required_vars = [
            'NETLIFY_API_BASE',
            'API_RATE_LIMIT_PER_MINUTE',
            'DEPLOY_RATE_LIMIT_PER_MINUTE',
            'DEPLOY_RATE_LIMIT_PER_DAY',
            'MASTER_PASSWORD_HASH'  # Add password to required vars
        ]
        
        missing_vars = [var for var in required_vars if not os.getenv(var)]
        
        if missing_vars:
            raise ValueError(f"Missing required environment variables: {', '.join(missing_vars)}")
            
        # Verify password matches
        stored_password = os.getenv('MASTER_PASSWORD_HASH')
        if not stored_password:
            raise ValueError("Master password not set in .env file")
            
        return True
            
    except Exception as e:
        QMessageBox.critical(None, "Environment Error", str(e))
        return False

# Load environment with password check
if not load_env_with_password():
    sys.exit(1)

# File type constants
MIME_TYPES = {
    '.html': 'text/html',
    '.css': 'text/css',
    '.js': 'application/javascript',
    '.json': 'application/json',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.gif': 'image/gif',
    '.svg': 'image/svg+xml',
    '.ico': 'image/x-icon',
    '.woff': 'font/woff',
    '.woff2': 'font/woff2',
    '.ttf': 'font/ttf',
    '.eot': 'application/vnd.ms-fontobject',
    '.otf': 'font/otf',
    '.pdf': 'application/pdf',
    '.txt': 'text/plain',
    '.xml': 'application/xml',
}

# --- Security Utilities ---
class SecurityManager:
    def __init__(self, key_file='security.key'):
        self.key_file = key_file
        self.key = None
        self.fernet = None
        # No longer use plaintext password, key will be set after password check

    def generate_key(self, password: str):
        try:
            import base64, hashlib
            key = hashlib.sha256(password.encode()).digest()
            self.key = base64.urlsafe_b64encode(key)
            self.fernet = Fernet(self.key)
            with open(self.key_file, 'wb') as f:
                f.write(self.key)
        except Exception as e:
            print(f"Error generating key: {str(e)}")
            self.key = Fernet.generate_key()
            self.fernet = Fernet(self.key)

    def load_key(self, password: str):
        # Password is already verified before this is called
        self.generate_key(password)

    def encrypt(self, data: str) -> str:
        return self.fernet.encrypt(data.encode()).decode()

    def decrypt(self, token: str) -> str:
        return self.fernet.decrypt(token.encode()).decode()

# --- Password Dialog ---
class PasswordDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        # Remove title bar by setting frameless window hint
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint)
        self.setModal(True)
        self.failed_attempts = 0
        self.max_attempts = 5
        self.lockout_time = 30  # seconds
        self.last_attempt_time = 0
        
        # Set fixed width but allow height to adjust automatically
        #self.setFixedWidth(480)
        #self.setFixedHeight(520)  # Set a reasonable minimum height
        
        # Track mouse position for moving the frameless window
        self._mousePressPos = None
        self._mouseMoveCursor = None
        
        # Main layout with zero margins - we'll use a card inside
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)
        
        # Create a card container with stylish background
        card = QFrame()
        card.setObjectName("loginCard")
        card.setStyleSheet("""
            QFrame#loginCard {
                background-color: #1e1e1e;
                border: 1px solid #333333;
                border-radius: 6px;
            }
        """)
        
        # Layout for card contents
        card_layout = QVBoxLayout(card)
        card_layout.setContentsMargins(30, 30, 30, 30)
        card_layout.setSpacing(20)
        
        # Create a logo/branding area
        logo_frame = QFrame()
        logo_frame.setFixedHeight(80)
        logo_frame.setStyleSheet("""
            QFrame {
                background-color: #202020;
                border-radius: 8px;
                border-bottom: 3px solid #0078D4;
            }
        """)
        
        logo_layout = QVBoxLayout(logo_frame)
        logo_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        # Netlify logo text
        logo_label = QLabel("Netlify Deployer")
        logo_label.setStyleSheet("""
            color: #FFFFFF;
            font-size: 26px;
            font-weight: bold;
            font-family: 'Segoe UI', Arial, sans-serif;
        """)
        logo_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        # Add a small tagline
        tagline = QLabel("Deployment Management")
        tagline.setStyleSheet("""
            color: #999999;
            font-size: 12px;
            font-family: 'Segoe UI', Arial, sans-serif;
        """)
        tagline.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        logo_layout.addWidget(logo_label)
        logo_layout.addWidget(tagline)
        card_layout.addWidget(logo_frame)
        
        # Welcome message
        welcome_label = QLabel("Welcome Back")
        welcome_label.setStyleSheet("""
            color: #0078D4;
            font-size: 18px;
            font-weight: bold;
            margin-top: 10px;
        """)
        welcome_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        card_layout.addWidget(welcome_label)
        
        # Instruction with icon
        instruction_layout = QHBoxLayout()
        lock_icon = QLabel("🔒")
        lock_icon.setStyleSheet("""
            font-size: 16px;
            color: #AAAAAA;
        """)
        
        instruction = QLabel("Enter your management password to continue:")
        instruction.setStyleSheet("""
            color: #CCCCCC;
            font-size: 14px;
        """)
        
        instruction_layout.addWidget(lock_icon)
        instruction_layout.addWidget(instruction)
        instruction_layout.addStretch()
        card_layout.addLayout(instruction_layout)
        
        # Password field with modern styling and show/hide toggle
        password_container = QFrame()
        password_container.setStyleSheet("""
            QFrame {
                background-color: #252525;
                border: 1px solid #383838;
                border-radius: 5px;
                margin-top: 5px;
                margin-bottom: 5px;
            }
            QFrame:focus-within {
                border: 1px solid #0078D4;
                background-color: #2A2A2A;
            }
        """)
        
        password_layout = QHBoxLayout(password_container)
        password_layout.setContentsMargins(2, 2, 2, 2)
        password_layout.setSpacing(0)
        
        # Password input field
        self.input = QLineEdit()
        self.input.setEchoMode(QLineEdit.EchoMode.Password)
        self.input.setStyleSheet("""
            QLineEdit {
                background-color: transparent;
                color: white;
                border: none;
                padding: 10px 15px;
                font-size: 14px;
                selection-background-color: #0078D4;
            }
        """)
        self.input.setPlaceholderText("Enter password...")
        
        # Show/hide password button
        self.toggle_password_btn = QPushButton("👁️")
        self.toggle_password_btn.setCheckable(True)
        self.toggle_password_btn.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        self.toggle_password_btn.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                color: #AAAAAA;
                border: none;
                padding: 5px 10px;
                font-size: 16px;
                border-radius: 0px;
                min-width: 40px;
            }
            QPushButton:hover {
                color: #FFFFFF;
            }
            QPushButton:checked {
                color: #0078D4;
            }
        """)
        self.toggle_password_btn.setToolTip("Show password")
        self.toggle_password_btn.clicked.connect(self.toggle_password_visibility)
        
        password_layout.addWidget(self.input)
        password_layout.addWidget(self.toggle_password_btn)
        
        card_layout.addWidget(password_container)
        
        # Remember password checkbox with modern styling
        self.remember_password = QCheckBox("Remember password for this session")
        self.remember_password.setStyleSheet("""
            QCheckBox {
                color: #AAAAAA;
                font-size: 13px;
                padding: 5px;
            }
            QCheckBox::indicator {
                width: 18px;
                height: 18px;
                border: 1px solid #444444;
                border-radius: 3px;
                background-color: #252525;
            }
            QCheckBox::indicator:checked {
                background-color: #0078D4;
                border: 1px solid #0078D4;
                image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxNiIgaGVpZ2h0PSIxNiIgdmlld0JveD0iMCAwIDE2IDE2IiBmaWxsPSJub25lIj48cGF0aCBkPSJNMTMuNSA0TDYgMTEuNSAyLjUgOCIgc3Ryb2tlPSJ3aGl0ZSIgc3Ryb2tlLXdpZHRoPSIyIiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiLz48L3N2Zz4=);
            }
            QCheckBox::indicator:hover {
                border: 1px solid #0078D4;
            }
        """)
        card_layout.addWidget(self.remember_password)
        
        # Error message (hidden initially) with improved styling
        self.error_label = QLabel("")
        self.error_label.setStyleSheet("""
            color: #F85149;
            font-size: 13px;
            padding: 10px;
            background-color: rgba(248, 81, 73, 0.07);
            border-radius: 4px;
            border-left: 3px solid #F85149;
            margin-top: 5px;
        """)
        self.error_label.setWordWrap(True)
        self.error_label.hide()
        card_layout.addWidget(self.error_label)
        
        # Add stretch to push buttons to the bottom
        card_layout.addStretch()
        
        # Modern button layout
        button_layout = QHBoxLayout()
        button_layout.setSpacing(15)
        
        # Cancel button
        cancel_btn = QPushButton("Cancel")
        cancel_btn.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        cancel_btn.setStyleSheet("""
            QPushButton {
                background-color: #2D2D2D;
                color: #CCCCCC;
                border: none;
                padding: 12px 0px;
                font-size: 14px;
                font-weight: 500;
                border-radius: 4px;
                min-width: 120px;
            }
            QPushButton:hover {
                background-color: #3D3D3D;
                color: #FFFFFF;
            }
            QPushButton:pressed {
                background-color: #333333;
            }
        """)
        cancel_btn.clicked.connect(self.reject)
        
        # Login button
        login_btn = QPushButton("Log In")
        login_btn.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        login_btn.setStyleSheet("""
            QPushButton {
                background-color: #0078D4;
                color: white;
                border: none;
                padding: 12px 0px;
                font-size: 14px;
                font-weight: 600;
                border-radius: 4px;
                min-width: 120px;
            }
            QPushButton:hover {
                background-color: #0086F0;
            }
            QPushButton:pressed {
                background-color: #006CBE;
            }
        """)
        login_btn.clicked.connect(self.validate_password)
        
        button_layout.addStretch()
        button_layout.addWidget(cancel_btn)
        button_layout.addWidget(login_btn)
        card_layout.addLayout(button_layout)
        
        # Add the card to the main layout with margins for shadow effect
        main_layout.addWidget(card, 1, Qt.AlignmentFlag.AlignCenter)
        
        # Apply shadow effect to the card
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(20)
        shadow.setColor(QColor(0, 0, 0, 70))
        shadow.setOffset(0, 0)
        card.setGraphicsEffect(shadow)
        
        # Set overall dialog styling
        self.setStyleSheet("""
            QDialog {
                background-color: #1A1A1A;
            }
        """)
        
        # Set focus to password field
        self.input.setFocus()
        
        # Set enter key to validate
        self.input.returnPressed.connect(login_btn.click)

    def validate_password(self):
        import time
        if self.failed_attempts >= self.max_attempts:
            now = time.time()
            if now - self.last_attempt_time < self.lockout_time:
                # Create custom error dialog for lockout
                lockout_dialog = AuthErrorDialog(self)
                
                # Update title and message for lockout
                for child in lockout_dialog.findChildren(QLabel):
                    if child.text() == "Authentication Error":
                        child.setText("Account Locked")
                    elif child.text() == "Invalid password. Please check your credentials and try again.":
                        child.setText(f"Too many failed attempts. Please wait {int(self.lockout_time - (now - self.last_attempt_time))} seconds before trying again.")
                
                lockout_dialog.exec()
                return
            else:
                self.failed_attempts = 0
        password = self.input.text()
        try:
            ph.verify(MASTER_PASSWORD_HASH, password)
            # If verify passes, clear sensitive data
            self.input.clear()
            self.accept()
        except argon2_exceptions.VerifyMismatchError:
            self.failed_attempts += 1
            self.last_attempt_time = time.time()
            time.sleep(0.5)  # Add delay to slow brute-force
            
            # Use our custom AuthErrorDialog instead of QMessageBox
            error_dialog = AuthErrorDialog(self)
            error_dialog.exec()
            
            self.input.clear()
            self.input.setFocus()
        except Exception as e:
            # Create custom error dialog for general errors
            general_error_dialog = AuthErrorDialog(self)
            
            # Update title and message for general error
            for child in general_error_dialog.findChildren(QLabel):
                if child.text() == "Authentication Error":
                    child.setText("Error")
                elif child.text() == "Invalid password. Please check your credentials and try again.":
                    child.setText(f"Password verification failed: {str(e)}")
            
            general_error_dialog.exec()
            self.input.clear()
            self.input.setFocus()

    def get_password(self):
        return self.input.text()

    def toggle_password_visibility(self):
        """Toggle between showing and hiding the password."""
        if self.toggle_password_btn.isChecked():
            self.input.setEchoMode(QLineEdit.EchoMode.Normal)
            self.toggle_password_btn.setText("🔒")
            self.toggle_password_btn.setToolTip("Hide password")
        else:
            self.input.setEchoMode(QLineEdit.EchoMode.Password)
            self.toggle_password_btn.setText("👁️")
            self.toggle_password_btn.setToolTip("Show password")

class AuthErrorDialog(QDialog):
    """Custom frameless error dialog for authentication errors."""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        # Remove title bar
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.Dialog)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setModal(True)
        
        # Set size
        self.setFixedSize(400, 220)
        
        # Create layout
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        
        # Create main container with border radius
        container = QFrame(self)
        container.setObjectName("container")
        container.setStyleSheet("""
            QFrame#container {
                background-color: #1E1E1E;
                border-radius: 8px;
                border: 1px solid #333333;
            }
        """)
        
        container_layout = QVBoxLayout(container)
        container_layout.setContentsMargins(20, 20, 20, 20)
        container_layout.setSpacing(15)
        
        # Header with close button
        header_layout = QHBoxLayout()
        
        error_title = QLabel("Authentication Error")
        error_title.setStyleSheet("""
            color: #FF5252;
            font-size: 16px;
            font-weight: bold;
        """)
        header_layout.addWidget(error_title)
        
        header_layout.addStretch()
        
        close_btn = QPushButton("✕")
        close_btn.setFixedSize(20, 20)
        close_btn.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        close_btn.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                color: #888;
                border: none;
                font-weight: bold;
                border-radius: 10px;
            }
            QPushButton:hover {
                background-color: #FF5252;
                color: white;
            }
        """)
        close_btn.clicked.connect(self.accept)
        header_layout.addWidget(close_btn)
        
        container_layout.addLayout(header_layout)
        
        # Error icon and message
        message_layout = QHBoxLayout()
        
        error_icon = QLabel("⚠️")
        error_icon.setStyleSheet("font-size: 32px; margin-right: 10px;")
        message_layout.addWidget(error_icon)
        
        error_message = QLabel("Invalid password. Please check your credentials and try again.")
        error_message.setWordWrap(True)
        error_message.setStyleSheet("""
            color: #DDD;
            font-size: 14px;
        """)
        message_layout.addWidget(error_message, 1)
        
        container_layout.addLayout(message_layout)
        
        container_layout.addStretch()
        
        # OK button
        ok_button = QPushButton("OK")
        ok_button.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        ok_button.setStyleSheet("""
            QPushButton {
                background-color: #0078D4;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 8px 16px;
                font-size: 14px;
                min-width: 80px;
            }
            QPushButton:hover {
                background-color: #0086F0;
            }
            QPushButton:pressed {
                background-color: #006CBE;
            }
        """)
        ok_button.clicked.connect(self.accept)
        
        btn_layout = QHBoxLayout()
        btn_layout.addStretch()
        btn_layout.addWidget(ok_button)
        container_layout.addLayout(btn_layout)
        
        layout.addWidget(container)
        
        # Add shadow effect
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(20)
        shadow.setColor(QColor(0, 0, 0, 80))
        shadow.setOffset(0, 0)
        container.setGraphicsEffect(shadow)
        
    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self._mouse_press_pos = event.globalPosition().toPoint()
        super().mousePressEvent(event)
        
    def mouseMoveEvent(self, event):
        if event.buttons() == Qt.MouseButton.LeftButton and hasattr(self, '_mouse_press_pos'):
            self.move(self.pos() + event.globalPosition().toPoint() - self._mouse_press_pos)
            self._mouse_press_pos = event.globalPosition().toPoint()
        super().mouseMoveEvent(event)

class DeploymentWorker(QThread):
    """Worker thread for handling Netlify deployments using the REST API.
    
    This implementation uses proper file hashing and individual file uploads.
    """
    progress = pyqtSignal(int)
    status = pyqtSignal(str)
    error = pyqtSignal(str)
    success = pyqtSignal(str)
    deployment_complete = pyqtSignal(str)    
    
    def __init__(self, token, project_path, publish_dir, site_name, team_name):
        super().__init__()
        self.token = token
        self.project_path = project_path
        self.publish_dir = publish_dir
        self.site_name = site_name
        self.team_name = team_name
        self.start_time = time.time()
        self.session = requests.Session()
        self.headers = {'Authorization': f'Bearer {token}'}
        
        # Initialize security features if available
        self.security_manager = None
        self.processed_content = {}  # Store processed content for files
        if SECURITY_FEATURES_AVAILABLE:
            try:
                self.security_manager = EnhancedSecurityManager()
                self.log("🔒 Enhanced security features initialized")
            except Exception as e:
                print(f"Error initializing security features: {e}")
        
    def _compute_file_hash(self, file_path):
        """Compute SHA1 hash of a file."""
        sha1 = hashlib.sha1()
        with open(file_path, 'rb') as f:
            for chunk in iter(lambda: f.read(4096), b''):
                sha1.update(chunk)
        return sha1.hexdigest()
    
    def _get_files_info(self, directory):
        """Get information about all files in the directory."""
        files_info = []
        total_size = 0
        
        for root, _, files in os.walk(directory):
            for file in files:
                file_path = os.path.join(root, file)
                relative_path = os.path.relpath(file_path, directory)
                
                # Convert Windows paths to forward slashes
                relative_path = relative_path.replace('\\', '/')
                
                file_size = os.path.getsize(file_path)
                total_size += file_size
                
                # Process content with watermarking if security features are available
                if self.security_manager and file_path.endswith(('.html', '.css', '.js')):
                    try:
                        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                            content = f.read()
                            processed = self.security_manager.process_file_content(file_path, content)
                            if processed != content:
                                self.processed_content[file_path] = processed
                    except Exception as e:
                        self.log(f"⚠️ Warning: Could not process {file_path}: {str(e)}")
                
                files_info.append({
                    'path': relative_path,
                    'full_path': file_path,
                    'size': file_size,
                    'sha1': self._compute_file_hash(file_path)
                })
                
        return files_info, total_size
    
    def _create_deploy(self, site_id, files_info):
        """Create a new deploy with file hashes."""
        deploy_url = f'{NETLIFY_API_BASE}/sites/{site_id}/deploys'
        files_dict = {file['path']: file['sha1'] for file in files_info}
        
        # Base deployment data
        deploy_data = {
            'title': f'Deployment via Desktop App - {time.strftime("%Y-%m-%d %H:%M:%S")}',
            'files': files_dict,
            'draft': False,
            'async': True
        }
        
        # Apply security enhancements if available
        if self.security_manager:
            try:
                # Add fingerprinting to deployment
                deploy_data = self.security_manager.fingerprinter.add_fingerprint_to_deployment(deploy_data)
                self.log("🔐 Added secure deployment fingerprint")
                
                # Apply custom protocol transformation
                custom_data, custom_headers = self.security_manager.deployment_protocol.transform_request(deploy_data)
                # Merge headers, preserving authorization
                merged_headers = {**self.headers, **custom_headers}
                
                # Make API request with enhanced security
                response = self.session.post(deploy_url, headers=merged_headers, json=custom_data)
                
            except Exception as e:
                self.log(f"⚠️ Security enhancement failed, using standard protocol: {str(e)}")
                # Fall back to standard API call
                response = self.session.post(deploy_url, headers=self.headers, json=deploy_data)
        else:
            # Standard API call without security enhancements
            response = self.session.post(deploy_url, headers=self.headers, json=deploy_data)
            
        if response.status_code not in [200, 201]:
            self.log(f"❌ Deploy creation failed - status: {response.status_code}, response: {response.text}")
            raise ValueError(f"Failed to create deploy: {response.text}")
        
        return response.json()

    def _create_site(self):
        """Create or get an existing site based on site name and team name."""
        self.log(f"🌐 Looking for site: {self.site_name}")
        
        # First, check if site already exists
        try:
            # Get all user sites (skip team site check)
            sites_url = f"{NETLIFY_API_BASE}/sites"
            response = self.session.get(sites_url, headers=self.headers)
            if response.status_code != 200:
                self.log(f"❌ User site search failed - status: {response.status_code}, response: {response.text}")
                raise ValueError(f"Failed to fetch sites: {response.text}")
            
            # Check if site exists by name
            sites = response.json()
            for site in sites:
                if site.get('name') == self.site_name:
                    self.log(f"✅ Found existing site: {self.site_name}")
                    return site['site_id']
            
            # Site wasn't found, so create a new one
            self.log(f"🆕 Creating new site: {self.site_name}")
            
            # Prepare site creation data
            site_data = {
                'name': self.site_name,
            }
            
            # Add team if specified
            if self.team_name:
                site_data['account_slug'] = self.team_name
                
            # Create the site
            create_url = f"{NETLIFY_API_BASE}/sites"
            response = self.session.post(create_url, json=site_data, headers=self.headers)
            
            # Handle "subdomain must be unique" error specifically
            if response.status_code == 422 and "subdomain" in response.text and "unique" in response.text:
                import random
                import string
                
                # Generate a random suffix
                suffix = ''.join(random.choices(string.digits, k=4))
                modified_name = f"{self.site_name}-{suffix}"
                
                # Log the issue and suggest an alternative
                self.log(f"⚠️ Site name '{self.site_name}' is already taken")
                self.log(f"🔄 Trying with modified name: {modified_name}")
                
                # Update site data with new name
                site_data['name'] = modified_name
                
                # Try creating with the modified name
                response = self.session.post(create_url, json=site_data, headers=self.headers)
            
            if response.status_code not in [200, 201]:
                self.log(f"❌ Site creation failed - status: {response.status_code}, response: {response.text}")
                
                # More user-friendly error message for common errors
                if "subdomain" in response.text and "unique" in response.text:
                    raise ValueError("Site name is already taken. Please try a different, more unique name.")
                else:
                    raise ValueError(f"Failed to create site: {response.text}")
                
            new_site = response.json()
            site_url = new_site.get('ssl_url') or new_site.get('url')
            self.log(f"✅ Site created successfully: {site_url}")
            
            # If we used a modified name, inform the user
            if site_data['name'] != self.site_name:
                self.log(f"ℹ️ Note: Your site was created with a modified name: {site_data['name']}")
            
            return new_site['id']
            
        except Exception as e:
            self.log(f"❌ Site creation exception: {str(e)}")
            raise ValueError(f"Site creation failed: {str(e)}")

    def _emit_progress_to(self, target):
        # Helper to emit all progress values from current to target (inclusive) with a small delay for smooth animation
        import time
        for p in range(self.progress_bar_value + 1, target + 1):
            self.progress.emit(p)
            time.sleep(0.01)  # 10ms delay for smoothness
        self.progress_bar_value = target

    def run(self):
        self.progress_bar_value = 0
        try:
            # Network connectivity check
            try:
                requests.get(f'{NETLIFY_API_BASE}', timeout=5)
            except Exception:
                self.error.emit("Network unavailable: Please check your internet connection and try again.")
                return
            self.progress.emit(0)
            self.log("🚀 Starting deployment process...")
            self._emit_progress_to(5)
            # Verify token first
            auth_response = self.session.get(f'{NETLIFY_API_BASE}/user', headers=self.headers)
            if auth_response.status_code != 200:
                raise ValueError(f"Authentication failed: Please check your Netlify token (Status: {auth_response.status_code})")
            self._emit_progress_to(10)
            # Verify publish directory
            full_publish_path = os.path.abspath(os.path.join(self.project_path, self.publish_dir))
            self._verify_publish_directory(full_publish_path)
            self._emit_progress_to(15)
            # Create or get site with proper error handling
            site_id = None
            try:
                site_id = self._create_site()
            except Exception as e:
                self.log(f"⚠️ Site creation error: {str(e)}")
                raise
            if not site_id:
                raise ValueError("Failed to get or create site")
            self._emit_progress_to(20)
            # Get files information
            self.log("📋 Scanning and hashing files...")
            files_info, total_size = self._get_files_info(full_publish_path)
            self._emit_progress_to(25)
            # Create deploy (send file hashes)
            self.log("🌐 Creating deployment...")
            deploy_data = self._create_deploy(site_id, files_info)
            deploy_id = deploy_data['id']
            required_files = set(deploy_data.get('required', []))
            self._emit_progress_to(30)
            # Upload files
            uploaded_files = 0
            total_required = len([f for f in files_info if f['sha1'] in required_files])
            for file_info in files_info:
                if file_info['sha1'] in required_files:
                    self.log(f"📤 Uploading: {file_info['path']}")
                    self._upload_file(deploy_id, file_info)
                    uploaded_files += 1
                    # Progress: 30-90 for file uploads
                    if total_required > 0:
                        progress = 30 + int((uploaded_files / total_required) * 60)
                        self._emit_progress_to(progress)
                else:
                    self.log(f"✨ File already on CDN: {file_info['path']}")
            self._emit_progress_to(90)
            
            # Monitor deployment until completion
            self.log("⏳ Monitoring deployment status...")
            self._monitor_deployment(deploy_id)
            
        except Exception as e:
            self.error.emit(str(e))
        finally:
            self.session.close()
    
    def _upload_file(self, deploy_id, file_info):
        """Upload a single file to the deploy."""
        upload_url = f'{NETLIFY_API_BASE}/deploys/{deploy_id}/files/{file_info["path"]}'
        
        # Check if we have a processed version of the file content
        if file_info['full_path'] in self.processed_content:
            # Use processed content with watermarking instead of the original file
            content = self.processed_content[file_info['full_path']].encode('utf-8')
        else:
            # Use original file content
            with open(file_info['full_path'], 'rb') as f:
                content = f.read()
            
        headers = self.headers.copy()
        headers['Content-Type'] = MIME_TYPES.get(
            os.path.splitext(file_info['path'])[1].lower(),
            'application/octet-stream'
        )
        
        response = self.session.put(upload_url, headers=headers, data=content)
        if response.status_code not in [200, 201]:
            self.log(f"❌ File upload failed for {file_info['path']} - status: {response.status_code}, response: {response.text}")
            raise ValueError(f"Failed to upload {file_info['path']}: {response.text}")
    
    def _monitor_deployment(self, deploy_id):
        """Monitor the deployment status and update progress."""
        max_attempts = 180  # Increased from 60 to 180 (6 minutes instead of 2)
        attempt = 0
        site_url = None
        url_emitted = False
        max_new_state = 30  # Max number of 'new' state attempts before considering successful
        new_state_count = 0  # Counter for consecutive 'new' states
        
        # Get the initial status of deployment to force update
        status_url = f"{NETLIFY_API_BASE}/deploys/{deploy_id}"
        try:
            response = self.session.get(status_url, headers=self.headers, timeout=10)
            if response.status_code == 200:
                deploy_data = response.json()
                site_url = deploy_data.get('ssl_url') or deploy_data.get('url')
                if site_url:
                    self.log(f"🔗 Deployment URL: {site_url}")
                    url_emitted = True
        except Exception:
            # Continue if initial check fails
            pass
        
        while attempt < max_attempts:
            try:
                response = self.session.get(status_url, headers=self.headers, timeout=10)
                
                if response.status_code == 200:
                    deploy_data = response.json()
                    state = deploy_data.get('state', '')
                    site_url = deploy_data.get('ssl_url') or deploy_data.get('url')
                    
                    # As soon as we have a URL, show it to the user, even if deploy isn't ready
                    if site_url and not url_emitted:
                        self.log(f"🔗 Deployment URL: {site_url}")
                        url_emitted = True
                    
                    elapsed_time = int(time.time() - self.start_time)
                    time_str = self._format_time(elapsed_time)
                    
                    # Check for completed states
                    if state == 'ready':
                        self._emit_progress_to(100)
                        self.success.emit(f"✨ Deployment completed in {time_str}")
                        self.deployment_complete.emit(site_url)
                        return  # Exit immediately on success
                    elif state == 'error':
                        error_message = deploy_data.get('error_message', 'Unknown error')
                        error_details = ""
                        if 'error_details' in deploy_data:
                            error_details = f"\nDetails: {deploy_data['error_details']}"
                        raise ValueError(f"Deployment failed after {time_str}: {error_message}{error_details}")
                    else:
                        status_message = {
                            'new': 'Initializing deployment...',
                            'uploading': 'Processing uploads...',
                            'processing': 'Processing files...',
                            'preparing': 'Preparing CDN...',
                            'ready': 'Finalizing...',
                        }.get(state, f'Status: {state}')
                        
                        # More informative logging with detailed state and attempt count
                        self.log(f"⏳ {status_message} ({time_str}) [State: {state}, Attempt: {attempt+1}/{max_attempts}]")
                        
                        # Count consecutive 'new' states
                        if state == 'new':
                            new_state_count += 1
                            # If URL exists and new state persists too long, consider it successful
                            if site_url and new_state_count >= max_new_state:
                                self._emit_progress_to(100)
                                self.log(f"✅ Deployment has a valid URL but remained in 'new' state for {new_state_count} attempts.")
                                self.log(f"🔍 This is likely a Netlify API limitation. Your site is available at: {site_url}")
                                self.success.emit(f"✅ Deployment completed with URL: {site_url}")
                                self.deployment_complete.emit(site_url)
                                return
                        else:
                            new_state_count = 0  # Reset counter if state changes
                                
                        # Progress: 90-99 for monitoring, more gradual increase
                        # Ensure we reach 100% even if we exit with a partial success
                        if attempt > max_attempts - 10:
                            progress = 99  # Force near completion for final attempts
                        else:
                            progress = 90 + min(9, int((attempt / (max_attempts - 10)) * 9))
                        self._emit_progress_to(progress)
                else:
                    # Handle non-200 responses
                    self.log(f"⚠️ Netlify API returned status {response.status_code} while checking deployment. Response: {response.text}")
            except requests.RequestException as e:
                # Handle network errors gracefully
                self.log(f"⚠️ Network error while checking deployment status: {str(e)}")
                # Don't increment attempt on network errors to be more forgiving
                time.sleep(5)  # Longer delay on network errors
                continue
                
            attempt += 1
            time.sleep(2)
            
            # Every 30 attempts (1 minute), if we have a URL, let the user know it might be taking a while
            if attempt % 30 == 0 and site_url:
                self.log(f"⏳ Deployment is still processing... ({attempt}/{max_attempts} attempts)")
            
        # If we exit the loop due to max attempts - consider it a success if we have a URL
        if site_url:
            self._emit_progress_to(100)  # Force 100% on exit with URL
            self.log(f"✅ Deployment completed but might still be processing on Netlify servers")
            self.log(f"🔍 You can visit your site at: {site_url}")
            self.success.emit(f"✅ Deployment completed with URL: {site_url}")
            self.deployment_complete.emit(site_url)
            return
        
        # Only raise an error if we don't have a site URL at all
        raise ValueError("Deployment timed out: No URL was provided by Netlify after multiple attempts")
    
    def _verify_publish_directory(self, full_publish_path):
        """Verify that the publish directory exists and contains files."""
        # Check if the directory exists
        if not os.path.exists(full_publish_path):
            raise ValueError(f"Build directory not found: {full_publish_path}\nMake sure to build your project first.")
        
        # Check if the directory is a directory (not a file)
        if not os.path.isdir(full_publish_path):
            raise ValueError(f"Path exists but is not a directory: {full_publish_path}\nPlease specify a valid directory.")
        
        # Check if the directory has any files
        has_files = False
        for _, _, files in os.walk(full_publish_path):
            if files:
                has_files = True
                break
                
        if not has_files:
            raise ValueError(f"Build directory is empty: {full_publish_path}\nMake sure your project has been built successfully.")
        
        # Log success
        self.log(f"✅ Verified publish directory: {full_publish_path}")
        return True
    
    def log(self, message):
        """Emit a status message."""
        self.status.emit(message)
    
    def _format_time(self, seconds):
        """Format elapsed time into a human-readable string."""
        minutes = seconds // 60
        seconds = seconds % 60
        return f"{minutes}m {seconds}s" if minutes > 0 else f"{seconds}s"

class ModernFrame(QFrame):
    """A sophisticated frame with subtle elevation and hover effects."""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("Card")
        self.setStyleSheet(CARD_STYLE)
        
        # Add subtle shadow effect
        shadow = QGraphicsDropShadowEffect(self)
        shadow.setBlurRadius(20)
        shadow.setColor(QColor(0, 0, 0, 30))
        shadow.setOffset(0, 2)
        self.setGraphicsEffect(shadow)
        
        # Set minimum dimensions
        self.setMinimumHeight(120)
        
        # Create the main layout but don't set it
        self.main_layout = QVBoxLayout()
        self.main_layout.setContentsMargins(
            int(DESIGN['SPACING']['LG'].replace('px', '')),
            int(DESIGN['SPACING']['LG'].replace('px', '')),
            int(DESIGN['SPACING']['LG'].replace('px', '')),
            int(DESIGN['SPACING']['LG'].replace('px', ''))
        )
        self.main_layout.setSpacing(int(DESIGN['SPACING']['BASE'].replace('px', '')))

    def setLayout(self, layout):
        """Override setLayout to use our main_layout as a container."""
        self.main_layout.addLayout(layout)
        super().setLayout(self.main_layout)

    def addWidget(self, widget):
        """Convenience method to add widgets directly."""
        self.main_layout.addWidget(widget)

    def addLayout(self, layout):
        """Convenience method to add layouts directly."""
        self.main_layout.addLayout(layout)

    def paintEvent(self, event):
        """Custom paint event to add subtle gradient and border."""
        super().paintEvent(event)
        
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        
        # Create subtle gradient
        gradient = QLinearGradient(0, 0, 0, self.height())
        gradient.setColorAt(0, QColor(DESIGN['SURFACE']['CARD']))
        gradient.setColorAt(1, QColor(DESIGN['SURFACE']['MAIN']))
        
        painter.setBrush(gradient)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.drawRoundedRect(
            self.rect(),
            int(DESIGN['BORDER_RADIUS']['MD'].replace('px', '')),
            int(DESIGN['BORDER_RADIUS']['MD'].replace('px', ''))
        )

class SettingsDialog(QDialog):
    def __init__(self, parent=None, token='', team_name=''):
        super().__init__(parent)
        self.setWindowTitle("Netlify Deployer")
        self.setStyleSheet(GLASS_DIALOG_STYLE)
        self.setMinimumSize(600, 200)
        self.setMaximumSize(600, 200)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(32, 24, 32, 24)
        layout.setSpacing(18)
        self.token_input = QLineEdit()
        self.token_input.setEchoMode(QLineEdit.EchoMode.Password)
        self.token_input.setText(token)
        self.token_input.setStyleSheet("""
            background: #1e1e1e;
            border: 1px solid #333;
            color: #d4d4d4;
            padding: 6px 10px;
            min-width: 300px;
            max-width: 300px;
            font-size: 14px;
        """)
        token_field_wrapper = QWidget()
        token_field_layout = QVBoxLayout(token_field_wrapper)
        token_field_layout.setContentsMargins(10, 8, 10, 8)
        token_field_layout.setSpacing(0)
        token_field_layout.addWidget(self._labeled_field("Netlify Token (*):", self.token_input))
        layout.addWidget(token_field_wrapper)
        self.team_name_input = QLineEdit()
        self.team_name_input.setText(team_name)
        self.team_name_input.setStyleSheet("""
            background: #1e1e1e;
            border: 1px solid #333;
            color: #d4d4d4;
            padding: 6px 10px;
            min-width: 300px;
            max-width: 300px;
            font-size: 14px;
        """)
        team_field_wrapper = QWidget()
        team_field_layout = QVBoxLayout(team_field_wrapper)
        team_field_layout.setContentsMargins(10, 8, 10, 8)
        team_field_layout.setSpacing(0)
        team_field_layout.addWidget(self._labeled_field("Team Name (*):", self.team_name_input))
        layout.addWidget(team_field_wrapper)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        buttons.button(QDialogButtonBox.StandardButton.Save).setStyleSheet(
            "background: #0e639c; color: #fff; border-radius: 4px; padding: 6px 18px;")
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setStyleSheet(
            "background: #23272e; color: #d4d4d4; border-radius: 4px; padding: 6px 18px;")
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
    def _labeled_field(self, label, widget):
        container = QWidget()
        layout = QHBoxLayout(container)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)
        lbl = QLabel(label)
        lbl.setStyleSheet("color: #d4d4d4; font-size: 13px; min-width: 140px;")
        layout.addWidget(lbl)
        layout.addWidget(widget)
        return container
    def get_settings(self):
        return self.token_input.text(), self.team_name_input.text()



class DeploymentHistoryDialog(QDialog):
    def __init__(self, parent=None, history=None):
        super().__init__(parent)
        self.parent = parent
        self.history = history or []
        self.setWindowTitle("Deployment History")
        self.setMinimumSize(800, 500)
        self.setMaximumSize(800, 500)
        self.setup_ui()

    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)

        # Header with Clear History button
        header_layout = QHBoxLayout()
        
        header = QLabel("📋 Deployment History")
        header.setStyleSheet("""
            QLabel {
                color: #00c3ff;
                font-size: 18px;
                font-weight: bold;
                padding: 10px;
            }
        """)
        header_layout.addWidget(header)
        
        header_layout.addStretch()
        
        clear_history_btn = QPushButton("🗑️ Clear History")
        clear_history_btn.setStyleSheet("""
            QPushButton {
                background-color: #d32f2f;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 8px 16px;
                font-weight: bold;
                font-size: 13px;
            }
            QPushButton:hover {
                background-color: #f44336;
                border: 1px solid #ff5252;
            }
            QPushButton:pressed {
                background-color: #b71c1c;
            }
        """)
        clear_history_btn.clicked.connect(self.clear_history)
        header_layout.addWidget(clear_history_btn)
        
        layout.addLayout(header_layout)

        # Search and Filter Bar
        filter_layout = QHBoxLayout()
        filter_layout.setSpacing(12)  # Increased spacing between filter elements
        
        # Search box with increased size
        self.search_input = QLineEdit()
        self.search_input.setMinimumHeight(36)  # Increased height
        self.search_input.setPlaceholderText("Search deployments...")
        self.search_input.textChanged.connect(self.filter_history)
        self.search_input.setStyleSheet("""
            QLineEdit {
                padding: 8px 12px;
                border: 1px solid #333;
                border-radius: 4px;
                background: #2d2d2d;
                color: #fff;
                font-size: 13px;
            }
            QLineEdit:focus {
                border: 1px solid #00c3ff;
            }
        """)
        filter_layout.addWidget(self.search_input)

        # Status filter dropdown with increased size
        self.status_filter = QComboBox()
        self.status_filter.setMinimumHeight(36)  # Increased height
        self.status_filter.addItems(["All Status", "Success", "Failed"])
        self.status_filter.currentTextChanged.connect(self.filter_history)
        self.status_filter.setStyleSheet("""
            QComboBox {
                padding: 8px 12px;
                border: 1px solid #333;
                border-radius: 4px;
                background: #2d2d2d;
                color: #fff;
                min-width: 140px;
                font-size: 13px;
            }
            QComboBox:hover {
                border: 1px solid #00c3ff;
            }
            QComboBox::drop-down {
                border: none;
                padding-right: 8px;
            }
        """)
        filter_layout.addWidget(self.status_filter)

        # Date filter dropdown with increased size
        self.date_filter = QComboBox()
        self.date_filter.setMinimumHeight(36)  # Increased height
        self.date_filter.addItems(["All Time", "Today", "Last 7 Days", "Last 30 Days"])
        self.date_filter.currentTextChanged.connect(self.filter_history)
        self.date_filter.setStyleSheet(self.status_filter.styleSheet())
        filter_layout.addWidget(self.date_filter)

        layout.addLayout(filter_layout)

        # History Table
        self.table = QTableWidget()
        self.table.setColumnCount(6)
        self.table.setHorizontalHeaderLabels(["Date", "Time", "Site Name", "Status", "URL", "Actions"])
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.setStyleSheet("""
            QTableWidget {
                background-color: #1e1e1e;
                color: #d4d4d4;
                gridline-color: #333;
                border: none;
            }
            QTableWidget::item {
                padding: 8px;
            }
            QTableWidget::item:selected {
                background-color: #094771;
            }
            QHeaderView::section {
                background-color: #252526;
                color: #00c3ff;
                padding: 8px;
                border: none;
            }
        """)
        layout.addWidget(self.table)

        # Populate table
        self.populate_table()

        # Bottom buttons
        button_layout = QHBoxLayout()
        
        refresh_btn = QPushButton("🔄 Refresh")
        refresh_btn.clicked.connect(self.refresh_history)
        refresh_btn.setStyleSheet(self.get_button_style())
        button_layout.addWidget(refresh_btn)
        
        button_layout.addStretch()
        
        export_btn = QPushButton("📥 Export History")
        export_btn.clicked.connect(self.export_history)
        export_btn.setStyleSheet(self.get_button_style())
        button_layout.addWidget(export_btn)
        
        close_btn = QPushButton("Close")
        close_btn.clicked.connect(self.accept)
        close_btn.setStyleSheet(self.get_button_style())
        button_layout.addWidget(close_btn)
        
        layout.addLayout(button_layout)

    def get_button_style(self):
        return """
            QPushButton {
                background-color: #0e639c;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 8px 16px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #1177bb;
            }
            QPushButton:pressed {
                background-color: #0d5485;
            }
        """

    def populate_table(self, filtered_history=None):
        history_data = filtered_history if filtered_history is not None else self.history
        self.table.setRowCount(0)  # Clear existing rows
        
        for row, entry in enumerate(history_data):
            self.table.insertRow(row)
            
            # Parse timestamp
            timestamp = entry.get('timestamp', '')
            try:
                dt = datetime.strptime(timestamp, '%Y-%m-%d %H:%M:%S')
                date_str = dt.strftime('%Y-%m-%d')
                time_str = dt.strftime('%H:%M:%S')
            except:
                date_str = 'N/A'
                time_str = 'N/A'
            
            # Set cell items
            self.table.setItem(row, 0, QTableWidgetItem(date_str))
            self.table.setItem(row, 1, QTableWidgetItem(time_str))
            self.table.setItem(row, 2, QTableWidgetItem(entry.get('site_name', '')))
            
            # Status with color and tooltip
            status_item = QTableWidgetItem(entry.get('status', ''))
            status_item.setForeground(QColor('#00ff00') if entry.get('status') == 'success' else QColor('#ff0000'))
            status_item.setToolTip("Deployment completed successfully" if entry.get('status') == 'success' else "Deployment failed")
            self.table.setItem(row, 3, status_item)
            
            # Store site_id and deploy_id for rollback functionality
            if 'site_id' not in entry and 'site_name' in entry and hasattr(self.parent, 'feature_integration') and self.parent.has_feature_integration:
                if 'multisite' in self.parent.feature_integration.feature_managers:
                    multisite_manager = self.parent.feature_integration.feature_managers['multisite']
                    site = multisite_manager.site_manager.get_site(entry.get('site_name', ''))
                    if site and site.site_id:
                        entry['site_id'] = site.site_id
            
            # URL as clickable link with tooltip
            url = entry.get('url', '')
            url_item = QTableWidgetItem(url)
            url_item.setForeground(QColor('#00c3ff'))
            url_item.setToolTip(f"Click 'Visit Site' to open {url} in your browser")
            self.table.setItem(row, 4, url_item)
            
            # Actions cell with buttons
            actions_widget = QWidget()
            actions_layout = QHBoxLayout(actions_widget)
            actions_layout.setContentsMargins(8, 4, 8, 4)  # Increased horizontal margins
            actions_layout.setSpacing(16)  # Increased spacing between buttons
            
            # Info button
            info_btn = QPushButton("ℹ️")
            info_btn.setFixedSize(32, 32)  # Increased button size
            info_btn.setToolTip(
                f"Project Directory: {entry.get('project_dir', 'N/A')}\n"
                f"Publish Directory: {entry.get('publish_dir', 'N/A')}\n"
                f"Deployment Time: {timestamp}"
            )
            info_btn.setStyleSheet("""
                QPushButton {
                    background-color: #2d2d2d;
                    color: white;
                    border: none;
                    border-radius: 16px;
                    padding: 4px;
                    font-size: 16px;
                }
                QPushButton:hover {
                    background-color: #3d3d3d;
                    border: 1px solid #00c3ff;
                }
            """)
            info_btn.clicked.connect(lambda checked, e=entry: self.show_deployment_info(e))
            actions_layout.addWidget(info_btn)
            
            # Quick Redeploy button with enhanced tooltip
            redeploy_btn = QPushButton("🚀 Quick Redeploy")
            redeploy_btn.setFixedWidth(190)  # Set consistent width
            redeploy_btn.setMinimumHeight(32)  # Set minimum height
            redeploy_btn.setToolTip(
                "Quickly redeploy this site with the same settings:\n"
                f"• Site Name: {entry.get('site_name', 'N/A')}\n"
                f"• Project Dir: {entry.get('project_dir', 'N/A')}\n"
                f"• Publish Dir: {entry.get('publish_dir', 'N/A')}"
            )
            redeploy_btn.setStyleSheet("""
                QPushButton {
                    background-color: #0e639c;
                    color: white;
                    border: none;
                    border-radius: 4px;
                    padding: 5px 12px;
                    font-size: 13px;
                    text-align: center;
                }
                QPushButton:hover {
                    background-color: #1177bb;
                    border: 1px solid #00c3ff;
                }
                QPushButton:pressed {
                    background-color: #0d5485;
                }
            """)
            redeploy_btn.clicked.connect(lambda checked, e=entry: self.quick_redeploy(e))
            actions_layout.addWidget(redeploy_btn)
            
            # Visit Site button with enhanced tooltip
            visit_btn = QPushButton("🌐 Visit Site")
            visit_btn.setFixedWidth(120)  # Set fixed width
            visit_btn.setMinimumHeight(32)  # Set minimum height
            visit_btn.setToolTip(f"Open the deployed site in your browser:\n{url}")
            visit_btn.setStyleSheet("""
                QPushButton {
                    background-color: #23272e;
                    color: white;
                    border: none;
                    border-radius: 4px;
                    padding: 5px 12px;
                    font-size: 13px;
                    text-align: center;
                }
                QPushButton:hover {
                    background-color: #2c313a;
                    border: 1px solid #00c3ff;
                }
                QPushButton:pressed {
                    background-color: #1e2228;
                }
            """)
            visit_btn.clicked.connect(lambda checked, url=url: self.visit_site(url))
            actions_layout.addWidget(visit_btn)
            
            actions_layout.addStretch()  # Add stretch at the end to push buttons to the left
            self.table.setCellWidget(row, 5, actions_widget)

        # Adjust column widths
        self.table.resizeColumnsToContents()
        self.table.setColumnWidth(5, 400)  # Increased width for actions column to accommodate buttons
        
        # Set row heights
        for row in range(self.table.rowCount()):
            self.table.setRowHeight(row, 55)  # Increased row height for better button visibility

    def clear_history(self):
        """Clear the deployment history"""
        confirm = QMessageBox.question(
            self,
            "Confirm Clear History",
            "Are you sure you want to clear all deployment history?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        
        if confirm == QMessageBox.StandardButton.Yes:
            # Clear the history list
            self.history = []
            # Update the table
            self.populate_table()
            # Inform the parent to save the cleared history
            if hasattr(self.parent, 'save_deployment_history'):
                try:
                    # Pass clear_all=True to indicate this is a complete reset
                    self.parent.save_deployment_history("", "", "", clear_all=True)
                except Exception as e:
                    print(f"Error saving cleared history: {str(e)}")
            
            QMessageBox.information(
                self, 
                "History Cleared", 
                "Deployment history has been cleared successfully."
            )
    
    def filter_history(self):
        """Filter the deployment history based on search, status and date"""
        search_text = self.search_input.text().lower()
        status_filter = self.status_filter.currentText()
        date_filter = self.date_filter.currentText()
        
        filtered_history = []
        
        for entry in self.history:
            # Apply search filter
            if search_text:
                site_name = entry.get('site_name', '').lower()
                url = entry.get('url', '').lower()
                project_dir = entry.get('project_dir', '').lower()
                
                if (search_text not in site_name and 
                    search_text not in url and 
                    search_text not in project_dir):
                    continue
            
            # Apply status filter
            if status_filter != "All Status":
                entry_status = entry.get('status', '').lower()
                if status_filter.lower() != entry_status:
                    continue
            
            # Apply date filter
            if date_filter != "All Time":
                try:
                    timestamp = entry.get('timestamp', '')
                    dt = datetime.strptime(timestamp, '%Y-%m-%d %H:%M:%S')
                    today = datetime.now()
                    
                    if date_filter == "Today":
                        if dt.date() != today.date():
                            continue
                    elif date_filter == "Last 7 Days":
                        if (today - dt).days > 7:
                            continue
                    elif date_filter == "Last 30 Days":
                        if (today - dt).days > 30:
                            continue
                except Exception:
                    # Skip this entry if date parsing fails
                    continue
            
            # If it passed all filters, add to filtered list
            filtered_history.append(entry)
        
        # Update the table with filtered history
        self.populate_table(filtered_history)

    def quick_redeploy(self, entry):
        """Quick redeploy with the same settings"""
        try:
            # Fill the form fields with the saved configuration
            self.parent.project_dir.setText(entry.get('project_dir', ''))
            self.parent.publish_dir.setText(entry.get('publish_dir', ''))
            self.parent.site_name.setText(entry.get('site_name', ''))
            
            # Close the dialog
            self.accept()
            
            # Start the deployment
            QMessageBox.information(
                self.parent,
                "Quick Redeploy",
                f"Starting deployment for {entry.get('site_name', '')}",
                QMessageBox.StandardButton.Ok
            )
            self.parent.start_deployment()
        except Exception as e:
            QMessageBox.critical(
                self,
                "Error",
                f"Failed to redeploy: {str(e)}",
                QMessageBox.StandardButton.Ok
            )
    
    def visit_site(self, url):
        """Open the deployed site in the browser"""
        if url:
            QDesktopServices.openUrl(QUrl(url))

    def refresh_history(self):
        """Refresh the history from the parent"""
        try:
            if hasattr(self.parent, 'load_deployment_history'):
                self.history = self.parent.load_deployment_history()
                self.populate_table()
        except Exception as e:
            QMessageBox.critical(
                self,
                "Error",
                f"Failed to refresh history: {str(e)}",
                QMessageBox.StandardButton.Ok
            )
    
    def export_history(self):
        """Export the deployment history to CSV"""
        try:
            file_path, _ = QFileDialog.getSaveFileName(
                self,
                "Export Deployment History",
                "deployment_history.csv",
                "CSV Files (*.csv);;All Files (*)"
            )
            
            if file_path:
                with open(file_path, 'w', newline='') as f:
                    writer = csv.writer(f)
                    writer.writerow(['Date', 'Time', 'Site Name', 'Status', 'URL', 'Project Directory', 'Publish Directory'])
                    
                    for entry in self.history:
                        timestamp = entry.get('timestamp', '')
                        try:
                            dt = datetime.strptime(timestamp, '%Y-%m-%d %H:%M:%S')
                            date_str = dt.strftime('%Y-%m-%d')
                            time_str = dt.strftime('%H:%M:%S')
                        except:
                            date_str = 'N/A'
                            time_str = 'N/A'
                        
                        writer.writerow([
                            date_str,
                            time_str,
                            entry.get('site_name', ''),
                            entry.get('status', ''),
                            entry.get('url', ''),
                            entry.get('project_dir', ''),
                            entry.get('publish_dir', '')
                        ])
                
                QMessageBox.information(
                    self,
                    "Export Complete",
                    f"Deployment history exported to {file_path}",
                    QMessageBox.StandardButton.Ok
                )
        except Exception as e:
            QMessageBox.critical(
                self,
                "Export Error",
                f"Failed to export history: {str(e)}",
                QMessageBox.StandardButton.Ok
            )

    def show_deployment_info(self, entry):
        """Show detailed deployment information in a dialog."""
        info_dialog = QDialog(self)
        info_dialog.setWindowTitle("Deployment Details")
        info_dialog.setMinimumWidth(400)
        info_dialog.setStyleSheet("""
            QDialog {
                background-color: #1e1e1e;
                color: #d4d4d4;
            }
            QLabel {
                color: #d4d4d4;
                font-size: 13px;
                padding: 4px;
            }
            QLabel[heading="true"] {
                color: #00c3ff;
                font-weight: bold;
                font-size: 15px;
            }
        """)

        layout = QVBoxLayout(info_dialog)
        layout.setSpacing(10)
        layout.setContentsMargins(20, 20, 20, 20)

        # Add header
        header = QLabel("📋 Deployment Information")
        header.setProperty("heading", True)
        layout.addWidget(header)

        # Add info fields
        info_text = f"""
        <b>Site Name:</b> {entry.get('site_name', 'N/A')}
        <br><br>
        <b>Status:</b> <span style='color: {"#00ff00" if entry.get("status") == "success" else "#ff0000"};'>
            {entry.get('status', 'N/A').title()}
        </span>
        <br><br>
        <b>Deployment URL:</b> <a href='{entry.get("url", "#")}' style='color: #00c3ff;'>
            {entry.get('url', 'N/A')}
        </a>
        <br><br>
        <b>Project Directory:</b> {entry.get('project_dir', 'N/A')}
        <br><br>
        <b>Publish Directory:</b> {entry.get('publish_dir', 'N/A')}
        <br><br>
        <b>Deployment Time:</b> {entry.get('timestamp', 'N/A')}
        """

        info_label = QLabel(info_text)
        info_label.setTextFormat(Qt.TextFormat.RichText)
        info_label.setOpenExternalLinks(True)
        info_label.setWordWrap(True)
        layout.addWidget(info_label)

        # Add buttons
        button_layout = QHBoxLayout()
        
        close_btn = QPushButton("Close")
        close_btn.setStyleSheet("""
            QPushButton {
                background-color: #2d2d2d;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 8px 16px;
            }
            QPushButton:hover {
                background-color: #3d3d3d;
            }
        """)
        close_btn.clicked.connect(info_dialog.accept)
        button_layout.addStretch()
        button_layout.addWidget(close_btn)
        layout.addLayout(button_layout)

        info_dialog.exec()

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        # --- Security: Prompt for master password ---
        self.security = SecurityManager()
        self.persistent_token = ''  # Ensure always defined
        self.persistent_team = ''   # Ensure always defined
        # Initialize clipboard
        self.clipboard = QApplication.clipboard()
        
        # Initialize feature integration flag
        self.has_feature_integration = False
        
        password = self.prompt_for_password()
        self.security.load_key(password)
        self.master_password = password
        
        # Track recent files (maximum 5)
        self.recent_files = []
        self.max_recent_files = 5
        self.current_config_file = None  # Track current file path
        self.load_recent_files()

        # Project templates
        self.templates = []
        self.load_templates()

        # --- Build process tracking ---
        self.build_process = None
        self.build_commands = {
            "npm": {
                "build": "npm run build",
                "prod": "npm run build --production",
                "clean": "npm run clean"
            },
            "yarn": {
                "build": "yarn build",
                "prod": "yarn build --production",
                "clean": "yarn clean"
            },
            "vue": {
                "build": "vue-cli-service build",
                "prod": "vue-cli-service build --mode production",
                "clean": "rm -rf dist"
            },
            "react": {
                "build": "react-scripts build",
                "prod": "react-scripts build",
                "clean": "rm -rf build"
            },
            "angular": {
                "build": "ng build",
                "prod": "ng build --prod",
                "clean": "rm -rf dist"
            },
            "custom": {
                "build": "",
                "prod": "",
                "clean": ""
            }
        }
        self.current_build_type = "npm"  # Default build type

        # --- Main window setup ---
        self.setWindowTitle("Netlify Deployer")
        self.setGeometry(100, 100, 800, 600)
        self.setMinimumWidth(800)  # Set minimum width to prevent UI elements from being too cramped
        self.setMaximumWidth(800)  # Set minimum width to prevent UI elements from being too cramped
        # Set minimum and maximum height for the main window
        #self.setMinimumHeight(600)
        self.setMaximumHeight(600)
        self.setStyleSheet("""
            QMainWindow, QWidget {
                background: #1e1e1e;
                color: #d4d4d4;
                font-family: 'Segoe UI', 'Fira Mono', 'Consolas', monospace;
            }
        """)
        # Set window icon (cross-platform fallback)
        try:
            self.setWindowIcon(QIcon(":/icons/vscode.png"))
        except Exception:
            self.setWindowIcon(QIcon())

        # Add a menu bar with a Settings action
        menubar = self.menuBar()
        menubar.setStyleSheet("""
            QMenuBar {
                background-color: #242424;
                color: #dcdcdc;
                padding: 9px;
                font-size: 13px;
            }
            QMenuBar::item {
                background-color: transparent;
                padding: 8px 12px;
            }
            QMenuBar::item:selected {
                background-color: #2e2e2e;
            }
            QMenuBar::item:pressed {
                background-color: #0e639c;
            }
            QMenu {
                background-color: #252526;
                color: #cccccc;
                border: 1px solid #3c3c3c;
            }
            QMenu::item:selected {
                background-color: #094771;
            }
        """)
        
        # Add File menu
        file_menu = menubar.addMenu("&File")
        
        # New Configuration action
        new_config_action = QAction("New Configuration", self)
        new_config_action.setShortcut("Ctrl+N")
        new_config_action.triggered.connect(self.new_configuration)
        file_menu.addAction(new_config_action)
        
        # Open Configuration action
        open_config_action = QAction("Open Configuration", self)
        open_config_action.setShortcut("Ctrl+O")
        open_config_action.triggered.connect(self.open_configuration)
        file_menu.addAction(open_config_action)
        
        # Open Recent submenu
        self.recent_menu = QMenu("Open Recent", self)
        self.recent_menu.setStyleSheet(file_menu.styleSheet())
        file_menu.addMenu(self.recent_menu)
        self.update_recent_files_menu()
        
        # Save Configuration action
        save_config_action = QAction("Save Configuration", self)
        save_config_action.setShortcut("Ctrl+S")
        save_config_action.triggered.connect(self.save_configuration)
        file_menu.addAction(save_config_action)
        
        # Save Configuration As action
        save_as_config_action = QAction("Save Configuration As...", self)
        save_as_config_action.setShortcut("Ctrl+Shift+S")
        save_as_config_action.triggered.connect(self.save_configuration_as)
        file_menu.addAction(save_as_config_action)
        
        # Delete Configuration action
        delete_config_action = QAction("Delete Configuration", self)
        delete_config_action.triggered.connect(self.delete_configuration)
        file_menu.addAction(delete_config_action)
        
        # Add separator
        file_menu.addSeparator()
        
        # Exit action
        exit_action = QAction("Exit", self)
        exit_action.setShortcut("Alt+F4")
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)
        
        # Feature menus are now added after feature_integration initialization

        # Create Edit menu
        edit_menu = menubar.addMenu("&Edit")
        
        # Move Clear Log to Edit menu
        clear_log_action = QAction("Clear Log", self)
        clear_log_action.triggered.connect(self.clear_log)
        edit_menu.addAction(clear_log_action)
        
        # Add separator
        edit_menu.addSeparator()
        
        # Add Cut, Copy, Paste actions
        cut_action = QAction("Cut", self)
        cut_action.setShortcut("Ctrl+X")
        cut_action.triggered.connect(self.cut_to_clipboard)
        edit_menu.addAction(cut_action)
        
        copy_action = QAction("Copy", self)
        copy_action.setShortcut("Ctrl+C")
        copy_action.triggered.connect(self.copy_to_clipboard)
        edit_menu.addAction(copy_action)
        
        paste_action = QAction("Paste", self)
        paste_action.setShortcut("Ctrl+V")
        paste_action.triggered.connect(self.paste_from_clipboard)
        edit_menu.addAction(paste_action)
        
        # Create Build menu
        build_menu = menubar.addMenu("&Build")
        
        # Add build actions
        build_action = QAction("Build Project", self)
        build_action.setShortcut("Ctrl+B")
        build_action.triggered.connect(self.build_project)
        build_menu.addAction(build_action)
        
        prod_build_action = QAction("Production Build", self)
        prod_build_action.triggered.connect(self.build_production)
        build_menu.addAction(prod_build_action)
        
        build_menu.addSeparator()
        
        clean_build_action = QAction("Clean and Build", self)
        clean_build_action.triggered.connect(self.clean_and_build)
        build_menu.addAction(clean_build_action)
        
        build_menu.addSeparator()
        
        # Add configuration for build options
        build_settings_action = QAction("Configure Build Settings", self)
        build_settings_action.triggered.connect(self.configure_build_settings)
        build_menu.addAction(build_settings_action)
        
        self.stop_build_action = QAction("Stop Build", self)
        self.stop_build_action.setEnabled(False)
        self.stop_build_action.triggered.connect(self.stop_build)
        build_menu.addAction(self.stop_build_action)
        
        # Create Configuration menu
        config_menu = menubar.addMenu("&Configuration")
        
        # Move Settings under Configuration menu
        settings_menu = QMenu("&Settings", self)
        settings_menu.setStyleSheet(file_menu.styleSheet())
        open_settings_action = QAction("Netlify Configurations", self)
        open_settings_action.triggered.connect(self.open_settings_dialog)
        settings_menu.addAction(open_settings_action)
        config_menu.addMenu(settings_menu)
        
        # Move TOML configuration under Configuration menu
        toml_menu = QMenu("&TOML File Configuration", self)
        toml_menu.setStyleSheet(file_menu.styleSheet())
        open_toml_action = QAction("Edit netlify.toml Content", self)
        open_toml_action.triggered.connect(self.open_toml_dialog)
        toml_menu.addAction(open_toml_action)
        config_menu.addMenu(toml_menu)
        
        # Move Security under Configuration menu
        security_menu = QMenu("&Security", self)
        security_menu.setStyleSheet(file_menu.styleSheet())
        change_password_action = QAction("Change Management Password", self)
        change_password_action.triggered.connect(self.show_change_password_dialog)
        security_menu.addAction(change_password_action)
        config_menu.addMenu(security_menu)
        
        # Add Admin menu for security actions
        admin_menu = menubar.addMenu("&Admin")
        encrypt_env_action = QAction("Encrypt .env File", self)
        encrypt_env_action.triggered.connect(self.encrypt_env_dialog)
        admin_menu.addAction(encrypt_env_action)
        decrypt_env_action = QAction("Decrypt .env File", self)
        decrypt_env_action.triggered.connect(self.decrypt_env_dialog)
        admin_menu.addAction(decrypt_env_action)
        
        # Add separator before security options
        admin_menu.addSeparator()
        
        # Add Initialize USB Security Key action
        self.init_usb_key_action = QAction("Initialize USB Security Key", self)
        self.init_usb_key_action.triggered.connect(self.initialize_security_key)
        admin_menu.addAction(self.init_usb_key_action)
        
        # Add Verify Hardware Key action
        verify_key_action = QAction("Verify Hardware Key", self)
        verify_key_action.triggered.connect(self.verify_hardware_key)
        admin_menu.addAction(verify_key_action)

        # Create Help menu
        help_menu = menubar.addMenu("&Help")
        
        # Add History to Help menu
        history_help_action = QAction("History", self)
        history_help_action.triggered.connect(self.show_deployment_history)
        help_menu.addAction(history_help_action)
        
        # Add Report Bug action
        report_bug_action = QAction("Report Bug", self)
        report_bug_action.triggered.connect(self.report_bug)
        help_menu.addAction(report_bug_action)
        
        # Add Tutorial action
        tutorial_action = QAction("Tutorial", self)
        tutorial_action.triggered.connect(self.show_tutorial)
        help_menu.addAction(tutorial_action)
        
        # Add About action
        about_action = QAction("About", self)
        about_action.triggered.connect(self.show_about)
        help_menu.addAction(about_action)
        
        # Check if already initialized and disable button if so
        if SECURITY_FEATURES_AVAILABLE:
            try:
                from security_features import security_manager
                if security_manager.is_hardware_key_initialized():
                    self.init_usb_key_action.setEnabled(False)
                    self.init_usb_key_action.setToolTip("USB security key is already initialized")
            except Exception:
                pass
        
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        main_layout = QHBoxLayout(main_widget)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)
        content = QWidget()
        content_layout = QVBoxLayout(content)
        content_layout.setContentsMargins(40, 0, 40, 30)
        content_layout.setSpacing(18)
        main_layout.addWidget(content)
        card = QFrame()
        card.setObjectName("Card")
        card.setStyleSheet(GLASS_CARD_STYLE)
        card_layout = QVBoxLayout(card)
        card_layout.setSpacing(16)
        card_layout.setContentsMargins(32, 24, 32, 24)
        project_label = QLabel("Project Deploy Configuration")
        project_label.setStyleSheet("font-size: 15px;background-color: #242424; padding: 8px; color: #b5cea8; font-weight: 500; margin-bottom: 2px;")
        card_layout.addWidget(project_label)
        self.project_dir = QLineEdit()
        self.project_dir.setStyleSheet("background: #1e1e1e; border: 1px solid #333; border-radius: 4px; color: #d4d4d4; padding: 6px 10px; font-size: 14px;")
        browse_project = QPushButton(QIcon.fromTheme("folder-open"), "Browse")
        browse_project.setStyleSheet("""
            QPushButton {
                background: #21252b;
                color: #d4d4d4;
                border: none;
                border-radius: 4px;
                padding: 10px 16px;
            }
            QPushButton:hover {
                background: #2c2c32;
            }
        """)

        browse_project.clicked.connect(self.browse_project)
        project_dir_layout = QHBoxLayout()
        project_dir_layout.addWidget(self.project_dir)
        project_dir_layout.addWidget(browse_project)
        project_dir_widget = QWidget()
        project_dir_widget.setLayout(project_dir_layout)
        card_layout.addWidget(self._labeled_field("Project Directory:", project_dir_widget))
        self.publish_dir = QLineEdit()
        self.publish_dir.setPlaceholderText("e.g., dist, build, public")
        self.publish_dir.setStyleSheet("background: #1e1e1e; border: 1px solid #333; border-radius: 4px; color: #d4d4d4; padding: 6px 10px; font-size: 14px;")
        card_layout.addWidget(self._labeled_field("Publish Directory:", self.publish_dir))
        self.site_name = QLineEdit()
        self.site_name.setStyleSheet("background: #1e1e1e; border: 1px solid #333; border-radius: 4px; color: #d4d4d4; padding: 6px 10px; font-size: 14px;")
        card_layout.addWidget(self._labeled_field("Site Name:", self.site_name))
        # No team name field here

        # Deploy button (Rufus style, no unsupported CSS)
        self.deploy_button = QPushButton(QIcon.fromTheme("cloud-upload"), "Deploy Your Project to Netlify Now")
        self.deploy_button.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        self.deploy_button.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #23272e, stop:1 #23272e);
                color: #fff;
                border: 1.5px solid #23272e;
                border-radius: 8px;
                font-weight: 600;
                font-size: 16px;
                padding: 10px 0;
                letter-spacing: 0.5px;
            }
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #303030, stop:1 #303030);
                color: #fff;
                border: 1.5px solid #2f2f2f;
            }
            QPushButton:pressed {
                background: #1e3d6b;
                color: #fff;
            }
            QPushButton:disabled {
                background: #23272e;
                color: #888;
                border: 1.5px solid #23272e;
            }
        """)

        self.deploy_button.clicked.connect(self.start_deployment)
        card_layout.addWidget(self.deploy_button)
        # Progress bar layout (initially hidden)
        progress_layout = QHBoxLayout()
        self.progress_bar = QProgressBar()
        self.progress_bar.setTextVisible(True)
        self.progress_bar.setStyleSheet(PROGRESS_STYLE)
        self.progress_bar.setMinimumHeight(16)
        self.progress_bar.setMaximumHeight(24)
        progress_layout.addWidget(self.progress_bar)
        self.progress_widget = QWidget()  # Store as attribute for later
        self.progress_widget.setLayout(progress_layout)
        self.progress_widget.setVisible(False)  # Hide initially
        card_layout.addWidget(self.progress_widget)
        #card_layout.addSpacing(0)
        card.setLayout(card_layout)
        content_layout.addWidget(card)
        log_label = QLabel("Activity Status Log")
        log_label.setStyleSheet("font-size: 14px; color: #c586c0; font-weight: 500; background-color: #242424; padding: 12px;")
        content_layout.addWidget(log_label)
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setMinimumHeight(120)
        self.log_text.setStyleSheet(OUTPUT_SYNTAX_STYLE + OUTPUT_SCROLLBAR_STYLE)
        # Set minimum and maximum height for log_text
        self.log_text.setMinimumHeight(120)
        self.log_text.setMaximumHeight(200)
        content_layout.addWidget(self.log_text)
        self.load_settings()
        self.apply_persistent_settings()
        
        # Initialize feature integration (after log_text is created)
        self.has_feature_integration = False
        try:
            print("Attempting to import feature_integration...")
            from feature_integration import FeatureIntegration
            # Check if feature integration is enabled in settings
            if hasattr(self, 'settings') and self.settings.get('feature_integration_enabled', True):
                print("Feature integration enabled in settings")
                self.feature_integration = FeatureIntegration(self)
                self.has_feature_integration = True
                self.log_text.append("<span style='color: #569cd6;'>Feature integrations initialized successfully</span>")
                print("Feature integration initialized successfully")
                
                # Explicitly add the Features menu after initialization
                self.feature_integration.add_menus(self.menuBar())
            else:
                print("Feature integration disabled in settings")
                self.log_text.append("<span style='color: #dcdcaa;'>Feature integrations disabled in settings</span>")
        except ImportError as e:
            print(f"Error importing feature_integration: {str(e)}")
            self.log_text.append(f"<span style='color: #ce9178;'>Error loading feature integrations: {str(e)}</span>")
            self.has_feature_integration = False
        except Exception as e:
            print(f"Unexpected error initializing feature integration: {str(e)}")
            self.log_text.append(f"<span style='color: #ce9178;'>Unexpected error initializing feature integration: {str(e)}</span>")
            self.has_feature_integration = False
            
        print(f"Feature integration status: {self.has_feature_integration}")
        
        # Load TOML content from settings
        self.toml_content = self.settings.get('toml_content', '') if hasattr(self, 'settings') and 'toml_content' in self.settings else ''
        self.default_toml = self.toml_content or ''
        if not self.toml_content:
            self.toml_content = ''
            self.default_toml = ''

    def _labeled_field(self, label, widget):
        container = QWidget()
        layout = QHBoxLayout(container)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)
        lbl = QLabel(label)
        lbl.setStyleSheet("color: #d4d4d4; font-size: 13px; min-width: 140px;")
        layout.addWidget(lbl)
        layout.addWidget(widget)
        return container

    # --- Rate Limiting ---
    _api_request_times = []
    _deploy_request_times = []
    _deploy_day_counts = {}

    def _rate_limit_api(self):
        import time
        now = time.time()
        # Remove requests older than 60 seconds
        self._api_request_times = [t for t in self._api_request_times if now - t < 60]
        if len(self._api_request_times) >= API_RATE_LIMIT_PER_MINUTE:
            raise Exception(f"API rate limit exceeded: {API_RATE_LIMIT_PER_MINUTE} requests per minute. Please wait before retrying.")
        self._api_request_times.append(now)

    def _rate_limit_deploy(self):
        import time, datetime
        now = time.time()
        # Per-minute limit
        self._deploy_request_times = [t for t in self._deploy_request_times if now - t < 60]
        if len(self._deploy_request_times) >= DEPLOY_RATE_LIMIT_PER_MINUTE:
            raise Exception(f"Deployment rate limit exceeded: {DEPLOY_RATE_LIMIT_PER_MINUTE} deploys per minute. Please wait before retrying.")
        self._deploy_request_times.append(now)
        # Per-day limit
        today = datetime.date.today().isoformat()
        if today not in self._deploy_day_counts:
            self._deploy_day_counts = {today: 0}
        if self._deploy_day_counts[today] >= DEPLOY_RATE_LIMIT_PER_DAY:
            raise Exception(f"Daily deployment limit exceeded: {DEPLOY_RATE_LIMIT_PER_DAY} deploys per day. Please try again tomorrow.")
        self._deploy_day_counts[today] += 1

    def start_deployment(self):
        """Start the deployment process after validating inputs, ensuring rate limits, and checking security."""
        # Store current time for deployment history
        self.deployment_start_time = datetime.now()
        
        # First, check for hardware key security validation if enabled
        if SECURITY_FEATURES_AVAILABLE:
            try:
                from security_features import security_manager
                if not security_manager.is_admin_authenticated():
                    self.show_error("Security verification failed: USB security key is required for deployment.\n\nPlease insert the authorized USB security key and try again.")
                    self.deploy_button.setEnabled(True)  # Re-enable the button
                    return
                
                # Check if user has accepted the Terms of Service
                if not security_manager.legal.has_accepted_tos(getattr(self, "username", platform.node())):
                    # Show Terms of Service dialog
                    from tos_dialog import TermsOfServiceDialog
                    tos_text = security_manager.legal.get_tos_text()
                    tos_dialog = TermsOfServiceDialog(tos_text, self)
                    
                    if tos_dialog.exec() != QDialog.DialogCode.Accepted or not tos_dialog.was_accepted():
                        self.show_error("You must accept the Terms of Service before deployment.")
                        self.deploy_button.setEnabled(True)  # Re-enable the button
                        return
                    
                    # Record acceptance
                    security_manager.legal.accept_tos(getattr(self, "username", platform.node()))
                    self.log_text.append("✅ Terms of Service accepted")
            except Exception as e:
                self.show_error(f"Security verification error: {str(e)}\n\nCannot proceed with deployment.")
                self.deploy_button.setEnabled(True)  # Re-enable the button
                self.progress_widget.setVisible(False)  # Hide progress widget
                return
        
        # Basic input validation
        validation_error = self._validate_inputs()
        if validation_error is not None:
            self.show_error(validation_error)
            self.deploy_button.setEnabled(True)  # Re-enable the button
            self.progress_widget.setVisible(False)  # Hide progress widget
            return
        
        # Check API rate limits
        try:
            self._rate_limit_api()
        except Exception as e:
            self.show_error(str(e))
            self.deploy_button.setEnabled(True)  # Re-enable the button
            self.progress_widget.setVisible(False)  # Hide progress widget
            return
        
        # Check deployment rate limits
        try:
            self._rate_limit_deploy()
        except Exception as e:
            self.show_error(str(e))
            self.deploy_button.setEnabled(True)  # Re-enable the button
            self.progress_widget.setVisible(False)  # Hide progress widget
            return
        
        # Get absolute paths to project and publish directory
        try:
            project_path = os.path.abspath(self.project_dir.text())
            publish_dir = self.publish_dir.text()
            
            # Sanitize/validate paths for security
            try:
                publish_path = self.sanitize_path(project_path, publish_dir)
            except ValueError as e:
                self.show_error(f"Invalid publish directory path: {str(e)}")
                self.deploy_button.setEnabled(True)
                self.progress_widget.setVisible(False)
                return
                
        except Exception as e:
            self.show_error(f"Error resolving paths: {str(e)}")
            self.deploy_button.setEnabled(True)
            self.progress_widget.setVisible(False)
            return
        
        # Update UI immediately
        self.deploy_button.setEnabled(False)
        self.progress_widget.setVisible(True)
        self.update_progress(0)
        self.update_status("Starting deployment process...")
        
        # Create worker thread
        try:
            # Get the persistent token and team name values
            token = self.persistent_token
            if not token:
                self.show_error("Netlify API token is not configured. Please set it in Settings.")
                self.deploy_button.setEnabled(True)
                self.progress_widget.setVisible(False)
                return
                
            team_name = self.persistent_team
            site_name = self.site_name.text()
            
            # Trigger webhook notification for deployment started
            # Webhook notifications feature has been removed
            pass
            
            # Create and start worker thread
            self.worker = DeploymentWorker(token, project_path, self.publish_dir.text(), site_name, team_name)
            self.worker.progress.connect(self.update_progress)
            self.worker.status.connect(self.update_status)
            self.worker.error.connect(self.handle_error)
            self.worker.success.connect(self.handle_success)
            self.worker.deployment_complete.connect(self.deployment_complete)
            self.worker.start()
            
            # Store data needed for history later
            self.current_deploy = {
                "site_name": site_name,
                "project_path": project_path,
                "publish_dir": self.publish_dir.text(),
                "start_time": self.deployment_start_time.isoformat(),
                "status": "in_progress",
            }
        except Exception as e:
            self.show_error(f"Error starting deployment: {str(e)}")
            self.deploy_button.setEnabled(True)
            self.progress_widget.setVisible(False)

    def _validate_inputs(self):
        """Validate user inputs before starting deployment."""
        # Ensure project directory is specified and exists
        if not self.project_dir.text().strip():
            return "Project directory is required."
        
        project_path = os.path.abspath(self.project_dir.text())
        if not os.path.isdir(project_path):
            return f"Project directory does not exist: {project_path}"
        
        # Ensure read access to project directory
        if not os.access(project_path, os.R_OK):
            return f"Cannot read from project directory. Please check permissions."
        
        # Ensure publish directory is specified
        if not self.publish_dir.text().strip():
            return "Publish directory is required."
        
        # Ensure site name is specified
        if not self.site_name.text().strip():
            return "Site name is required."
        
        # Ensure site name does not contain invalid characters
        import re
        if not re.match(r'^[a-zA-Z0-9-]+$', self.site_name.text()):
            return "Site name can only contain letters, numbers, and hyphens."
        
        return None  # No validation errors

    def sanitize_path(self, base, path):
        # Prevent directory traversal
        full = os.path.abspath(os.path.join(base, path))
        if not full.startswith(os.path.abspath(base)):
            raise ValueError("Invalid path: directory traversal detected.")
        return full

    def save_deployment_history(self, site_name, url, status, error=None, deploy_id=None, clear_all=False):
        history_file = 'deploy_history.json'
        
        if clear_all:
            try:
                if os.path.exists(history_file):
                    # Create a backup before clearing
                    backup_file = f"{history_file}.bak"
                    if os.path.exists(backup_file):
                        os.remove(backup_file)
                    os.rename(history_file, backup_file)
                    
                with open(history_file, 'w') as f:
                    f.write('[]')
                return
            except Exception as e:
                self.log_text.append(f"<span style='color: #e74c3c;'>Error clearing history: {str(e)}</span>")
                return
        
        entry = {
            'site_name': site_name,
            'url': url,
            'status': status,
            'timestamp': time.strftime('%Y-%m-%d %H:%M:%S'),
            'project_dir': self.project_dir.text(),
            'publish_dir': self.publish_dir.text()
        }
        
        # Add deploy_id if available (needed for rollback)
        if deploy_id:
            entry['deploy_id'] = deploy_id
        
        # Add error if provided
        if error:
            entry['error'] = error
            
        try:
            data = []
            if os.path.exists(history_file):
                try:
                    with open(history_file, 'r') as f:
                        content = f.read().strip()
                        if content:
                            data = json.loads(content)
                except Exception as e:
                    self.log_text.append(f"<span style='color: #e74c3c;'>Error reading history: {str(e)}</span>")
                    # Create backup of corrupted file
                    if os.path.exists(history_file):
                        backup_file = f"{history_file}.corrupted"
                        try:
                            import shutil
                            shutil.copy2(history_file, backup_file)
                            self.log_text.append(f"<span style='color: #e74c3c;'>Created backup of corrupted history file: {backup_file}</span>")
                        except Exception as backup_err:
                            self.log_text.append(f"<span style='color: #e74c3c;'>Failed to create backup: {str(backup_err)}</span>")
            
            # Add new entry at the beginning
            data.insert(0, entry)
            
            # Limit history size to 100 entries
            if len(data) > 100:
                data = data[:100]
            
            # Use atomic write pattern with temporary file
            temp_file = f"{history_file}.tmp"
            with open(temp_file, 'w') as f:
                json.dump(data, f, indent=2)
                
            # Ensure the file is written completely before replacing the original
            os.replace(temp_file, history_file)
            
        except Exception as e:
            self.log_text.append(f"<span style='color: #e74c3c;'>Failed to save deployment history: {str(e)}</span>")

    def load_deployment_history(self):
        history_file = 'deploy_history.json'
        try:
            if os.path.exists(history_file):
                with open(history_file, 'r') as f:
                    encrypted = f.read()
                data = json.loads(self.security.decrypt(encrypted))
                return data
            else:
                return []
        except Exception as e:
            self.log_text.append(f"⚠️ Failed to load deployment history: {str(e)}")
            return []

    def show_deployment_history(self):
        history = self.load_deployment_history()
        dialog = DeploymentHistoryDialog(self, history)
        dialog.exec()

    def deployment_complete(self, url):
        """Handle deployment completion."""
        try:
            self.deploy_button.setEnabled(True)
            self.deploy_button.setText("Deploy Your Project to Netlify Now")  # Reset button text
            self.deploy_button.setIcon(QIcon.fromTheme("cloud-upload"))  # Restore icon
            self.progress_widget.setVisible(False)  # Hide progress bar
            self.progress_bar.setValue(0)
            
            if url:  # Only proceed if URL is not None
                self.log_text.append(f"🌎 Project deployed successfully to: {url}")
                
                # Extract deploy_id from URL
                deploy_id = None
                try:
                    if '--' in url:
                        deploy_id = url.split('//')[1].split('--')[0]
                        print(f"Extracted deploy_id from URL: {deploy_id}")
                    # Try alternative extraction methods if the standard approach fails
                    elif '/' in url:
                        # Look for deploy ID in URL segments
                        url_parts = url.replace('https://', '').replace('http://', '').split('/')
                        for part in url_parts:
                            if len(part) >= 12 and not part.startswith('www.'):
                                deploy_id = part
                                print(f"Extracted possible deploy_id from URL path: {deploy_id}")
                                break
                except Exception as e:
                    print(f"Error extracting deploy_id: {str(e)}")
                
                message_box = QMessageBox()
                message_box.setWindowTitle("✅ Deployment Complete")
                message_box.setText(f"<b style='color:#00c3ff;'>Your project has been successfully deployed to Netlify!</b><br><br>"
                                f"<span style='color:#aaa;'>It is available at:</span><br>"
                                f"<a href='{url}' style='color:#00c3ff;'>{url}</a>")
                message_box.setStandardButtons(QMessageBox.StandardButton.Ok)
                message_box.setTextFormat(Qt.TextFormat.RichText)
                message_box.setStyleSheet("""
                    QMessageBox {
                        background-color: #23272e;
                        color: #fff;
                        font-size: 14px;
                        font-family: 'Segoe UI', sans-serif;
                    }
                    QPushButton {
                        background-color: #3794ff;
                        color: white;
                        padding: 6px 12px;
                        border: none;
                        border-radius: 6px;
                        font-weight: bold;
                    }
                    QPushButton:hover {
                        background-color: #00c3ff;
                    }
                """)
                message_box.exec()
                
                # Save to deployment history with deploy_id
                self.save_deployment_history(self.site_name.text(), url, 'success', deploy_id=deploy_id)
                
                # Update multisite manager if available
                if self.has_feature_integration and 'multisite' in self.feature_integration.feature_managers:
                    try:
                        multisite_manager = self.feature_integration.feature_managers['multisite']
                        
                        # Get site_id if available
                        site_id = None
                        site = multisite_manager.site_manager.get_site(self.site_name.text())
                        if site:
                            site_id = site.site_id
                        
                        # Create extra data for deployment history
                        extra_data = {
                            "deploy_id": deploy_id,
                            "site_id": site_id
                        }
                        
                        # Update deployment history
                        multisite_manager.update_deployment_history(
                            self.site_name.text(), 
                            "success", 
                            url, 
                            extra_data=extra_data
                        )
                    except Exception as e:
                        print(f"Error updating multisite manager: {str(e)}")
                
                # Webhook notifications functionality has been removed
            else:
                self.log_text.append("⚠️ Deployment completed but no URL was returned")
        except Exception as e:
            self.log_text.append(f"⚠️ Error in deployment completion: {str(e)}")

    
    def show_error(self, message):
        """Show an error message dialog with the given message."""
        # Convert boolean values to strings to prevent QMessageBox.critical errors
        if isinstance(message, bool):
            message = str(message)
        elif message is None:
            message = "An unknown error occurred"
            
        QMessageBox.critical(self, "Error", message)

    def save_persistent_settings(self):
        # Save persistent token and team name (do NOT encrypt)
        try:
            # Create settings directory if it doesn't exist
            settings_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'settings')
            os.makedirs(settings_dir, exist_ok=True)
            
            # Save to file
            settings_file = os.path.join(settings_dir, 'persistent_settings.json')
            
            # Use atomic write pattern with temporary file
            temp_file = f"{settings_file}.tmp"
            with open(temp_file, 'w') as f:
                json.dump({
                    'token': self.persistent_token,
                    'team_name': self.persistent_team
                }, f, indent=2)
                
            # Ensure the file is written completely before replacing the original
            os.replace(temp_file, settings_file)
            
            # Set strict permissions on the settings file
            try:
                # On Unix-like systems, set read/write for owner only
                if hasattr(os, 'chmod'):
                    import stat
                    os.chmod(settings_file, stat.S_IRUSR | stat.S_IWUSR)
            except Exception as e:
                print(f"Warning: Could not set strict permissions on settings file: {e}")
                
        except Exception as e:
            print(f"Error saving persistent settings: {e}")
            self.log_text.append(f"⚠️ Failed to save settings: {str(e)}")

    def open_settings_dialog(self):
        """Open settings dialog to configure API token and team name."""
        # Create and show settings dialog
        dialog = SettingsDialog(self, self.persistent_token, self.persistent_team)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            token, team_name = dialog.get_settings()
            
            # Validate token (ensure it's not empty and has a reasonable format)
            if not token:
                self.log_text.append("⚠️ API token not provided. Some functionality may be limited.")
            elif len(token) < 10:
                self.log_text.append("⚠️ API token appears to be too short. Please check your token.")
            
            # Store token and team name in memory and on disk
            self.persistent_token = token
            self.persistent_team = team_name
            self.save_persistent_settings()
            
            self.log_text.append("✅ Settings updated")

    def apply_persistent_settings(self):
        # No UI fields to update; persistent values are used only for deployment and settings dialog
        pass

    def open_toml_dialog(self):
        # Always use the latest decrypted toml_content
        toml_content = self.toml_content
        # If toml_content is still encrypted, try to decrypt it
        try:
            # Try to detect if it's encrypted (Fernet tokens are base64, start with 'gAAAA')
            if toml_content and toml_content.startswith('gAAAA'):
                toml_content = self.security.decrypt(toml_content)
        except Exception:
            pass  # If decryption fails, show as is
        # Use self.TomlConfigDialog to avoid undefined variable error
        dlg = self.TomlConfigDialog(self, toml_content)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            self.toml_content = dlg.get_toml()
            self.save_settings()  # Save to netlify_config.json

    def prompt_for_password(self):
        dlg = PasswordDialog()
        if dlg.exec() == QDialog.DialogCode.Accepted:
            return dlg.get_password()
        else:
            sys.exit(0)

    def clear_log(self):
        self.log_text.clear()

    def browse_project(self):
        """Open a directory browser dialog for project directory selection."""
        directory = QFileDialog.getExistingDirectory(
            self,
            "Select Project Directory",
            os.path.expanduser("~"),  # Start from user's home directory
            QFileDialog.Option.ShowDirsOnly
        )
        if directory:
            self.project_dir.setText(directory)
            # Auto-detect common publish directories
            common_dirs = ['dist', 'build', 'public', 'out', '_site']
            for dir_name in common_dirs:
                if os.path.exists(os.path.join(directory, dir_name)):
                    self.publish_dir.setText(dir_name)
                    break

    def load_settings(self):
        # Directory where all settings are stored
        settings_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'settings')
        os.makedirs(settings_dir, exist_ok=True)
        config_path = os.path.join(settings_dir, 'app_settings.json')
        
        if not os.path.exists(config_path):
            # Create default settings
            self.settings = {
                'persistent_token': '',
                'persistent_team': '',
                'recent_files': [],
                'toml_content': '',
                'build_type': 'npm',
                'custom_commands': {}
            }
            # Save default settings
            with open(config_path, 'w') as f:
                json.dump(self.settings, f, indent=4)
        else:
            # Load settings
            with open(config_path, 'r') as f:
                try:
                    self.settings = json.load(f)
                except json.JSONDecodeError:
                    # If file is corrupted, create new settings
                    self.settings = {
                        'persistent_token': '',
                        'persistent_team': '',
                        'recent_files': [],
                        'toml_content': '',
                        'build_type': 'npm',
                        'custom_commands': {}
                    }
        
        # Update recent files from settings
        if 'recent_files' in self.settings:
            self.recent_files = self.settings['recent_files']
        
        # Update build type from settings
        if 'build_type' in self.settings:
            self.current_build_type = self.settings['build_type']
        
        # Update custom commands from settings
        if 'custom_commands' in self.settings and self.settings['custom_commands']:
            self.build_commands['custom'] = self.settings['custom_commands']

    def save_settings(self):
        """Save current settings to a configuration file, do NOT encrypt any fields."""
        settings = {
            'project_dir': self.project_dir.text(),
            'publish_dir': self.publish_dir.text(),
            'site_name': self.site_name.text(),
            'token': self.persistent_token,
            'team_name': self.persistent_team,
            'toml_content': self.toml_content,
            'build_type': self.current_build_type,
            'build_commands': {
                'custom': self.build_commands.get('custom', {})  # Only save custom commands
            }
        }
        try:
            with open('netlify_config.json', 'w') as f:
                json.dump(settings, f)
        except Exception as e:
            self.log_text.append(f"⚠️ Failed to save settings: {str(e)}")

    def update_progress(self, value):
        self.progress_bar.setValue(value)

    def update_status(self, message):
        self.log_text.append(message)

    def handle_error(self, message):
        """Handle error messages from worker thread"""
        self.log_text.append(f"<span style='color: #e74c3c;'>{message}</span>")
        self.deploy_button.setEnabled(True)
        self.progress_widget.setVisible(False)
        
        # Save failed deployment to history
        if hasattr(self, 'current_deploy'):
            self.current_deploy["status"] = "failed"
            self.current_deploy["end_time"] = datetime.now().isoformat()
            self.current_deploy["error"] = message
            self.save_deployment_history(
                self.current_deploy["site_name"],
                "", # No URL for failed deployments
                "failed",
                error=message
            )
            
        # Webhook notifications feature has been removed

    def handle_success(self, message):
        """Handle success messages from worker thread"""
        self.log_text.append(f"<span style='color: #2ecc71;'>{message}</span>")

    def show_change_password_dialog(self):
        """Show dialog to change the master password."""
        dialog = self.ChangePasswordDialog(self)
        dialog.exec()
        
    # Create a nested ChangePasswordDialog class inside MainWindow to avoid undefined variable errors
    class ChangePasswordDialog(QDialog):
        """Dialog for changing the master password."""
        
        def __init__(self, parent=None):
            super().__init__(parent)
            self.parent = parent
            self.setWindowTitle("Change Master Password")
            self.setMinimumSize(450, 320)
            self.setStyleSheet(GLASS_DIALOG_STYLE)
            
            layout = QVBoxLayout(self)
            layout.setContentsMargins(24, 24, 24, 24)
            layout.setSpacing(15)
            
            # Current password field
            self.current_password = QLineEdit()
            self.current_password.setEchoMode(QLineEdit.EchoMode.Password)
            self.current_password.setPlaceholderText("Enter current password")
            self.current_password.setStyleSheet("""
                background: #1e1e1e;
                border: 1px solid #333;
                border-radius: 4px;
                color: #d4d4d4;
                padding: 10px;
                font-size: 14px;
            """)
            
            # New password field
            self.new_password = QLineEdit()
            self.new_password.setEchoMode(QLineEdit.EchoMode.Password)
            self.new_password.setPlaceholderText("Enter new password")
            self.new_password.setStyleSheet(self.current_password.styleSheet())
            
            # Confirm password field
            self.confirm_password = QLineEdit()
            self.confirm_password.setEchoMode(QLineEdit.EchoMode.Password)
            self.confirm_password.setPlaceholderText("Confirm new password")
            self.confirm_password.setStyleSheet(self.current_password.styleSheet())
            
            # Add fields with labels
            layout.addWidget(QLabel("Current Password:"))
            layout.addWidget(self.current_password)
            layout.addWidget(QLabel("New Password:"))
            layout.addWidget(self.new_password)
            layout.addWidget(QLabel("Confirm New Password:"))
            layout.addWidget(self.confirm_password)
            
            # Error message label (hidden initially)
            self.error_label = QLabel("")
            self.error_label.setStyleSheet("""
                color: #ff5252;
                font-size: 13px;
                padding: 5px;
            """)
            self.error_label.setWordWrap(True)
            self.error_label.hide()
            layout.addWidget(self.error_label)
            
            # Button layout
            button_layout = QHBoxLayout()
            button_layout.setSpacing(10)
            
            # Cancel button
            cancel_btn = QPushButton("Cancel")
            cancel_btn.setStyleSheet("""
                background-color: #2d2d2d;
                color: #cccccc;
                border: none;
                padding: 10px 20px;
                border-radius: 4px;
            """)
            cancel_btn.clicked.connect(self.reject)
            
            # Change button
            change_btn = QPushButton("Change Password")
            change_btn.setStyleSheet("""
                background-color: #0078d4;
                color: white;
                border: none;
                padding: 10px 20px;
                border-radius: 4px;
            """)
            change_btn.clicked.connect(self.change_password)
            
            button_layout.addStretch()
            button_layout.addWidget(cancel_btn)
            button_layout.addWidget(change_btn)
            
            layout.addLayout(button_layout)
        
        def change_password(self):
            """Validate inputs and change the password if valid."""
            current = self.current_password.text()
            new_pwd = self.new_password.text()
            confirm = self.confirm_password.text()
            
            # Validate current password
            try:
                ph.verify(MASTER_PASSWORD_HASH, current)
            except argon2_exceptions.VerifyMismatchError:
                self.show_error("Current password is incorrect")
                return
            
            # Validate new password
            if not new_pwd:
                self.show_error("New password cannot be empty")
                return
            
            if len(new_pwd) < 8:
                self.show_error("New password must be at least 8 characters long")
                return
                
            if new_pwd != confirm:
                self.show_error("New passwords do not match")
                return
            
            # Generate new hash and save
            try:
                # Update environment variable
                new_hash = ph.hash(new_pwd)
                os.environ['MASTER_PASSWORD_HASH'] = new_hash
                
                # Update .env file if it exists
                env_file = '.env'
                if os.path.exists(env_file):
                    lines = []
                    with open(env_file, 'r') as f:
                        for line in f:
                            if line.startswith('MASTER_PASSWORD_HASH='):
                                lines.append(f'MASTER_PASSWORD_HASH={new_hash}\n')
                            else:
                                lines.append(line)
                    
                    with open(env_file, 'w') as f:
                        f.writelines(lines)
                        
                # Update parent's security manager
                if self.parent:
                    self.parent.security.load_key(new_pwd)
                    self.parent.master_password = new_pwd
                    
                QMessageBox.information(
                    self,
                    "Success",
                    "Password has been changed successfully"
                )
                self.accept()
                
            except Exception as e:
                self.show_error(f"Failed to change password: {str(e)}")
        
        def show_error(self, message):
            """Show error message in the dialog."""
            # Convert boolean values to strings to prevent errors
            if isinstance(message, bool):
                message = str(message)
            elif message is None:
                message = "An unknown error occurred"
                
            self.error_label.setText(message)
            self.error_label.show()

    def new_configuration(self):
        """Reset all configuration fields to their default values."""
        reply = QMessageBox.question(
            self, 
            "New Configuration", 
            "This will clear all current settings. Are you sure?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No
        )
        
        if reply == QMessageBox.StandardButton.Yes:
            self.project_dir.clear()
            self.publish_dir.clear()
            self.site_name.clear()
            self.persistent_token = ''
            self.persistent_team = ''
            self.toml_content = ''
            self.current_config_file = None
            self.update_window_title()
            
            self.log_text.append("✨ Created new configuration")
    
    def open_configuration(self):
        """Open a configuration file."""
        file_name, _ = QFileDialog.getOpenFileName(
            self,
            "Open Configuration",
            "",
            "JSON Files (*.json);;All Files (*)"
        )
        
        if file_name:
            try:
                with open(file_name, 'r') as f:
                    settings = json.load(f)
                
                self.project_dir.setText(settings.get('project_dir', ''))
                self.publish_dir.setText(settings.get('publish_dir', ''))
                self.site_name.setText(settings.get('site_name', ''))
                self.persistent_token = settings.get('token', '')
                self.persistent_team = settings.get('team_name', '')
                self.toml_content = settings.get('toml_content', '')
                
                # Set current config file path
                self.current_config_file = file_name
                self.update_window_title()
                
                self.log_text.append(f"📂 Opened configuration from: {file_name}")
                
                # Add to recent files
                self.add_to_recent_files(file_name)
            except Exception as e:
                QMessageBox.critical(
                    self,
                    "Error Opening Configuration",
                    f"Failed to open configuration: {str(e)}"
                )
    
    def save_configuration(self):
        """Save configuration to the current file or prompt for new file."""
        if self.current_config_file:
            self._save_to_file(self.current_config_file)
        else:
            self.save_configuration_as()
    
    def save_configuration_as(self):
        """Save configuration to a file chosen by the user."""
        file_name, _ = QFileDialog.getSaveFileName(
            self,
            "Save Configuration As",
            "",
            "JSON Files (*.json);;All Files (*)"
        )
        
        if file_name:
            if not file_name.endswith('.json'):
                file_name += '.json'
            
            # Save to the file and update current file
            self._save_to_file(file_name)
            self.current_config_file = file_name
            self.update_window_title()
    
    def _save_to_file(self, file_path):
        """Helper method to save configuration to a specific file."""
        settings = {
            'project_dir': self.project_dir.text(),
            'publish_dir': self.publish_dir.text(),
            'site_name': self.site_name.text(),
            'token': self.persistent_token,
            'team_name': self.persistent_team,
            'toml_content': self.toml_content,
        }
        
        try:
            with open(file_path, 'w') as f:
                json.dump(settings, f, indent=2)
            
            self.log_text.append(f"💾 Saved configuration to: {file_path}")
            
            # Add to recent files
            self.add_to_recent_files(file_path)
        except Exception as e:
            QMessageBox.critical(
                self,
                "Error Saving Configuration",
                f"Failed to save configuration: {str(e)}"
            )

    def load_recent_files(self):
        """Load the list of recent files from settings."""
        try:
            # Check if app_settings.json exists
            if os.path.exists('app_settings.json'):
                with open('app_settings.json', 'r') as f:
                    app_settings = json.load(f)
                    self.recent_files = app_settings.get('recent_files', [])
        except Exception as e:
            print(f"Error loading recent files: {str(e)}")
            self.recent_files = []
    
    def save_recent_files(self):
        """Save the list of recent files to settings."""
        try:
            # Load existing app settings if available
            app_settings = {}
            if os.path.exists('app_settings.json'):
                with open('app_settings.json', 'r') as f:
                    app_settings = json.load(f)
            
            # Update recent files
            app_settings['recent_files'] = self.recent_files
            
            # Save back to file
            with open('app_settings.json', 'w') as f:
                json.dump(app_settings, f, indent=2)
        except Exception as e:
            print(f"Error saving recent files: {str(e)}")
    
    def add_to_recent_files(self, file_path):
        """Add a file to the recent files list."""
        # Remove if already exists (to move it to the top)
        try:
            if file_path in self.recent_files:
                self.recent_files.remove(file_path)
        except Exception as e:
            print(f"Error removing existing file from recent files: {str(e)}")
        
        # Add to the beginning of the list
        self.recent_files.insert(0, file_path)
        
        # Limit to max number of recent files
        self.recent_files = self.recent_files[:self.max_recent_files]
        
        # Save the updated list
        self.save_recent_files()
        
        # Update the menu
        self.update_recent_files_menu()
    
    def update_recent_files_menu(self):
        """Update the Open Recent submenu with the list of recent files."""
        self.recent_menu.clear()
        
        if not self.recent_files:
            no_recent_action = QAction("No Recent Files", self)
            no_recent_action.setEnabled(False)
            self.recent_menu.addAction(no_recent_action)
            return
        
        for file_path in self.recent_files:
            # Use the file name as display text, but store the full path
            file_name = os.path.basename(file_path)
            action = QAction(file_name, self)
            action.setStatusTip(file_path)
            action.triggered.connect(lambda checked, path=file_path: self.open_recent_file(path))
            self.recent_menu.addAction(action)
        
        self.recent_menu.addSeparator()
        clear_action = QAction("Clear Recent Files", self)
        clear_action.triggered.connect(self.clear_recent_files)
        self.recent_menu.addAction(clear_action)
    
    def open_recent_file(self, file_path):
        """Open a configuration file from the recent files list."""
        if not os.path.exists(file_path):
            QMessageBox.warning(
                self,
                "File Not Found",
                f"The file {file_path} no longer exists."
            )
            # Remove from recent files (safely)
            try:
                if file_path in self.recent_files:
                    self.recent_files.remove(file_path)
                    self.save_recent_files()
                    self.update_recent_files_menu()
            except Exception as e:
                print(f"Error removing file from recent files: {str(e)}")
            return
        
        try:
            with open(file_path, 'r') as f:
                settings = json.load(f)
            
            self.project_dir.setText(settings.get('project_dir', ''))
            self.publish_dir.setText(settings.get('publish_dir', ''))
            self.site_name.setText(settings.get('site_name', ''))
            self.persistent_token = settings.get('token', '')
            self.persistent_team = settings.get('team_name', '')
            self.toml_content = settings.get('toml_content', '')
            
            self.log_text.append(f"📂 Opened configuration from: {file_path}")
            
            # Set current config file path
            self.current_config_file = file_path
            self.update_window_title()
            
            # Add to recent files (will move it to the top if it already exists)
            self.add_to_recent_files(file_path)
        except Exception as e:
            QMessageBox.critical(
                self,
                "Error Opening Configuration",
                f"Failed to open configuration: {str(e)}"
            )
    
    def clear_recent_files(self):
        """Clear the list of recent files."""
        self.recent_files = []
        self.save_recent_files()
        self.update_recent_files_menu()
        self.log_text.append("🧹 Cleared recent files list")
    
    def report_bug(self):
        """Opens a dialog to report a bug"""
        import webbrowser
        QMessageBox.information(
            self,
            "Report Bug",
            "You'll be redirected to the bug reporting form in your web browser."
        )
        # Replace with your actual bug reporting URL
        webbrowser.open("https://github.com/yourusername/netlify-deployer/issues/new")
    
    def show_tutorial(self):
        """Shows a tutorial dialog with instructions on how to use the application"""
        tutorial_dialog = QDialog(self)
        tutorial_dialog.setWindowTitle("Netlify Deployer Tutorial")
        tutorial_dialog.setMinimumSize(700, 500)
        
        layout = QVBoxLayout(tutorial_dialog)
        
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setStyleSheet("""
            QScrollArea {
                border: none;
                background-color: #1e1e1e;
            }
        """)
        
        tutorial_content = QWidget()
        tutorial_layout = QVBoxLayout(tutorial_content)
        
        # Add tutorial content
        title = QLabel("Netlify Deployer Tutorial")
        title.setStyleSheet("""
            font-size: 24px;
            color: #00c3ff;
            font-weight: bold;
            padding-bottom: 20px;
        """)
        tutorial_layout.addWidget(title)
        
        sections = [
            ("Getting Started", """
            <p>Welcome to Netlify Deployer, a desktop application for easily deploying your website to Netlify.</p>
            <p>To get started, you'll need to:</p>
            <ol>
                <li>Configure your Netlify API token in Settings</li>
                <li>Select your project directory</li>
                <li>Specify the publish directory (e.g., dist, build, public)</li>
                <li>Enter a unique site name for your Netlify site</li>
            </ol>
            """),
            
            ("Configuration Options", """
            <p>Use the Configuration menu to:</p>
            <ul>
                <li>Set up your Netlify API token and team name</li>
                <li>Edit your netlify.toml file for custom site settings</li>
                <li>Manage security settings</li>
            </ul>
            """),
            
            ("Deployment Process", """
            <p>Click the "Deploy Your Project to Netlify Now" button to start the deployment process.</p>
            <p>The application will:</p>
            <ol>
                <li>Scan and hash your files for efficient deployments</li>
                <li>Upload only changed files to Netlify</li>
                <li>Monitor deployment status</li>
                <li>Provide you with a URL to your deployed site</li>
            </ol>
            """),
            
            ("Managing Deployments", """
            <p>Use the History menu to view past deployments, including:</p>
            <ul>
                <li>Deployment timestamps</li>
                <li>Site names and URLs</li>
                <li>Success/failure status</li>
                <li>Quick redeploy options</li>
            </ul>
            """)
        ]
        
        for title, content in sections:
            section_title = QLabel(title)
            section_title.setStyleSheet("""
                font-size: 18px;
                color: #00c3ff;
                font-weight: bold;
                padding-top: 10px;
            """)
            
            section_content = QLabel()
            section_content.setText(content)
            section_content.setWordWrap(True)
            section_content.setTextFormat(Qt.TextFormat.RichText)
            section_content.setStyleSheet("""
                font-size: 14px;
                color: #d4d4d4;
                padding-left: 10px;
                padding-bottom: 15px;
            """)
            
            tutorial_layout.addWidget(section_title)
            tutorial_layout.addWidget(section_content)
        
        tutorial_layout.addStretch()
        
        scroll_area.setWidget(tutorial_content)
        layout.addWidget(scroll_area)
        
        # Add close button
        close_button = QPushButton("Close")
        close_button.setStyleSheet("""
            QPushButton {
                background-color: #0e639c;
                color: white;
                border: none;
                padding: 8px 16px;
                font-weight: bold;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: #1177bb;
            }
        """)
        close_button.clicked.connect(tutorial_dialog.accept)
        
        button_layout = QHBoxLayout()
        button_layout.addStretch()
        button_layout.addWidget(close_button)
        layout.addLayout(button_layout)
        
        # Set overall dialog styling
        tutorial_dialog.setStyleSheet("""
            QDialog {
                background-color: #1e1e1e;
                color: #d4d4d4;
            }
        """)
        
        tutorial_dialog.exec()
    
    def cut_to_clipboard(self):
        """Cut selected text to clipboard"""
        focused_widget = QApplication.focusWidget()
        if hasattr(focused_widget, 'cut') and callable(focused_widget.cut):
            focused_widget.cut()
        else:
            self.log_text.append("⚠️ Cut operation not supported for the current selection")
    
    def copy_to_clipboard(self):
        """Copy selected text to clipboard"""
        focused_widget = QApplication.focusWidget()
        if hasattr(focused_widget, 'copy') and callable(focused_widget.copy):
            focused_widget.copy()
        else:
            self.log_text.append("⚠️ Copy operation not supported for the current selection")
    
    def paste_from_clipboard(self):
        """Paste text from clipboard"""
        focused_widget = QApplication.focusWidget()
        if hasattr(focused_widget, 'paste') and callable(focused_widget.paste):
            focused_widget.paste()
        else:
            self.log_text.append("⚠️ Paste operation not supported for the current selection")
    
    def show_about(self):
        """Shows information about the application"""
        about_text = """
        <div style="text-align: center;">
            <h2 style="color: #00c3ff;">Netlify Deployer</h2>
            <p style="color: #d4d4d4;">Version 1.0.0</p>
            <p style="color: #d4d4d4;">A desktop application for easily deploying websites to Netlify.</p>
            <p style="color: #d4d4d4;">Created with PyQt6</p>
            <p style="color: #aaaaaa;">Copyright © 2023</p>
        </div>
        """
        
        about_dialog = QMessageBox(self)
        about_dialog.setWindowTitle("About Netlify Deployer")
        about_dialog.setText(about_text)
        about_dialog.setTextFormat(Qt.TextFormat.RichText)
        about_dialog.setStandardButtons(QMessageBox.StandardButton.Ok)
        
        # Set custom styling
        about_dialog.setStyleSheet("""
            QMessageBox {
                background-color: #1e1e1e;
            }
            QLabel {
                color: #d4d4d4;
                padding: 20px;
            }
            QPushButton {
                background-color: #0e639c;
                color: white;
                border: none;
                padding: 8px 16px;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: #1177bb;
            }
        """)
        
        about_dialog.exec()

    def update_window_title(self):
        """Update window title to show current configuration file."""
        base_title = "Netlify Deployer"
        if self.current_config_file:
            filename = os.path.basename(self.current_config_file)
            self.setWindowTitle(f"{base_title} - {filename}")
        else:
            self.setWindowTitle(base_title)

    # --- Build logic: ensure netlify.toml is only checked in publish dir after build ---
    def build_project(self):
        """Run the build command for the current project"""
        build_type = getattr(self, 'current_build_type', 'npm')
        build_command = self.build_commands.get(build_type, {}).get('build', '')
        
        # Skip if no command defined
        if not build_command:
            self.log_text.append("<span style='color: #e74c3c;'>No build command defined for this project type</span>")
            return
            
        # Webhook notifications feature has been removed
            
        # Run the build command
        self.run_build_command(build_command, f"Building project using {build_command}...")

    def build_production(self):
        """Run production build"""
        if not self.project_dir.text() or not os.path.isdir(self.project_dir.text()):
            self.show_error("Please select a valid project directory first.")
            return
        command = self.build_commands[self.current_build_type]["prod"]
        if not command:
            self.show_error("No production build command configured. Please configure build settings first.")
            return
        self.run_build_command(command, "Running production build")
        # No QTimer.singleShot here

    def clean_and_build(self):
        """Clean and then build the project"""
        if not self.project_dir.text() or not os.path.isdir(self.project_dir.text()):
            self.show_error("Please select a valid project directory first.")
            return
        clean_command = self.build_commands[self.current_build_type]["clean"]
        build_command = self.build_commands[self.current_build_type]["build"]
        if not clean_command or not build_command:
            self.show_error("Clean or build commands not configured. Please configure build settings first.")
            return
        self.run_build_command(f"{clean_command} && {build_command}", "Cleaning and building project")
        # No QTimer.singleShot here

    def check_publish_dir_for_toml(self, retries=40, delay_ms=500):
        """Wait for the publish directory to be created, then check for netlify.toml inside it."""
        project_dir = self.project_dir.text()
        publish_dir = self.publish_dir.text()
        publish_path = os.path.join(project_dir, publish_dir)
        self.log_text.append(f"[DEBUG] Checking for publish directory: {publish_path}")
        if not os.path.isdir(publish_path):
            if retries > 0:
                self.log_text.append(f"[DEBUG] Publish directory not found, waiting... ({retries} retries left)")
                QTimer.singleShot(delay_ms, lambda: self.check_publish_dir_for_toml(retries-1, delay_ms))
                return
            else:
                self.log_text.append(f"[DEBUG] Publish directory does NOT exist after waiting: {publish_path}")
                self.show_error(f"Publish directory does not exist after build: {publish_path}\n\nPlease check your build process.")
                return
        self.log_text.append(f"[DEBUG] Publish directory exists: {publish_path}")
        netlify_toml_path = os.path.join(publish_path, 'netlify.toml')
        self.log_text.append(f"[DEBUG] Checking for netlify.toml in publish directory: {netlify_toml_path}")
        if not os.path.exists(netlify_toml_path):
            self.log_text.append(f"[DEBUG] netlify.toml not found in publish directory, prompting user...")
            reply = QMessageBox.question(
                self,
                "Create netlify.toml",
                f"No netlify.toml file found in publish directory ({publish_path}). Would you like to create one now?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.Yes
            )
            if reply == QMessageBox.StandardButton.Yes:
                dialog = self.TomlConfigDialog(self, self.default_toml)
                if dialog.exec() == QDialog.DialogCode.Accepted:
                    toml_content = dialog.get_toml()
                    with open(netlify_toml_path, 'w', encoding='utf-8') as f:
                        f.write(toml_content)
                    self.log_text.append(f"✅ netlify.toml created in publish directory: {netlify_toml_path}")
                    self.toml_content = toml_content
                    self.save_settings()
                else:
                    self.log_text.append("⚠️ User cancelled netlify.toml creation after build.")
            else:
                self.log_text.append("⚠️ User chose not to create netlify.toml after build.")
        else:
            self.log_text.append(f"✅ netlify.toml already exists in publish directory: {netlify_toml_path}")

    # Remove all netlify.toml checks from project directory in build logic
    # (The deployment logic is already correct and only checks publish dir)

    def configure_netlify_toml(self, netlify_toml_path):
        """Open dialog to configure netlify.toml file"""
        try:
            # Create a dialog to edit the netlify.toml content
            dialog = self.TomlConfigDialog(self)
            
            # Connect the dialog's finished signal to handle the build
            result = dialog.exec()
            
            # Check if tolmconfig.txt exists (should be saved by the dialog before closing)
            if os.path.exists('tolmconfig.txt'):
                try:
                    # Read the saved TOML content
                    with open('tolmconfig.txt', 'r', encoding='utf-8') as f:
                        toml_content = f.read()
                    
                    # Write the TOML content to netlify.toml
                    with open(netlify_toml_path, 'w') as f:
                        f.write(toml_content)
                    
                    self.log_text.append(f"✅ netlify.toml created successfully from tolmconfig.txt")
                    
                    # Store the TOML content in app settings
                    self.toml_content = toml_content
                    self.save_settings()
                    
                    # Run the build command
                    command = self.build_commands[self.current_build_type]["build"]
                    self.run_build_command(command, "Building project")
                    return
                except Exception as e:
                    self.log_text.append(f"⚠️ Error reading from tolmconfig.txt: {str(e)}")
            
            # If we couldn't use tolmconfig.txt or it didn't exist, fall back to the old method
            if result == QDialog.DialogCode.Accepted:
                try:
                    # Get content BEFORE the dialog is destroyed
                    toml_content = dialog.toml_editor.toPlainText()
                    
                    # Write the toml content to the file
                    with open(netlify_toml_path, 'w') as f:
                        f.write(toml_content)
                    
                    self.log_text.append(f"✅ netlify.toml created successfully at: {netlify_toml_path}")
                    
                    # Store the toml content in the app settings
                    self.toml_content = toml_content
                    self.save_settings()
                    
                    # Get the build command for the current project type
                    command = self.build_commands[self.current_build_type]["build"]
                    # Run the build command
                    self.run_build_command(command, "Building project")
                except Exception as e:
                    self.show_error(f"Failed to create netlify.toml: {str(e)}")
            else:
                # User canceled netlify.toml creation, still run the build
                command = self.build_commands[self.current_build_type]["build"]
                self.run_build_command(command, "Building project")
        except Exception as e:
            self.show_error(f"Failed to open netlify.toml configuration window: {str(e)}")
            # Continue with the build anyway
            command = self.build_commands[self.current_build_type]["build"]
            self.run_build_command(command, "Building project")
    
    def run_build_command(self, command, status_message):
        """Run a build command in the project directory"""
        if self.build_process and self.build_process.state() == QProcess.ProcessState.Running:
            self.show_error("A build is already in progress. Please wait or stop it.")
            return
            
        self.log_text.append(f"🔧 {status_message}...")
        
        # Create and configure process
        self.build_process = QProcess()
        self.build_process.setWorkingDirectory(self.project_dir.text())
        
        # Connect signals
        self.build_process.readyReadStandardOutput.connect(self.process_output)
        self.build_process.readyReadStandardError.connect(self.process_error)
        self.build_process.finished.connect(self.build_finished)
        
        # Enable stop button
        self.stop_build_action.setEnabled(True)
        
        # Start the process with appropriate shell
        if sys.platform == 'win32':
            self.build_process.start("cmd.exe", ["/c", command])
        else:
            self.build_process.start("/bin/sh", ["-c", command])
    
    def process_output(self):
        """Process standard output from the build process"""
        data = self.build_process.readAllStandardOutput().data().decode('utf-8', errors='replace')
        self.log_text.append(data.rstrip())
    
    def process_error(self):
        """Process standard error from the build process"""
        data = self.build_process.readAllStandardError().data().decode('utf-8', errors='replace')
        self.log_text.append(f"⚠️ {data.rstrip()}")
    
    def build_finished(self, exit_code, exit_status):
        """Handle build process completion"""
        if exit_code == 0:
            self.log_text.append(f"<span style='color: #2ecc71;'>Build completed successfully!</span>")
            
            # Check if build directory contains files
            try:
                publish_dir = os.path.join(self.project_dir.text(), self.publish_dir.text())
                if os.path.exists(publish_dir):
                    files = os.listdir(publish_dir)
                    self.log_text.append(f"<span style='color: #2ecc71;'>Found {len(files)} files in publish directory</span>")
                    
                    # Configure netlify.toml if needed
                    if self.toml_content:
                        self.check_publish_dir_for_toml()
                else:
                    self.log_text.append(f"<span style='color: #e74c3c;'>Warning: Publish directory {publish_dir} does not exist</span>")
            except Exception as e:
                self.log_text.append(f"<span style='color: #e74c3c;'>Error checking publish directory: {str(e)}</span>")
            
            # Webhook notifications feature has been removed
        else:
            self.log_text.append(f"<span style='color: #e74c3c;'>Build failed with exit code {exit_code}</span>")
            
            # Webhook notifications feature has been removed
        
        self.stop_build_action.setEnabled(False)
    
    def stop_build(self):
        """Stop the currently running build process"""
        if self.build_process and self.build_process.state() == QProcess.ProcessState.Running:
            self.log_text.append("🛑 Stopping build process...")
            self.build_process.terminate()
            
            # Give some time to terminate gracefully before killing
            QTimer.singleShot(5000, lambda: self.kill_process_if_running())
    
    def kill_process_if_running(self):
        """Kill the process if it's still running after terminate request"""
        if self.build_process and self.build_process.state() == QProcess.ProcessState.Running:
            self.build_process.kill()
            self.log_text.append("⚠️ Force killed build process")
    
    def configure_build_settings(self):
        """Open dialog to configure build settings"""
        # Use self.BuildSettingsDialog to avoid undefined variable error
        dialog = self.BuildSettingsDialog(self, self.current_build_type, self.build_commands)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            # Update build settings
            self.current_build_type = dialog.get_build_type()
            if self.current_build_type == "custom":
                # Update custom commands
                self.build_commands["custom"] = dialog.get_custom_commands()
            
            self.log_text.append(f"✅ Build settings updated to {self.current_build_type} configuration")

    def encrypt_env_dialog(self):
        password, ok = QInputDialog.getText(self, 'Encrypt .env', 'Enter password to encrypt .env:', QLineEdit.EchoMode.Password)
        if ok and password:
            try:
                encrypt_env_file(password)
                QMessageBox.information(self, 'Success', '.env file encrypted and removed. Use the same password to decrypt.')
            except Exception as e:
                QMessageBox.critical(self, 'Encryption Error', f'Failed to encrypt .env: {e}')

    def decrypt_env_dialog(self):
        password, ok = QInputDialog.getText(self, 'Decrypt .env', 'Enter password to decrypt .env:', QLineEdit.EchoMode.Password)
        if ok and password:
            try:
                decrypt_env_file(password)
                QMessageBox.information(self, 'Success', '.env file decrypted.')
            except Exception as e:
                QMessageBox.critical(self, 'Decryption Error', f'Failed to decrypt .env: {e}')
                
    # Add BuildSettingsDialog class inside MainWindow to avoid undefined variable errors
    class BuildSettingsDialog(QDialog):
        """Dialog for configuring build settings."""
        
        def __init__(self, parent=None, current_build_type="npm", build_commands=None):
            super().__init__(parent)
            self.parent = parent
            self.build_commands = build_commands or {
                "custom": {
                    "build": "",
                    "prod": "",
                    "clean": ""
                }
            }
            self.setWindowTitle("Build Configuration")
            self.setMinimumSize(600, 400)
            self.setStyleSheet(GLASS_DIALOG_STYLE)
            
            layout = QVBoxLayout(self)
            layout.setContentsMargins(20, 20, 20, 20)
            layout.setSpacing(15)
            
            # Header
            header = QLabel("Build Configuration")
            header.setStyleSheet("""
                background-color: transparent;
                color: #00c3ff;
                font-size: 18px;
                font-weight: bold;
            """)
            layout.addWidget(header)
            
            # Description
            description = QLabel(
                "Configure the build settings for your project. Select a preset or create custom build commands."
            )
            description.setWordWrap(True)
            description.setStyleSheet("color: #d4d4d4; font-size: 14px; background-color: transparent;")
            layout.addWidget(description)
            
            # Build type selection
            build_type_label = QLabel("Build System:")
            build_type_label.setStyleSheet("color: #d4d4d4; font-weight: bold; background-color: transparent;")
            layout.addWidget(build_type_label)
            
            self.build_type_combo = QComboBox()
            self.build_type_combo.addItems(["npm", "yarn", "vue", "react", "angular", "custom"])
            self.build_type_combo.setStyleSheet("""
                background-color: #2d2d2d;
                color: #d4d4d4;
                border: 1px solid #444;
                padding: 8px;
                min-width: 150px;
            """)
            
            # Set current selection
            index = self.build_type_combo.findText(current_build_type)
            if index >= 0:
                self.build_type_combo.setCurrentIndex(index)
            
            self.build_type_combo.currentTextChanged.connect(self.update_command_display)
            layout.addWidget(self.build_type_combo)
            
            # Custom commands section (only editable for custom type)
            self.custom_section = QGroupBox("Custom Build Commands")
            self.custom_section.setStyleSheet("""
                QGroupBox {
                    color: #d4d4d4;
                    border: 1px solid #444;
                    margin-top: 20px;
                    font-weight: bold;
                }
                QGroupBox::title {
                    subcontrol-origin: margin;
                    left: 10px;
                    padding: 0 5px;
                }
            """)
            
            custom_layout = QVBoxLayout(self.custom_section)
            
            # Build command
            build_label = QLabel("Build Command:")
            build_label.setStyleSheet("color: #d4d4d4;")
            custom_layout.addWidget(build_label)
            
            self.build_command = QLineEdit()
            self.build_command.setPlaceholderText("e.g., npm run build")
            self.build_command.setStyleSheet("""
                background-color: #1e1e1e;
                color: #d4d4d4;
                border: 1px solid #333;
                padding: 8px;
            """)
            custom_layout.addWidget(self.build_command)
            
            # Production build command
            prod_label = QLabel("Production Build Command:")
            prod_label.setStyleSheet("color: #d4d4d4;")
            custom_layout.addWidget(prod_label)
            
            self.prod_command = QLineEdit()
            self.prod_command.setPlaceholderText("e.g., npm run build --production")
            self.prod_command.setStyleSheet(self.build_command.styleSheet())
            custom_layout.addWidget(self.prod_command)
            
            # Clean command
            clean_label = QLabel("Clean Command:")
            clean_label.setStyleSheet("color: #d4d4d4;")
            custom_layout.addWidget(clean_label)
            
            self.clean_command = QLineEdit()
            self.clean_command.setPlaceholderText("e.g., npm run clean")
            self.clean_command.setStyleSheet(self.build_command.styleSheet())
            custom_layout.addWidget(self.clean_command)
            
            layout.addWidget(self.custom_section)
            
            # Command preview section
            preview_group = QGroupBox("Command Preview")
            preview_group.setStyleSheet(self.custom_section.styleSheet())
            preview_layout = QVBoxLayout(preview_group)
            
            self.preview_text = QTextEdit()
            self.preview_text.setReadOnly(True)
            self.preview_text.setStyleSheet("""
                background-color: #1a1a1a;
                color: #d4d4d4;
                border: 1px solid #333;
                font-family: 'Consolas', 'Courier New', monospace;
                font-size: 14px;
                padding: 10px;
            """)
            preview_layout.addWidget(self.preview_text)
            
            layout.addWidget(preview_group)
            
            # Button layout
            button_layout = QHBoxLayout()
            button_layout.addStretch()
            
            cancel_btn = QPushButton("Cancel")
            cancel_btn.setStyleSheet("""
                background-color: #2d2d2d;
                color: #d4d4d4;
                border: none;
                padding: 8px 16px;
                border-radius: 4px;
            """)
            cancel_btn.clicked.connect(self.reject)
            button_layout.addWidget(cancel_btn)
            
            save_btn = QPushButton("Save")
            save_btn.setStyleSheet("""
                background-color: #0e639c;
                color: white;
                border: none;
                padding: 8px 16px;
                border-radius: 4px;
                font-weight: bold;
            """)
            save_btn.clicked.connect(self.accept)
            button_layout.addWidget(save_btn)
            
            layout.addLayout(button_layout)
            
            # Initialize with current settings
            self.update_command_display(current_build_type)
            
            # Set custom commands if available
            if "custom" in self.build_commands:
                custom = self.build_commands["custom"]
                self.build_command.setText(custom.get("build", ""))
                self.prod_command.setText(custom.get("prod", ""))
                self.clean_command.setText(custom.get("clean", ""))
        
        def update_command_display(self, build_type):
            """Update command display and enable/disable custom inputs based on selected build type."""
            # Enable/disable custom inputs
            is_custom = build_type == "custom"
            self.custom_section.setEnabled(is_custom)
            
            # Update preview text
            if build_type in self.build_commands:
                commands = self.build_commands[build_type]
                preview = f"""Build Command:
{commands.get('build', '')}

Production Build Command:
{commands.get('prod', '')}

Clean Command:
{commands.get('clean', '')}"""
                self.preview_text.setText(preview)
            else:
                self.preview_text.setText("No commands configured for this build type.")
        
        def get_build_type(self):
            """Get the currently selected build type."""
            return self.build_type_combo.currentText()
        
        def get_custom_commands(self):
            """Get the custom commands from the input fields."""
            return {
                "build": self.build_command.text(),
                "prod": self.prod_command.text(),
                "clean": self.clean_command.text()
            }
                
    # --- Security Features for Hardware Key and Terms of Service ---
    def verify_hardware_key(self):
        """Verify hardware key authentication"""
        if not SECURITY_FEATURES_AVAILABLE:
            QMessageBox.warning(
                self,
                "Feature Not Available",
                "Enhanced security features are not available. Please install the security_features.py module."
            )
            return
            
        try:
            from security_features import security_manager
            
            # Check for hardware key
            if security_manager.hardware_auth.is_authenticated(True):  # Force recheck
                drive_path = security_manager.hardware_auth.get_drive_path()
                QMessageBox.information(
                    self,
                    "Hardware Key Authenticated",
                    f"USB security key detected and authenticated successfully.\n\nKey ID: {security_manager.hardware_auth.get_key_id()}\nDrive location: {drive_path}"
                )
                self.log_text.append("✅ USB flash drive security key verified")
            else:
                reply = QMessageBox.question(
                    self,
                    "Hardware Key Required",
                    "No valid USB security key detected. Would you like to initialize a new USB flash drive as a security key?",
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
                )
                
                if reply == QMessageBox.StandardButton.Yes:
                    self.initialize_security_key()
                else:
                    self.log_text.append("❌ USB security key verification failed")
        except Exception as e:
            QMessageBox.critical(
                self,
                "Authentication Error",
                f"Hardware key authentication error: {str(e)}"
            )
            self.log_text.append(f"❌ Hardware key error: {str(e)}")

    def initialize_security_key(self):
        """Initialize a USB flash drive as a security key"""
        if not SECURITY_FEATURES_AVAILABLE:
            QMessageBox.warning(
                self,
                "Feature Not Available",
                "Enhanced security features are not available. Please install the security_features.py module."
            )
            return
            
        try:
            from security_features import security_manager
            
            # Check if already initialized
            if security_manager.is_hardware_key_initialized():
                usb_serial = security_manager.hardware_auth.get_usb_serial()
                QMessageBox.information(
                    self,
                    "Already Initialized",
                    f"USB security key has already been initialized with serial number: {usb_serial[:8]}...\n\nNo need to initialize again."
                )
                # Disable the initialize button
                sender = self.sender()
                if sender:
                    sender.setEnabled(False)
                    sender.setToolTip("USB security key is already initialized")
                return
            
            # For Windows, show drive selection dialog
            if platform.system() == 'Windows':
                # Get available drives
                result = subprocess.run(
                    ["powershell", "-Command", "Get-WmiObject Win32_LogicalDisk | Where-Object { $_.DriveType -eq 2 } | Select-Object DeviceID, VolumeName | Format-Table -AutoSize"],
                    capture_output=True,
                    text=True
                )
                
                drive_info = result.stdout.strip()
                
                if not drive_info or len(drive_info.split('\n')) <= 2:  # Account for header rows
                    QMessageBox.critical(
                        self,
                        "No USB Drives Found",
                        "No USB flash drives were detected. Please insert a USB drive and try again."
                    )
                    return
                    
                # Ask user to select drive letter
                drive_letter, ok = QInputDialog.getText(
                    self, 
                    "Select USB Drive", 
                    f"Available USB drives:\n\n{drive_info}\n\nEnter the drive letter (e.g., E:)",
                    QLineEdit.EchoMode.Normal
                )
                
                if not ok or not drive_letter:
                    return
                
                # Try to get the USB serial number directly using the PowerShell command
                usb_serial = None
                try:
                    # Get the serial number using PowerShell for USB interface type drives
                    ps_command = 'Get-WmiObject Win32_DiskDrive | Where-Object {$_.InterfaceType -eq "USB"} | Select-Object Model, SerialNumber, DeviceID'
                    process = subprocess.run(
                        ["powershell", "-Command", ps_command],
                        capture_output=True, text=True
                    )
                    
                    if process.returncode == 0:
                        output = process.stdout.strip()
                        self.log_text.append(f"Found USB drives: {output}")
                        
                        # Parse the output to extract DeviceID and SerialNumber
                        import re
                        
                        # Example format: "\\.\PHYSICALDRIVE2       7427491226396596455"
                        matches = re.findall(r'\\\\\.\\PHYSICALDRIVE\d+\s+(\S+)', output)
                        
                        if matches and len(matches) > 0:
                            usb_serial = matches[0]  # Use the first USB drive's serial
                            self.log_text.append(f"Detected USB serial number: {usb_serial}")
                except Exception as e:
                    self.log_text.append(f"Error getting USB serial with PowerShell: {str(e)}")
                
                # Extract drive info to show serial number
                if not usb_serial:
                    try:
                        usb_drives = security_manager.hardware_auth._get_usb_drives_with_serials()
                        for path, serial in usb_drives:
                            if path.startswith(drive_letter.upper().rstrip(':\\')):
                                usb_serial = serial
                                break
                    except Exception as e:
                        self.log_text.append(f"Error in fallback serial detection: {str(e)}")
                
                serial_text = f"Serial Number: {usb_serial}" if usb_serial else "Serial number will be extracted from the device"
                
                # Confirm initialization with serial number information
                reply = QMessageBox.warning(
                    self,
                    "Initialize Security Key",
                    f"This will initialize the USB drive {drive_letter} as your security key.\n\n{serial_text}\n\nThis USB drive will be required for future deployments.\n\nProceed?",
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                    QMessageBox.StandardButton.No
                )
                
                if reply != QMessageBox.StandardButton.Yes:
                    return
                
                # First, try to create key with automatic detection
                key_id = security_manager.initialize_hardware_key(drive_letter)
                
                # If automatic detection fails, offer manual method
                if not key_id:
                    self.log_text.append("⚠️ Automatic USB serial number detection failed. Trying alternative methods...")
                    
                    # Try direct WMIC command
                    try:
                        # Run wmic command to get disk info with serial number
                        self.log_text.append("Attempting direct WMIC query for serial number...")
                        cmd = ["wmic", "diskdrive", "get", "SerialNumber"]
                        process = subprocess.run(cmd, capture_output=True, text=True)
                        
                        if process.returncode == 0 and process.stdout.strip():
                            lines = process.stdout.strip().split('\n')
                            if len(lines) >= 2:  # Must have at least header and one value
                                usb_serial = lines[1].strip()
                                if usb_serial and usb_serial != "NULL":
                                    self.log_text.append(f"Found USB serial: {usb_serial}")
                                    
                                    # Create a hash of the serial as the key ID
                                    import hashlib
                                    key_id = hashlib.sha256(usb_serial.encode()).hexdigest()
                                    
                                    # Create and save the key store file
                                    key_store_path = "usb_key_store.json"
                                    import json, datetime
                                    key_data = {
                                        "usb_serial": usb_serial,
                                        "key_id": key_id,
                                        "created": datetime.datetime.now().isoformat(),
                                        "platform": platform.system(),
                                        "initialized_by": platform.node(),
                                        "drive_path": drive_letter
                                    }
                                    
                                    with open(key_store_path, 'w') as f:
                                        json.dump(key_data, f)
                                        
                                    # Update hardware auth state
                                    security_manager.hardware_auth._usb_serial = usb_serial
                                    security_manager.hardware_auth._initialized = True
                                    
                                    # Save the USB serial to .env file
                                    self._save_usb_serial_to_env(usb_serial)
                                    
                                    self.log_text.append("✅ USB security key initialized with direct method")
                                    
                                    # Success message and disable button
                                    QMessageBox.information(
                                        self,
                                        "Security Key Initialized",
                                        f"USB security key has been successfully initialized.\n\nSerial Number: {usb_serial}\n\nThis USB drive will be required for all future deployments."
                                    )
                                    
                                    # Disable initialize button
                                    sender = self.sender()
                                    if sender:
                                        sender.setEnabled(False)
                                        sender.setToolTip("USB security key is already initialized")
                                    
                                    return
                    except Exception as e:
                        self.log_text.append(f"Direct WMIC query failed: {str(e)}")
                        
                    # If all automatic methods fail, ask user for a manual identifier
                    manual_id, ok = QInputDialog.getText(
                        self,
                        "Manual USB Identification",
                        "Automatic USB serial detection failed. Please enter a unique identifier for this USB drive.\n\n"
                        "This could be any text that uniquely identifies your USB drive (e.g., 'JohnsUSB-123'):",
                        QLineEdit.EchoMode.Normal,
                        f"USB-{drive_letter.strip(':')}-{int(time.time())}"  # Default value
                    )
                    
                    if ok and manual_id:
                        # Create a hash of the manual ID as the key ID
                        import hashlib
                        key_id = hashlib.sha256(manual_id.encode()).hexdigest()
                        
                        # Create and save the key store file
                        key_store_path = "usb_key_store.json"
                        import json, datetime
                        key_data = {
                            "usb_serial": manual_id,
                            "key_id": key_id,
                            "created": datetime.datetime.now().isoformat(),
                            "platform": platform.system(),
                            "initialized_by": platform.node(),
                            "drive_path": drive_letter,
                            "manual_entry": True
                        }
                        
                        with open(key_store_path, 'w') as f:
                            json.dump(key_data, f)
                            
                        # Update hardware auth state
                        security_manager.hardware_auth._usb_serial = manual_id
                        security_manager.hardware_auth._initialized = True
                        
                        # Save the manual identifier to .env file
                        self._save_usb_serial_to_env(manual_id)
                        
                        self.log_text.append(f"✅ USB security key initialized with manual identifier: {manual_id}")
                        
                        # Permanently disable the initialize button
                        sender = self.sender()
                        if sender:
                            sender.setEnabled(False)
                            sender.setToolTip("USB security key is already initialized")
                        
                        # Show success message with manual identifier
                        QMessageBox.information(
                            self,
                            "Security Key Initialized",
                            f"USB security key has been successfully initialized with manual identifier.\n\nIdentifier: {manual_id}\n\nThis USB drive will be required for all future deployments."
                        )
                    else:
                        self.log_text.append("❌ Security key initialization cancelled by user")
                        QMessageBox.critical(
                            self,
                            "Initialization Cancelled",
                            "USB security key initialization was cancelled."
                        )
                else:
                    # Original key creation worked
                    # Get the USB serial number
                    usb_serial = security_manager.hardware_auth.get_usb_serial()
                    
                    # Save the USB serial to .env file
                    self._save_usb_serial_to_env(usb_serial)
                    
                    # Permanently disable the initialize button
                    sender = self.sender()
                    if sender:
                        sender.setEnabled(False)
                        sender.setToolTip("USB security key is already initialized")
                    
                    # Show success message with serial number
                    QMessageBox.information(
                        self,
                        "Security Key Initialized",
                        f"USB security key has been successfully initialized.\n\nSerial Number: {usb_serial}\n\nThis USB drive will be required for all future deployments."
                    )
                    self.log_text.append(f"✅ USB security key initialized with serial number: {usb_serial}")
            else:
                # For macOS and Linux (remaining code is similar)
                pass
                    
        except Exception as e:
            QMessageBox.critical(
                self,
                "Initialization Error",
                f"Failed to initialize security key: {str(e)}"
            )
            self.log_text.append(f"❌ Security key initialization error: {str(e)}")
    
    def _save_usb_serial_to_env(self, serial):
        """Save the USB serial number to the .env file"""
        self.log_text.append(f"Saving USB serial number to .env file: {serial}")
        
        try:
            env_file = '.env'
            env_lines = []
            usb_key_line = f"USB_KEY_SERIAL={serial}"
            
            # Read existing .env file if it exists
            if os.path.exists(env_file):
                with open(env_file, 'r') as f:
                    env_lines = f.readlines()
            
            # Check if the USB_KEY_SERIAL line already exists
            usb_key_found = False
            for i, line in enumerate(env_lines):
                if line.startswith('USB_KEY_SERIAL='):
                    env_lines[i] = usb_key_line + '\n'
                    usb_key_found = True
                    break
            
            # If the line doesn't exist, add it
            if not usb_key_found:
                env_lines.append(usb_key_line + '\n')
            
            # Write back to .env file
            with open(env_file, 'w') as f:
                f.writelines(env_lines)
            
            self.log_text.append("✅ USB serial number saved to .env file")
            
            # Reload environment variables
            from dotenv import load_dotenv
            load_dotenv(override=True)
            
        except Exception as e:
            self.log_text.append(f"⚠️ Error saving USB serial to .env file: {str(e)}")

    def show_terms_of_service(self):
        """Show Terms of Service dialog"""
        if not SECURITY_FEATURES_AVAILABLE:
            QMessageBox.warning(
                self,
                "Feature Not Available",
                "Enhanced security features are not available. Please install the security_features.py module."
            )
            return
            
        try:
            from security_features import security_manager
            from tos_dialog import TermsOfServiceDialog
            
            # Get TOS text and show dialog
            tos_text = security_manager.legal.get_tos_text()
            tos_dialog = TermsOfServiceDialog(tos_text, self)
            
            # If user accepts, record it
            if tos_dialog.exec() == QDialog.DialogCode.Accepted and tos_dialog.was_accepted():
                security_manager.legal.accept_tos(getattr(self, "username", platform.node()))
                self.log_text.append("✅ Terms of Service accepted")
            
        except Exception as e:
            QMessageBox.critical(
                self,
                "Terms of Service Error",
                f"Could not display Terms of Service: {str(e)}"
            )
            self.log_text.append(f"❌ Terms of Service error: {str(e)}")

    def initialize_security_key_on_h_drive(self):
        """Initialize a USB security key specifically on the H: drive"""
        if not SECURITY_FEATURES_AVAILABLE:
            self.show_error("Security features are not available. Cannot create USB security key.")
            return
            
        try:
            from security_features import security_manager
            
            # Directly target H: drive
            h_drive = "H:"
            
            # Check if H: drive exists
            if not os.path.exists(h_drive):
                self.log_text.append("❌ Drive H: not found. Please make sure the USB drive is properly connected.")
                self.show_error("Drive H: not found. Please make sure the USB drive is properly connected.")
                return
                
            self.log_text.append(f"🔑 Initializing USB security key on drive H:")
            
            # Initialize the key
            key_id = security_manager.initialize_hardware_key(h_drive)
            
            if key_id:
                self.log_text.append(f"✅ USB security key successfully created on drive H:")
                self.log_text.append(f"✅ Key ID: {key_id[:8]}... (first 8 characters)")
                QMessageBox.information(
                    self,
                    "Security Key Created",
                    f"USB security key has been successfully created on drive H:.\n\nPlease keep this USB drive safe as it will be required for login and deployments."
                )
            else:
                self.log_text.append("❌ Failed to create USB security key")
                error_msg = security_manager.hardware_auth.get_last_error()
                self.show_error(f"Failed to create USB security key: {error_msg}")
        except Exception as e:
            self.show_error(f"Error initializing USB security key: {str(e)}")

    # Add TomlConfigDialog class inside MainWindow to avoid undefined variable errors
    class TomlConfigDialog(QDialog):
        """Dialog for editing netlify.toml configuration."""
        
        def __init__(self, parent=None, initial_content=''):
            super().__init__(parent)
            self.parent = parent
            self.setWindowTitle("Netlify TOML Configuration")
            self.setMinimumSize(700, 500)
            self.setStyleSheet(GLASS_DIALOG_STYLE)
            
            layout = QVBoxLayout(self)
            layout.setContentsMargins(20, 20, 20, 20)
            layout.setSpacing(15)
            
            # Header
            header = QLabel("Netlify TOML Configuration")
            header.setStyleSheet("""
                background-color: transparent;
                color: #00c3ff;
                font-size: 18px;
                font-weight: bold;
            """)
            layout.addWidget(header)
            
            # Description
            description = QLabel(
                "Edit your netlify.toml file below. This file configures your Netlify deployment options, "
                "including redirects, headers, and build settings."
            )
            description.setWordWrap(True)
            description.setStyleSheet("color: #d4d4d4; font-size: 14px; background-color: transparent;")
            layout.addWidget(description)
            
            # Editor
            self.toml_editor = QTextEdit()
            self.toml_editor.setStyleSheet("""
                background-color: #1e1e1e;
                color: #d4d4d4;
                border: 1px solid #333;
                font-family: 'Consolas', 'Courier New', monospace;
                font-size: 14px;
                padding: 10px;
            """)
            
            # Set initial content or default template
            if initial_content:
                self.toml_editor.setText(initial_content)
            else:
                default_template = """# Netlify Configuration File
# See https://docs.netlify.com/configure-builds/file-based-configuration/

[build]
  # Directory with the built site (relative to the repository root)
  publish = "dist"  # Change to your build output directory (dist, build, public, out, etc.)
  # Command to build your site
  command = "npm run build"  # Change if you use a different build command

# URL handling for single-page applications (SPAs)
[[redirects]]
  from = "/*"
  to = "/index.html"
  status = 200
  force = true  # Ensure SPA routing works correctly

# Custom headers
[[headers]]
  for = "/*"
  [headers.values]
    X-Frame-Options = "DENY"
    X-XSS-Protection = "1; mode=block"
    X-Content-Type-Options = "nosniff"
    Referrer-Policy = "strict-origin-when-cross-origin"
"""
                self.toml_editor.setText(default_template)
            
            layout.addWidget(self.toml_editor)
            
            # Button layout
            button_layout = QHBoxLayout()
            
            # Add sample templates dropdown
            template_label = QLabel("Templates:")
            template_label.setStyleSheet("color: #d4d4d4; background-color: transparent;")
            button_layout.addWidget(template_label)
            
            templates = QComboBox()
            templates.addItem("Select Template...")
            templates.addItem("Basic SPA")
            templates.addItem("Static Site")
            templates.addItem("Custom Headers")
            templates.addItem("Functions")
            templates.setStyleSheet("""
                background-color: #2d2d2d;
                color: #d4d4d4;
                border: 1px solid #444;
                padding: 5px;
                min-width: 150px;
            """)
            templates.currentIndexChanged.connect(self.apply_template)
            button_layout.addWidget(templates)
            
            button_layout.addStretch()
            
            cancel_btn = QPushButton("Cancel")
            cancel_btn.setStyleSheet("""
                background-color: #2d2d2d;
                color: #d4d4d4;
                border: none;
                padding: 8px 16px;
                border-radius: 4px;
            """)
            cancel_btn.clicked.connect(self.reject)
            button_layout.addWidget(cancel_btn)
            
            save_btn = QPushButton("Save")
            save_btn.setStyleSheet("""
                background-color: #0e639c;
                color: white;
                border: none;
                padding: 8px 16px;
                border-radius: 4px;
                font-weight: bold;
            """)
            save_btn.clicked.connect(self.accept)
            button_layout.addWidget(save_btn)
            
            layout.addLayout(button_layout)
            
            # Save content to a file when dialog closes with accept
            self.accepted.connect(self.save_toml_content)
        
        def apply_template(self, index):
            """Apply a template based on the selected index."""
            if index == 0:  # "Select Template..."
                return
                
            templates = {
                1: """# Basic SPA Configuration
[build]
  publish = "dist"
  command = "npm run build"

[[redirects]]
  from = "/*"
  to = "/index.html"
  status = 200
  force = true
""",
                2: """# Static Site Configuration
[build]
  publish = "dist"
  command = "npm run build"

# Enable asset optimization
[build.processing]
  skip_processing = false
[build.processing.css]
  bundle = true
  minify = true
[build.processing.js]
  bundle = true
  minify = true
[build.processing.images]
  compress = true
""",
                3: """# Custom Headers Configuration
[build]
  publish = "dist"
  command = "npm run build"

[[headers]]
  for = "/*"
  [headers.values]
    X-Frame-Options = "DENY"
    X-XSS-Protection = "1; mode=block"
    X-Content-Type-Options = "nosniff"
    Content-Security-Policy = "default-src 'self'"
    Referrer-Policy = "strict-origin-when-cross-origin"
""",
                4: """# Netlify Functions Configuration
[build]
  publish = "dist"
  command = "npm run build"
  functions = "netlify/functions"

# API endpoint for your functions
[[redirects]]
  from = "/api/*"
  to = "/.netlify/functions/:splat"
  status = 200
"""
            }
            
            # Get current template text
            if index in templates:
                template_text = templates[index]
                # Set the text in the editor
                self.toml_editor.setText(template_text)
        
        def get_toml(self):
            """Get the TOML content from the editor."""
            return self.toml_editor.toPlainText()
        
        def save_toml_content(self):
            """Save TOML content to a temp file for reference."""
            try:
                with open('tolmconfig.txt', 'w', encoding='utf-8') as f:
                    f.write(self.get_toml())
            except Exception:
                pass  # Silently fail, this is just a convenience

    def save_template(self):
        """Save current project configuration as a template"""
        dialog = QInputDialog(self)
        dialog.setWindowTitle("Save as Template")
        dialog.setLabelText("Template Name:")
        dialog.setWindowIcon(self.windowIcon())
        dialog.resize(350, 100)
        dialog.setStyleSheet("""
            QInputDialog {
                background-color: #1e1e1e;
                color: #d4d4d4;
            }
            QInputDialog QLabel {
                color: #d4d4d4;
                font-size: 13px;
            }
            QInputDialog QLineEdit {
                background-color: #252525;
                color: #d4d4d4;
                border: 1px solid #3c3c3c;
                border-radius: 4px;
                padding: 5px;
                font-size: 13px;
            }
            QInputDialog QPushButton {
                background-color: #0e639c;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 6px 12px;
                font-size: 13px;
                margin: 5px;
            }
            QInputDialog QPushButton:hover {
                background-color: #1177bb;
            }
            QInputDialog QPushButton:pressed {
                background-color: #0d5989;
            }
        """)
        
        if dialog.exec() == QDialog.DialogCode.Accepted:
            template_name = dialog.textValue().strip()
            if template_name:
                # Create template data from current settings
                template = {
                    'name': template_name,
                    'project_dir': self.project_dir.text(),
                    'publish_dir': self.publish_dir.text(),
                    'site_name': self.site_name.text(),
                    'team_name': self.persistent_team,
                    'token': self.security.encrypt(self.persistent_token) if self.persistent_token else '',
                    'toml_content': self.toml_content,
                    'build_type': self.current_build_type,
                    'created_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                }
                
                # Add to templates list
                self.templates.append(template)
                self.save_templates()
                
                # Update templates menu
                self.update_templates_menu()
                
                self.log_text.append(f"<span style='color: #6A9955'>✓ Template '{template_name}' saved successfully.</span>")
    
    def load_templates(self):
        """Load saved templates from file"""
        templates_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'settings')
        os.makedirs(templates_dir, exist_ok=True)
        templates_path = os.path.join(templates_dir, 'templates.json')
        
        if os.path.exists(templates_path):
            try:
                with open(templates_path, 'r') as f:
                    self.templates = json.load(f)
            except json.JSONDecodeError:
                self.templates = []
        else:
            self.templates = []
    
    def save_templates(self):
        """Save templates to file"""
        templates_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'settings')
        os.makedirs(templates_dir, exist_ok=True)
        templates_path = os.path.join(templates_dir, 'templates.json')
        
        with open(templates_path, 'w') as f:
            json.dump(self.templates, f, indent=4)
    
    def load_template(self, index):
        """Apply selected template to current configuration"""
        if 0 <= index < len(self.templates):
            template = self.templates[index]
            
            # Apply template settings
            self.project_dir.setText(template['project_dir'])
            self.publish_dir.setText(template['publish_dir'])
            self.site_name.setText(template['site_name'])
            self.persistent_team = template.get('team_name', '')
            
            # Load token if it exists
            if template.get('token'):
                try:
                    self.persistent_token = self.security.decrypt(template['token'])
                except Exception:
                    self.persistent_token = ''
                    
            # Load TOML content if it exists
            if 'toml_content' in template:
                self.toml_content = template['toml_content']
                self.default_toml = self.toml_content
            
            # Load build type if it exists
            if 'build_type' in template:
                self.current_build_type = template['build_type']
                
            self.save_persistent_settings()
            
            self.log_text.append(f"<span style='color: #6A9955'>✓ Template '{template['name']}' loaded successfully.</span>")
    
    def manage_templates(self):
        """Open dialog for managing templates"""
        dialog = QDialog(self)
        dialog.setWindowTitle("Manage Templates")
        dialog.setWindowIcon(self.windowIcon())
        dialog.setMinimumWidth(500)
        dialog.setMinimumHeight(400)
        dialog.setStyleSheet("""
            QDialog {
                background-color: #1e1e1e;
                color: #d4d4d4;
            }
        """)
        
        layout = QVBoxLayout(dialog)
        
        # Template list
        list_widget = QListWidget()
        list_widget.setStyleSheet("""
            QListWidget {
                background-color: #252525;
                color: #d4d4d4;
                border: 1px solid #3c3c3c;
                border-radius: 4px;
                padding: 5px;
                font-size: 13px;
            }
            QListWidget::item {
                padding: 6px;
                border-bottom: 1px solid #333;
            }
            QListWidget::item:selected {
                background-color: #094771;
            }
        """)
        
        for template in self.templates:
            item = QListWidgetItem(f"{template['name']} ({template.get('created_at', 'Unknown date')})")
            item.setData(Qt.ItemDataRole.UserRole, self.templates.index(template))
            list_widget.addItem(item)
        
        layout.addWidget(list_widget)
        
        # Buttons layout
        btn_layout = QHBoxLayout()
        
        load_btn = QPushButton("Load")
        load_btn.setStyleSheet("""
            QPushButton {
                background-color: #0e639c;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 8px 16px;
                font-size: 13px;
            }
            QPushButton:hover {
                background-color: #1177bb;
            }
            QPushButton:pressed {
                background-color: #0d5989;
            }
        """)
        
        delete_btn = QPushButton("Delete")
        delete_btn.setStyleSheet("""
            QPushButton {
                background-color: #c72c41;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 8px 16px;
                font-size: 13px;
            }
            QPushButton:hover {
                background-color: #d13651;
            }
            QPushButton:pressed {
                background-color: #b02739;
            }
        """)
        
        cancel_btn = QPushButton("Close")
        cancel_btn.setStyleSheet("""
            QPushButton {
                background-color: #333333;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 8px 16px;
                font-size: 13px;
            }
            QPushButton:hover {
                background-color: #444444;
            }
            QPushButton:pressed {
                background-color: #2a2a2a;
            }
        """)
        
        btn_layout.addWidget(load_btn)
        btn_layout.addWidget(delete_btn)
        btn_layout.addStretch()
        btn_layout.addWidget(cancel_btn)
        
        layout.addLayout(btn_layout)
        
        # Connect signals
        load_btn.clicked.connect(lambda: self.load_template(list_widget.currentItem().data(Qt.ItemDataRole.UserRole)) if list_widget.currentItem() else None)
        load_btn.clicked.connect(dialog.accept)
        
        delete_btn.clicked.connect(lambda: self.delete_template(list_widget.currentItem().data(Qt.ItemDataRole.UserRole)) if list_widget.currentItem() else None)
        delete_btn.clicked.connect(lambda: list_widget.takeItem(list_widget.currentRow()) if list_widget.currentItem() else None)
        
        cancel_btn.clicked.connect(dialog.reject)
        
        # Double click to load
        list_widget.itemDoubleClicked.connect(lambda item: self.load_template(item.data(Qt.ItemDataRole.UserRole)))
        list_widget.itemDoubleClicked.connect(dialog.accept)
        
        dialog.exec()
    
    def delete_template(self, index):
        """Delete a template by index"""
        if 0 <= index < len(self.templates):
            template_name = self.templates[index]['name']
            del self.templates[index]
            self.save_templates()
            self.update_templates_menu()
            self.log_text.append(f"<span style='color: #CE9178'>✓ Template '{template_name}' deleted.</span>")
    
    def update_templates_menu(self):
        """Update the templates submenu with current templates"""
        if hasattr(self, 'templates_menu'):
            self.templates_menu.clear()
            
            # Add templates actions
            for template in self.templates:
                action = QAction(template['name'], self)
                action.triggered.connect(lambda checked=False, idx=self.templates.index(template): self.load_template(idx))
                self.templates_menu.addAction(action)
                
            if self.templates:
                self.templates_menu.addSeparator()
                
            self.templates_menu.addAction(self.manage_templates_action)
            self.templates_menu.addAction(self.save_template_action)

    def _add_menu_items(self, menubar, file_menu):
        """Add menu items to menubar and file menu"""
        
        # Create Configuration menu
        config_menu = menubar.addMenu("&Configuration")
        
        # Add Templates submenu under Configuration menu
        self.templates_menu = QMenu("&Templates", self)
        self.templates_menu.setStyleSheet(file_menu.styleSheet())
        
        self.save_template_action = QAction("Save Current as Template", self)
        self.save_template_action.triggered.connect(self.save_template)
        
        self.manage_templates_action = QAction("Manage Templates", self)
        self.manage_templates_action.triggered.connect(self.manage_templates)
        
        self.update_templates_menu()
        config_menu.addMenu(self.templates_menu)
        
        # Move Settings under Configuration menu
        settings_menu = QMenu("&Settings", self)
        settings_menu.setStyleSheet(file_menu.styleSheet())
        open_settings_action = QAction("Netlify Configurations", self)
        open_settings_action.triggered.connect(self.open_settings_dialog)
        settings_menu.addAction(open_settings_action)
        config_menu.addMenu(settings_menu)
        
        # Move TOML configuration under Configuration menu
        toml_menu = QMenu("&TOML File Configuration", self)
        toml_menu.setStyleSheet(file_menu.styleSheet())
        open_toml_action = QAction("Edit netlify.toml Content", self)
        open_toml_action.triggered.connect(self.open_toml_dialog)
        toml_menu.addAction(open_toml_action)
        config_menu.addMenu(toml_menu)
        
        # Move Security under Configuration menu
        security_menu = QMenu("&Security", self)
        security_menu.setStyleSheet(file_menu.styleSheet())
        change_password_action = QAction("Change Management Password", self)
        change_password_action.triggered.connect(self.show_change_password_dialog)
        security_menu.addAction(change_password_action)
        config_menu.addMenu(security_menu)

    def delete_configuration(self):
        """Delete the current configuration file"""
        if not self.current_config_file:
            return
            
        # Extract site name from configuration
        site_name = self.site_name.text()
        site_id = ""
        
        # Check if this is a site managed by the multisite manager
        if self.has_feature_integration and hasattr(self.feature_integration, 'feature_managers') and 'multisite' in self.feature_integration.feature_managers:
            multisite_manager = self.feature_integration.feature_managers['multisite']
            site = multisite_manager.site_manager.get_site(site_name)
            if site:
                site_id = site.site_id
        
        # Ask if user wants to delete from Netlify as well
        delete_from_netlify = False
        
        if site_id:
            message_box = QMessageBox(self)
            message_box.setWindowTitle("Confirm Deletion")
            message_box.setText(f"Are you sure you want to delete the configuration for '{site_name}'?")
            
            # Provide detailed information about the consequences
            info_text = (
                "Please choose one of the following options:\n\n"
                "• Delete Config Only: The configuration file will be removed but the site will remain on Netlify.\n"
                "• Delete from Netlify Too: The site will be permanently deleted from Netlify as well.\n\n"
                "Warning: Deleting from Netlify is permanent and cannot be undone."
            )
            message_box.setInformativeText(info_text)
            message_box.setIcon(QMessageBox.Icon.Warning)
            
            # Add buttons
            delete_config_button = message_box.addButton("Delete Config Only", QMessageBox.ButtonRole.AcceptRole)
            delete_both_button = message_box.addButton("Delete from Netlify Too", QMessageBox.ButtonRole.ActionRole)
            cancel_button = message_box.addButton(QMessageBox.StandardButton.Cancel)
            
            message_box.setDefaultButton(delete_config_button)
            
            # Show dialog
            message_box.exec()
            
            clicked_button = message_box.clickedButton()
            
            if clicked_button == cancel_button:
                return
            elif clicked_button == delete_both_button:
                delete_from_netlify = True
        else:
            # Standard confirmation dialog for config deletion only
            reply = QMessageBox.question(
                self, "Confirm Deletion", 
                f"Are you sure you want to delete the configuration file '{os.path.basename(self.current_config_file)}'?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No
            )
            
            if reply != QMessageBox.StandardButton.Yes:
                return
        
        # Delete from Netlify if requested
        if delete_from_netlify and self.has_feature_integration:
            try:
                # Show a progress dialog
                progress_dialog = QProgressDialog("Deleting site from Netlify...", "Cancel", 0, 0, self)
                progress_dialog.setWindowTitle("Deleting Site")
                progress_dialog.setWindowModality(Qt.WindowModality.WindowModal)
                progress_dialog.setMinimumDuration(0)
                progress_dialog.setValue(0)
                progress_dialog.show()
                QApplication.processEvents()
                
                # Delete from Netlify
                result, message = self.feature_integration.feature_managers['multisite'].delete_site_from_netlify(site_name)
                
                # Close progress dialog
                progress_dialog.close()
                
                if result:
                    QMessageBox.information(
                        self,
                        "Site Deleted",
                        f"The site '{site_name}' has been deleted from Netlify."
                    )
                else:
                    QMessageBox.warning(
                        self,
                        "Deletion Failed",
                        f"Failed to delete site from Netlify: {message}\n\n"
                        "The configuration file will still be deleted."
                    )
            except Exception as e:
                QMessageBox.warning(
                    self,
                    "Deletion Error",
                    f"Error deleting site from Netlify: {str(e)}\n\n"
                    "The configuration file will still be deleted."
                )
        
        # Delete the configuration file
        try:
            # Store the file path before clearing it
            file_to_remove = self.current_config_file
            
            # Delete the file
            os.remove(file_to_remove)
            
            # Clear UI and variables
            self.current_config_file = ""
            self.clear_fields()
            self.update_window_title()
            self.log_text.append(f"<span style='color: #e74c3c;'>Configuration file deleted</span>")
            
            # Remove from recent files using the stored path
            try:
                if file_to_remove in self.recent_files:
                    self.recent_files.remove(file_to_remove)
                    self.save_recent_files()
                    self.update_recent_files_menu()
            except Exception as e:
                print(f"Error removing file from recent files during deletion: {str(e)}")
        except Exception as e:
            self.show_error(f"Error deleting configuration file: {str(e)}")

    def clear_fields(self):
        """Clear all input fields and reset configuration values."""
        self.project_dir.clear()
        self.publish_dir.clear()
        self.site_name.clear()
        self.persistent_token = ''
        self.persistent_team = ''
        self.toml_content = ''
        # Don't update window title here as it's done separately




def set_strict_permissions(filepath):
    """Set file permissions to be readable/writable only by the current user (cross-platform)."""
    import os, sys
    try:
        if sys.platform == 'win32':
            import subprocess
            import getpass
            username = getpass.getuser()
            subprocess.run(["icacls", os.path.abspath(filepath), "/inheritance:r", f"/grant:r", f"{username}:F"], check=True)
        elif sys.platform == 'darwin':  # macOS
            os.chmod(filepath, 0o600)
            # Optionally, lock file (user cannot modify/delete without unlocking)
            try:
                import subprocess
                subprocess.run(["chflags", "uchg", os.path.abspath(filepath)], check=True)
            except Exception:
                pass  # chflags may not be available
        elif sys.platform.startswith('linux') or sys.platform.startswith('cygwin'):
            os.chmod(filepath, 0o600)
        else:
            print(f"[SECURITY WARNING] Platform {sys.platform} not fully supported for strict file permissions. File: {filepath}")
    except Exception as e:
        print(f"[SECURITY WARNING] Could not set strict permissions for {filepath}: {e}")

# --- .env Encryption Utilities ---
def encrypt_env_file(password, env_path='.env', encrypted_path='.env.encrypted'):
    """Encrypt the .env file with Fernet using a key derived from the password."""
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.backends import default_backend
    import os
    salt = os.urandom(16)
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=390000,
        backend=default_backend()
    )
    key = base64.urlsafe_b64encode(kdf.derive(password.encode()))
    f = Fernet(key)
    with open(env_path, 'rb') as f_in:
        data = f_in.read()
    encrypted = f.encrypt(data)
    with open(encrypted_path, 'wb') as f_out:
        f_out.write(salt + encrypted)
    os.remove(env_path)
    set_strict_permissions(encrypted_path)


def decrypt_env_file(password, encrypted_path='.env.encrypted', env_path='.env'):
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.backends import default_backend
    import os
    with open(encrypted_path, 'rb') as f_in:
        salt = f_in.read(16)
        encrypted = f_in.read()
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=390000,
        backend=default_backend()
    )
    key = base64.urlsafe_b64encode(kdf.derive(password.encode()))
    f = Fernet(key)
    data = f.decrypt(encrypted)
    with open(env_path, 'wb') as f_out:
        f_out.write(data)
    set_strict_permissions(env_path)

# --- Secure netlify_config.json ---
class SecureConfigManager:
    """Encrypt/decrypt sensitive fields in netlify_config.json using Fernet."""
    def __init__(self, password):
        import base64, hashlib
        key = hashlib.sha256(password.encode()).digest()
        self.key = base64.urlsafe_b64encode(key)
        self.fernet = Fernet(self.key)
        self.config_path = 'netlify_config.json'

    def load(self):
        import json, os
        if not os.path.exists(self.config_path):
            return {}
        with open(self.config_path, 'r') as f:
            data = json.load(f)
        for field in ['token', 'team_name', 'toml_content']:
            if field in data and data[field]:
                try:
                    data[field] = self.fernet.decrypt(data[field].encode()).decode()
                except Exception:
                    pass  # If not encrypted, leave as is
        return data

    def save(self, data):
        import json
        for field in ['token', 'team_name', 'toml_content']:
            if field in data and data[field]:
                data[field] = self.fernet.encrypt(data[field].encode()).decode()
        with open(self.config_path, 'w') as f:
            json.dump(data, f)
        set_strict_permissions(self.config_path)

# --- Secure all sensitive files on startup ---
for sensitive_file in ['netlify_config.json', 'security.key', '.env', '.env.encrypted']:
    if os.path.exists(sensitive_file):
        set_strict_permissions(sensitive_file)

def handle_env_decryption():
    """Handle .env file decryption before app startup"""
    # Process .env.encrypted if it exists
    if os.path.exists('.env.encrypted'):
        from PyQt6.QtWidgets import QInputDialog, QLineEdit, QMessageBox
        password, ok = QInputDialog.getText(None, 'Decrypt .env', 'Enter password to decrypt .env:', QLineEdit.EchoMode.Password)
        if ok and password:
            try:
                decrypt_env_file(password)
                load_dotenv(override=True)
            except Exception as e:
                QMessageBox.critical(None, 'Decryption Error', f'Failed to decrypt .env: {e}')
                sys.exit(1)
        else:
            sys.exit(1)


def main():
    """Application entry point."""
    app = QApplication(sys.argv)
    
    # Process .env.encrypted after QApplication is initialized
    if os.path.exists('.env.encrypted'):
        handle_env_decryption()
    window = MainWindow()
    window.show()
    sys.exit(app.exec())


if __name__ == '__main__':
    main()
