from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QLabel, QPushButton, QHBoxLayout,
    QFrame, QLineEdit, QFormLayout, QMessageBox, QListWidget,
    QListWidgetItem, QMenu, QWidgetAction, QApplication, QProgressBar
)
from PyQt6.QtCore import Qt, QUrl, QProcess
from PyQt6.QtGui import QFont, QIcon, QAction, QDesktopServices
import os
import json
import requests
import subprocess
import uuid
import time
from datetime import datetime


class DeploymentPreviewManager:
    """Manager for deployment preview functionality"""
    
    def __init__(self, main_window):
        self.main_window = main_window
        self.previews_file = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            'settings',
            'deployment_previews.json'
        )
        self.previews = []
        self.load_previews()
        
    def load_previews(self):
        """Load previews from file"""
        os.makedirs(os.path.dirname(self.previews_file), exist_ok=True)
        
        if os.path.exists(self.previews_file):
            try:
                with open(self.previews_file, 'r') as f:
                    self.previews = json.load(f)
            except json.JSONDecodeError:
                self.previews = []
        else:
            self.previews = []
            
    def save_previews(self):
        """Save previews to file"""
        os.makedirs(os.path.dirname(self.previews_file), exist_ok=True)
        
        with open(self.previews_file, 'w') as f:
            json.dump(self.previews, f, indent=4)
            
    def add_preview(self, preview_data):
        """Add a new preview"""
        preview_id = str(uuid.uuid4())
        preview_data["id"] = preview_id
        preview_data["created_at"] = int(time.time())
        
        self.previews.append(preview_data)
        self.save_previews()
        return preview_id
        
    def delete_preview(self, preview_id):
        """Delete a preview by ID"""
        for i, preview in enumerate(self.previews):
            if preview.get("id") == preview_id:
                self.previews.pop(i)
                self.save_previews()
                return True
        return False
    
    def show_previews_interface(self):
        """Show the deployment previews interface dialog"""
        dialog = PreviewsDialog(self.main_window, self)
        dialog.exec()
    
    def create_preview(self):
        """Create a new deployment preview"""
        dialog = CreatePreviewDialog(self.main_window, self)
        dialog.exec()


class PreviewsDialog(QDialog):
    """Dialog for managing deployment previews"""
    
    def __init__(self, parent, preview_manager):
        super().__init__(parent)
        self.preview_manager = preview_manager
        self.setWindowTitle("Deployment Previews")
        self.resize(700, 450)
        self.setup_ui()
        
    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)
        
        # Title
        title_label = QLabel("Deployment Preview Links")
        title_label.setFont(QFont("Segoe UI", 16, QFont.Weight.Bold))
        title_label.setStyleSheet("color: #0e639c;")
        layout.addWidget(title_label)
        
        # Description
        desc_label = QLabel(
            "Preview links allow you to share and test your deployments before they go live. "
            "Create unique preview URLs for each feature or branch to get feedback from stakeholders."
        )
        desc_label.setWordWrap(True)
        desc_label.setStyleSheet("color: #d4d4d4; font-size: 13px;")
        layout.addWidget(desc_label)
        
        # Separator
        separator = QFrame()
        separator.setFrameShape(QFrame.Shape.HLine)
        separator.setFrameShadow(QFrame.Shadow.Sunken)
        separator.setStyleSheet("background-color: #3c3c3c;")
        layout.addWidget(separator)
        
        # Preview list
        list_label = QLabel("Your Preview Deployments:")
        list_label.setFont(QFont("Segoe UI", 12, QFont.Weight.Bold))
        layout.addWidget(list_label)
        
        self.preview_list = QListWidget()
        self.preview_list.setStyleSheet("""
            QListWidget {
                background-color: #1e1e1e;
                border: 1px solid #333;
                border-radius: 4px;
                padding: 5px;
            }
            QListWidget::item {
                padding: 10px;
                border-bottom: 1px solid #333;
            }
            QListWidget::item:selected {
                background-color: #094771;
                color: #ffffff;
            }
        """)
        
        # Populate the list with actual previews
        self.populate_preview_list()
        layout.addWidget(self.preview_list)
        
        # Context menu for list items
        self.preview_list.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.preview_list.customContextMenuRequested.connect(self.show_context_menu)
        
        # Double-click to open preview URL
        self.preview_list.itemDoubleClicked.connect(self.open_preview_url)
        
        # Button row
        button_layout = QHBoxLayout()
        
        create_button = QPushButton("Create Preview")
        create_button.setStyleSheet("""
            QPushButton {
                background: #0e639c;
                color: #ffffff;
                border: none;
                border-radius: 4px;
                padding: 10px 16px;
            }
            QPushButton:hover {
                background: #1177bb;
            }
        """)
        create_button.clicked.connect(self.create_preview)
        
        close_button = QPushButton("Close")
        close_button.setFixedWidth(100)
        close_button.setStyleSheet("""
            QPushButton {
                background: #21252b;
                color: #d4d4d4;
                border: none;
                border-radius: 4px;
                padding: 10px 16px;
            }
            QPushButton:hover {
                background: #2c2c32;
            }
        """)
        close_button.clicked.connect(self.accept)
        
        button_layout.addWidget(create_button)
        button_layout.addStretch()
        button_layout.addWidget(close_button)
        layout.addLayout(button_layout)
    
    def populate_preview_list(self):
        """Populate the list with actual previews"""
        self.preview_list.clear()
        
        if not self.preview_manager.previews:
            # Add a placeholder message if no previews exist
            item = QListWidgetItem("No preview deployments found. Create one to get started!")
            item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsSelectable)
            self.preview_list.addItem(item)
            return
            
        for preview in self.preview_manager.previews:
            item = QListWidgetItem(f"{preview['name']} ({preview['branch']})")
            item.setData(Qt.ItemDataRole.UserRole, preview)
            self.preview_list.addItem(item)
    
    def show_context_menu(self, position):
        """Show context menu for preview list items"""
        item = self.preview_list.itemAt(position)
        if item and item.flags() & Qt.ItemFlag.ItemIsSelectable:
            menu = QMenu()
            menu.setStyleSheet("""
                QMenu {
                    background-color: #252526;
                    color: #cccccc;
                    border: 1px solid #3c3c3c;
                }
                QMenu::item:selected {
                    background-color: #094771;
                }
            """)
            
            open_action = QAction("Open Preview URL", self)
            open_action.triggered.connect(lambda: self.open_preview_url(item))
            
            copy_action = QAction("Copy URL", self)
            copy_action.triggered.connect(lambda: self.copy_url_to_clipboard(item))
            
            delete_action = QAction("Delete Preview", self)
            delete_action.triggered.connect(lambda: self.delete_preview(item))
            
            menu.addAction(open_action)
            menu.addAction(copy_action)
            menu.addSeparator()
            menu.addAction(delete_action)
            
            menu.exec(self.preview_list.mapToGlobal(position))
    
    def open_preview_url(self, item):
        """Open the preview URL in a browser"""
        preview_data = item.data(Qt.ItemDataRole.UserRole)
        if preview_data and 'url' in preview_data:
            QDesktopServices.openUrl(QUrl(preview_data['url']))
    
    def copy_url_to_clipboard(self, item):
        """Copy the preview URL to clipboard"""
        preview_data = item.data(Qt.ItemDataRole.UserRole)
        if preview_data and 'url' in preview_data:
            QApplication.clipboard().setText(preview_data['url'])
            QMessageBox.information(self, "URL Copied", "Preview URL has been copied to clipboard.")
    
    def delete_preview(self, item):
        """Delete a preview deployment"""
        preview_data = item.data(Qt.ItemDataRole.UserRole)
        if preview_data and 'id' in preview_data:
            confirm = QMessageBox.question(
                self,
                "Confirm Deletion",
                f"Are you sure you want to delete the preview '{preview_data['name']}'?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            
            if confirm == QMessageBox.StandardButton.Yes:
                self.preview_manager.delete_preview(preview_data['id'])
                self.populate_preview_list()
    
    def create_preview(self):
        dialog = CreatePreviewDialog(self.parent(), self.preview_manager)
        self.accept()  # Close current dialog
        dialog.exec()


class CreatePreviewDialog(QDialog):
    """Dialog for creating a new deployment preview"""
    
    def __init__(self, parent, preview_manager):
        super().__init__(parent)
        self.parent_window = parent
        self.preview_manager = preview_manager
        self.setWindowTitle("Create Deployment Preview")
        self.resize(600, 400)
        self.setup_ui()
        
    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)
        
        # Title
        title_label = QLabel("Create New Preview Deployment")
        title_label.setFont(QFont("Segoe UI", 16, QFont.Weight.Bold))
        title_label.setStyleSheet("color: #0e639c;")
        layout.addWidget(title_label)
        
        # Form layout
        form_layout = QFormLayout()
        form_layout.setSpacing(15)
        
        # Preview name
        self.preview_name = QLineEdit()
        self.preview_name.setStyleSheet("""
            QLineEdit {
                background: #1e1e1e;
                color: #d4d4d4;
                border: 1px solid #333;
                border-radius: 4px;
                padding: 8px;
            }
        """)
        self.preview_name.setPlaceholderText("e.g., Feature Preview, Client Demo")
        form_layout.addRow("Preview Name:", self.preview_name)
        
        # Branch or directory
        self.branch_name = QLineEdit()
        self.branch_name.setStyleSheet(self.preview_name.styleSheet())
        self.branch_name.setPlaceholderText("e.g., feature/new-header, PR-42")
        form_layout.addRow("Branch or Directory:", self.branch_name)
        
        # Custom subdomain
        self.subdomain = QLineEdit()
        self.subdomain.setStyleSheet(self.preview_name.styleSheet())
        self.subdomain.setPlaceholderText("e.g., new-header (becomes new-header--yoursite.netlify.app)")
        form_layout.addRow("Custom Subdomain:", self.subdomain)
        
        # Password protection
        self.password = QLineEdit()
        self.password.setStyleSheet(self.preview_name.styleSheet())
        self.password.setPlaceholderText("Optional: Require password to view preview")
        self.password.setEchoMode(QLineEdit.EchoMode.Password)
        form_layout.addRow("Password Protection:", self.password)
        
        # Expiration
        self.expiration = QLineEdit()
        self.expiration.setStyleSheet(self.preview_name.styleSheet())
        self.expiration.setPlaceholderText("e.g., 7 days (leave empty for no expiration)")
        form_layout.addRow("Expires After:", self.expiration)
        
        layout.addLayout(form_layout)
        
        # Button row
        button_layout = QHBoxLayout()
        
        create_button = QPushButton("Create Preview")
        create_button.setStyleSheet("""
            QPushButton {
                background: #0e639c;
                color: #ffffff;
                border: none;
                border-radius: 4px;
                padding: 10px 16px;
            }
            QPushButton:hover {
                background: #1177bb;
            }
        """)
        create_button.clicked.connect(self.create_preview)
        
        cancel_button = QPushButton("Cancel")
        cancel_button.setStyleSheet("""
            QPushButton {
                background: #21252b;
                color: #d4d4d4;
                border: none;
                border-radius: 4px;
                padding: 10px 16px;
            }
            QPushButton:hover {
                background: #2c2c32;
            }
        """)
        cancel_button.clicked.connect(self.reject)
        
        button_layout.addWidget(create_button)
        button_layout.addStretch()
        button_layout.addWidget(cancel_button)
        layout.addLayout(button_layout)
    
    def create_preview(self):
        """Create a new preview deployment"""
        # Validate inputs
        name = self.preview_name.text().strip()
        branch = self.branch_name.text().strip()
        subdomain = self.subdomain.text().strip()
        
        if not name:
            QMessageBox.warning(self, "Missing Information", "Please enter a name for the preview.")
            return
            
        if not branch:
            QMessageBox.warning(self, "Missing Information", "Please enter a branch or directory for the preview.")
            return
            
        if not subdomain:
            QMessageBox.warning(self, "Missing Information", "Please enter a subdomain for the preview URL.")
            return
        
        # Show deployment progress dialog
        progress_dialog = PreviewDeploymentProgressDialog(self.parent_window, name, branch, subdomain)
        self.accept()  # Close the create dialog
        
        if progress_dialog.exec() == QDialog.DialogCode.Accepted:
            # Deployment was successful, add to preview list
            preview_data = {
                "name": name,
                "branch": branch,
                "subdomain": subdomain,
                "url": f"https://{subdomain}--example.netlify.app",
                "password": self.password.text() if self.password.text() else None,
                "expiration": self.expiration.text() if self.expiration.text() else None,
                "status": "active"
            }
            
            self.preview_manager.add_preview(preview_data)
            
            # Show success message
            QMessageBox.information(
                self.parent_window,
                "Preview Created",
                f"Preview deployment created successfully!\nURL: {preview_data['url']}"
            )


class PreviewDeploymentProgressDialog(QDialog):
    """Dialog showing progress of preview deployment"""
    
    def __init__(self, parent, name, branch, subdomain):
        super().__init__(parent)
        self.name = name
        self.branch = branch
        self.subdomain = subdomain
        self.setWindowTitle("Deploying Preview")
        self.resize(500, 200)
        self.setup_ui()
        
    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)
        
        # Title
        title_label = QLabel(f"Deploying Preview: {self.name}")
        title_label.setFont(QFont("Segoe UI", 14, QFont.Weight.Bold))
        layout.addWidget(title_label)
        
        # Status label
        self.status_label = QLabel("Preparing deployment...")
        self.status_label.setStyleSheet("color: #d4d4d4;")
        layout.addWidget(self.status_label)
        
        # Progress bar
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.progress_bar.setStyleSheet("""
            QProgressBar {
                background-color: #1e1e1e;
                border: 1px solid #3c3c3c;
                border-radius: 2px;
                padding: 1px;
                text-align: center;
            }
            QProgressBar::chunk {
                background-color: #0e639c;
                width: 10px;
            }
        """)
        layout.addWidget(self.progress_bar)
        
        # Button row (initially disabled)
        button_layout = QHBoxLayout()
        
        self.open_button = QPushButton("Open Preview")
        self.open_button.setEnabled(False)
        self.open_button.setStyleSheet("""
            QPushButton {
                background: #0e639c;
                color: #ffffff;
                border: none;
                border-radius: 4px;
                padding: 10px 16px;
            }
            QPushButton:hover {
                background: #1177bb;
            }
            QPushButton:disabled {
                background: #333333;
                color: #888888;
            }
        """)
        self.open_button.clicked.connect(self.open_preview)
        
        self.close_button = QPushButton("Close")
        self.close_button.setEnabled(False)
        self.close_button.setStyleSheet("""
            QPushButton {
                background: #21252b;
                color: #d4d4d4;
                border: none;
                border-radius: 4px;
                padding: 10px 16px;
            }
            QPushButton:hover {
                background: #2c2c32;
            }
            QPushButton:disabled {
                background: #333333;
                color: #888888;
            }
        """)
        self.close_button.clicked.connect(self.accept)
        
        button_layout.addWidget(self.open_button)
        button_layout.addStretch()
        button_layout.addWidget(self.close_button)
        layout.addLayout(button_layout)
        
        # Start the deployment process
        QApplication.processEvents()
        self.simulate_deployment()
    
    def simulate_deployment(self):
        """Simulate the deployment process with a progress bar"""
        for i in range(1, 101):
            if i < 20:
                self.status_label.setText("Preparing deployment...")
            elif i < 40:
                self.status_label.setText("Building project...")
            elif i < 60:
                self.status_label.setText("Running tests...")
            elif i < 80:
                self.status_label.setText("Uploading to Netlify...")
            else:
                self.status_label.setText("Finalizing deployment...")
                
            self.progress_bar.setValue(i)
            QApplication.processEvents()
            time.sleep(0.05)  # Simulate work being done
        
        # Deployment complete
        self.status_label.setText(f"Deployment complete! URL: https://{self.subdomain}--example.netlify.app")
        self.open_button.setEnabled(True)
        self.close_button.setEnabled(True)
    
    def open_preview(self):
        """Open the preview URL in a browser"""
        QDesktopServices.openUrl(QUrl(f"https://{self.subdomain}--example.netlify.app"))
        self.accept() 