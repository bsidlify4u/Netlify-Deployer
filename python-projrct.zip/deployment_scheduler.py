"""
Deployment Scheduler Module for Netlify Deployer
Allows users to schedule deployments for specific times
"""

import os
import json
import time
from datetime import datetime, timedelta
import threading
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QPushButton, QLabel,
    QDateTimeEdit, QListWidget, QListWidgetItem, QCheckBox,
    QComboBox, QMessageBox, QTextEdit, QGridLayout, QSpinBox
)
from PyQt6.QtCore import QDateTime, Qt, QTimer, pyqtSignal, QObject

class DeploymentScheduler(QObject):
    """Manager for scheduling deployments"""
    
    deployment_ready = pyqtSignal(dict)
    
    def __init__(self, main_window):
        super().__init__()
        self.main_window = main_window
        self.schedule_file = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            'settings',
            'scheduled_deployments.json'
        )
        self.scheduled_deployments = []
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.check_scheduled_deployments)
        self.timer.start(60000)  # Check every minute
        self.load_scheduled_deployments()
        
    def load_scheduled_deployments(self):
        """Load scheduled deployments from file"""
        os.makedirs(os.path.dirname(self.schedule_file), exist_ok=True)
        
        if os.path.exists(self.schedule_file):
            try:
                with open(self.schedule_file, 'r') as f:
                    self.scheduled_deployments = json.load(f)
                    # Filter out expired deployments
                    now = time.time()
                    self.scheduled_deployments = [
                        d for d in self.scheduled_deployments
                        if d.get("timestamp", 0) > now
                    ]
            except json.JSONDecodeError:
                self.scheduled_deployments = []
        else:
            self.scheduled_deployments = []
    
    def save_scheduled_deployments(self):
        """Save scheduled deployments to file"""
        os.makedirs(os.path.dirname(self.schedule_file), exist_ok=True)
        
        with open(self.schedule_file, 'w') as f:
            json.dump(self.scheduled_deployments, f, indent=4)
    
    def schedule_deployment(self, deployment_config):
        """Add a new scheduled deployment"""
        if "timestamp" not in deployment_config:
            return False
        
        # Add unique ID for this scheduled deployment
        deployment_config["id"] = str(int(time.time())) + str(id(deployment_config))
        
        self.scheduled_deployments.append(deployment_config)
        self.scheduled_deployments.sort(key=lambda x: x.get("timestamp", 0))
        self.save_scheduled_deployments()
        return True
    
    def cancel_deployment(self, deployment_id):
        """Cancel a scheduled deployment by ID"""
        for i, deployment in enumerate(self.scheduled_deployments):
            if deployment.get("id") == deployment_id:
                self.scheduled_deployments.pop(i)
                self.save_scheduled_deployments()
                return True
        return False
    
    def check_scheduled_deployments(self):
        """Check for deployments that need to be run"""
        now = time.time()
        deployments_to_run = []
        
        # Find deployments that need to run
        for deployment in self.scheduled_deployments:
            if deployment.get("timestamp", 0) <= now:
                deployments_to_run.append(deployment)
        
        # Remove deployments from the list
        self.scheduled_deployments = [
            d for d in self.scheduled_deployments
            if d not in deployments_to_run
        ]
        self.save_scheduled_deployments()
        
        # Emit signal for each deployment to run
        for deployment in deployments_to_run:
            self.deployment_ready.emit(deployment)

    def show_schedule_dialog(self):
        """Show dialog to schedule a deployment"""
        dialog = ScheduleDeploymentDialog(self.main_window, self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            return True
        return False
    
    def show_manage_dialog(self):
        """Show dialog to manage scheduled deployments"""
        dialog = ManageScheduledDeploymentsDialog(self.main_window, self)
        dialog.exec()
        return True

class ScheduleDeploymentDialog(QDialog):
    """Dialog for scheduling a new deployment"""
    
    def __init__(self, parent, scheduler):
        super().__init__(parent)
        self.scheduler = scheduler
        self.main_window = parent
        
        self.setWindowTitle("Schedule Deployment")
        self.setMinimumWidth(500)
        self.setStyleSheet("""
            QDialog {
                background-color: #1e1e1e;
                color: #d4d4d4;
            }
        """)
        
        self.setup_ui()
    
    def setup_ui(self):
        layout = QVBoxLayout(self)
        
        # Header
        header_label = QLabel("Schedule Deployment")
        header_label.setStyleSheet("font-size: 16px; font-weight: bold; margin-bottom: 10px;")
        layout.addWidget(header_label)
        
        # Project info
        project_layout = QGridLayout()
        
        # Project directory
        project_label = QLabel("Project:")
        project_label.setStyleSheet("font-weight: bold;")
        project_value = QLabel(self.main_window.project_dir.text() or "Not set")
        project_value.setStyleSheet("color: #9cdcfe;")
        
        # Publish directory
        publish_label = QLabel("Publish Dir:")
        publish_label.setStyleSheet("font-weight: bold;")
        publish_value = QLabel(self.main_window.publish_dir.text() or "Not set")
        publish_value.setStyleSheet("color: #9cdcfe;")
        
        # Site name
        site_label = QLabel("Site Name:")
        site_label.setStyleSheet("font-weight: bold;")
        site_value = QLabel(self.main_window.site_name.text() or "Not set")
        site_value.setStyleSheet("color: #9cdcfe;")
        
        project_layout.addWidget(project_label, 0, 0)
        project_layout.addWidget(project_value, 0, 1)
        project_layout.addWidget(publish_label, 1, 0)
        project_layout.addWidget(publish_value, 1, 1)
        project_layout.addWidget(site_label, 2, 0)
        project_layout.addWidget(site_value, 2, 1)
        
        layout.addLayout(project_layout)
        
        # Schedule options
        options_label = QLabel("Schedule Options:")
        options_label.setStyleSheet("font-size: 14px; margin-top: 10px;")
        layout.addWidget(options_label)
        
        # Date and time picker
        time_layout = QHBoxLayout()
        
        time_label = QLabel("Date and Time:")
        time_label.setStyleSheet("min-width: 120px;")
        
        self.datetime_picker = QDateTimeEdit()
        self.datetime_picker.setDateTime(QDateTime.currentDateTime().addSecs(3600))
        self.datetime_picker.setMinimumDateTime(QDateTime.currentDateTime())
        self.datetime_picker.setCalendarPopup(True)
        self.datetime_picker.setStyleSheet("""
            QDateTimeEdit {
                background-color: #252525;
                color: #d4d4d4;
                border: 1px solid #3c3c3c;
                border-radius: 4px;
                padding: 5px;
                min-width: 200px;
            }
        """)
        
        time_layout.addWidget(time_label)
        time_layout.addWidget(self.datetime_picker)
        layout.addLayout(time_layout)
        
        # Recurring options
        recur_layout = QHBoxLayout()
        
        recur_label = QLabel("Recurring:")
        recur_label.setStyleSheet("min-width: 120px;")
        
        self.recurring_cb = QCheckBox("Enable recurring deployment")
        self.recurring_cb.setStyleSheet("""
            QCheckBox {
                color: #d4d4d4;
                font-size: 13px;
            }
            QCheckBox::indicator {
                width: 16px;
                height: 16px;
                border: 1px solid #3c3c3c;
                border-radius: 3px;
                background-color: #252525;
            }
            QCheckBox::indicator:checked {
                background-color: #0e639c;
            }
        """)
        
        recur_layout.addWidget(recur_label)
        recur_layout.addWidget(self.recurring_cb)
        layout.addLayout(recur_layout)
        
        # Recurring interval
        interval_layout = QHBoxLayout()
        
        interval_label = QLabel("Interval:")
        interval_label.setStyleSheet("min-width: 120px;")
        
        self.interval_spin = QSpinBox()
        self.interval_spin.setMinimum(1)
        self.interval_spin.setMaximum(999)
        self.interval_spin.setValue(24)
        self.interval_spin.setEnabled(False)
        self.interval_spin.setStyleSheet("""
            QSpinBox {
                background-color: #252525;
                color: #d4d4d4;
                border: 1px solid #3c3c3c;
                border-radius: 4px;
                padding: 5px;
                min-width: 60px;
            }
            QSpinBox:disabled {
                background-color: #2d2d2d;
                color: #777777;
            }
        """)
        
        self.interval_unit = QComboBox()
        self.interval_unit.addItems(["Hours", "Days", "Weeks"])
        self.interval_unit.setCurrentIndex(0)
        self.interval_unit.setEnabled(False)
        self.interval_unit.setStyleSheet("""
            QComboBox {
                background-color: #252525;
                color: #d4d4d4;
                border: 1px solid #3c3c3c;
                border-radius: 4px;
                padding: 5px;
                min-width: 100px;
            }
            QComboBox:disabled {
                background-color: #2d2d2d;
                color: #777777;
            }
            QComboBox::drop-down {
                border: 0px;
            }
            QComboBox QAbstractItemView {
                background-color: #252525;
                color: #d4d4d4;
                selection-background-color: #0e639c;
            }
        """)
        
        interval_layout.addWidget(interval_label)
        interval_layout.addWidget(self.interval_spin)
        interval_layout.addWidget(self.interval_unit)
        interval_layout.addStretch()
        layout.addLayout(interval_layout)
        
        # Build options
        build_layout = QHBoxLayout()
        
        build_label = QLabel("Build:")
        build_label.setStyleSheet("min-width: 120px;")
        
        self.build_cb = QCheckBox("Run build before deploy")
        self.build_cb.setChecked(True)
        self.build_cb.setStyleSheet(self.recurring_cb.styleSheet())
        
        self.prod_build_cb = QCheckBox("Production build")
        self.prod_build_cb.setChecked(True)
        self.prod_build_cb.setStyleSheet(self.recurring_cb.styleSheet())
        
        build_layout.addWidget(build_label)
        build_layout.addWidget(self.build_cb)
        build_layout.addWidget(self.prod_build_cb)
        layout.addLayout(build_layout)
        
        # Notes
        notes_layout = QHBoxLayout()
        
        notes_label = QLabel("Notes:")
        notes_label.setStyleSheet("min-width: 120px;")
        
        self.notes_edit = QTextEdit()
        self.notes_edit.setMaximumHeight(80)
        self.notes_edit.setPlaceholderText("Optional notes for this deployment")
        self.notes_edit.setStyleSheet("""
            QTextEdit {
                background-color: #252525;
                color: #d4d4d4;
                border: 1px solid #3c3c3c;
                font-size: 13px;
            }
        """)
        
        notes_layout.addWidget(notes_label)
        notes_layout.addWidget(self.notes_edit)
        layout.addLayout(notes_layout)
        
        # Buttons
        btn_layout = QHBoxLayout()
        
        schedule_btn = QPushButton("Schedule Deployment")
        schedule_btn.setStyleSheet("""
            QPushButton {
                background-color: #0e639c;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 8px 16px;
                font-size: 13px;
            }
            QPushButton:hover {
                background-color: #1177bb;
            }
            QPushButton:pressed {
                background-color: #0d5989;
            }
        """)
        
        cancel_btn = QPushButton("Cancel")
        cancel_btn.setStyleSheet("""
            QPushButton {
                background-color: #333333;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 8px 16px;
                font-size: 13px;
            }
            QPushButton:hover {
                background-color: #444444;
            }
            QPushButton:pressed {
                background-color: #2a2a2a;
            }
        """)
        
        btn_layout.addStretch()
        btn_layout.addWidget(schedule_btn)
        btn_layout.addWidget(cancel_btn)
        
        layout.addStretch()
        layout.addLayout(btn_layout)
        
        # Connect signals
        self.recurring_cb.toggled.connect(self.toggle_recurring_options)
        schedule_btn.clicked.connect(self.schedule_deployment)
        cancel_btn.clicked.connect(self.reject)
    
    def toggle_recurring_options(self, checked):
        """Enable or disable recurring options"""
        self.interval_spin.setEnabled(checked)
        self.interval_unit.setEnabled(checked)
    
    def schedule_deployment(self):
        """Schedule the deployment with the configured options"""
        # Validate inputs
        if not self.main_window.project_dir.text():
            QMessageBox.warning(self, "Missing Project", "Project directory must be specified")
            return
        
        if not self.main_window.publish_dir.text():
            QMessageBox.warning(self, "Missing Publish Directory", "Publish directory must be specified")
            return
        
        if not self.main_window.site_name.text():
            QMessageBox.warning(self, "Missing Site Name", "Site name must be specified")
            return
            
        # Create deployment config
        scheduled_time = self.datetime_picker.dateTime().toSecsSinceEpoch()
        
        if scheduled_time <= time.time():
            QMessageBox.warning(self, "Invalid Time", "Scheduled time must be in the future")
            return
        
        deployment_config = {
            "timestamp": scheduled_time,
            "project_dir": self.main_window.project_dir.text(),
            "publish_dir": self.main_window.publish_dir.text(),
            "site_name": self.main_window.site_name.text(),
            "team_name": getattr(self.main_window, "persistent_team", ""),
            "token": getattr(self.main_window, "persistent_token", ""),
            "build": self.build_cb.isChecked(),
            "production_build": self.prod_build_cb.isChecked(),
            "notes": self.notes_edit.toPlainText(),
            "scheduled_by": "User",
            "scheduled_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "recurring": self.recurring_cb.isChecked()
        }
        
        # Add recurring info if enabled
        if self.recurring_cb.isChecked():
            interval_value = self.interval_spin.value()
            interval_unit = self.interval_unit.currentText().lower()
            
            # Convert to seconds
            if interval_unit == "hours":
                interval_seconds = interval_value * 3600
            elif interval_unit == "days":
                interval_seconds = interval_value * 86400
            else:  # weeks
                interval_seconds = interval_value * 604800
                
            deployment_config["recurring_interval"] = interval_seconds
            deployment_config["interval_display"] = f"{interval_value} {interval_unit}"
        
        # Schedule the deployment
        if self.scheduler.schedule_deployment(deployment_config):
            self.accept()
        else:
            QMessageBox.critical(self, "Error", "Failed to schedule deployment")

class ManageScheduledDeploymentsDialog(QDialog):
    """Dialog for managing scheduled deployments"""
    
    def __init__(self, parent, scheduler):
        super().__init__(parent)
        self.scheduler = scheduler
        self.deployments = scheduler.scheduled_deployments
        
        self.setWindowTitle("Scheduled Deployments")
        self.setMinimumWidth(700)
        self.setMinimumHeight(400)
        self.setStyleSheet("""
            QDialog {
                background-color: #1e1e1e;
                color: #d4d4d4;
            }
        """)
        
        self.setup_ui()
        
        # Start a timer to update the countdown
        self.update_timer = QTimer(self)
        self.update_timer.timeout.connect(self.update_countdowns)
        self.update_timer.start(1000)  # Update every second
    
    def setup_ui(self):
        layout = QVBoxLayout(self)
        
        # Header
        header_label = QLabel("Scheduled Deployments")
        header_label.setStyleSheet("font-size: 16px; font-weight: bold; margin-bottom: 10px;")
        layout.addWidget(header_label)
        
        # No scheduled deployments message
        if not self.deployments:
            no_deployments_label = QLabel("No scheduled deployments")
            no_deployments_label.setStyleSheet("color: #777777; font-size: 14px; padding: 20px;")
            no_deployments_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            layout.addWidget(no_deployments_label)
        else:
            # Deployments list
            self.list_widget = QListWidget()
            self.list_widget.setStyleSheet("""
                QListWidget {
                    background-color: #252525;
                    color: #d4d4d4;
                    border: 1px solid #3c3c3c;
                    border-radius: 4px;
                    padding: 5px;
                    font-size: 13px;
                }
                QListWidget::item {
                    padding: 10px;
                    border-bottom: 1px solid #333;
                }
                QListWidget::item:selected {
                    background-color: #0e639c;
                }
            """)
            
            # Add deployments to list
            for deployment in self.deployments:
                self.add_deployment_to_list(deployment)
            
            layout.addWidget(self.list_widget)
        
        # Buttons
        btn_layout = QHBoxLayout()
        
        new_btn = QPushButton("New Schedule")
        new_btn.setStyleSheet("""
            QPushButton {
                background-color: #0e639c;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 8px 16px;
                font-size: 13px;
            }
            QPushButton:hover {
                background-color: #1177bb;
            }
            QPushButton:pressed {
                background-color: #0d5989;
            }
        """)
        
        self.cancel_btn = QPushButton("Cancel Selected")
        self.cancel_btn.setEnabled(len(self.deployments) > 0)
        self.cancel_btn.setStyleSheet("""
            QPushButton {
                background-color: #c72c41;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 8px 16px;
                font-size: 13px;
            }
            QPushButton:hover {
                background-color: #d13651;
            }
            QPushButton:pressed {
                background-color: #b02739;
            }
            QPushButton:disabled {
                background-color: #666666;
                color: #aaaaaa;
            }
        """)
        
        close_btn = QPushButton("Close")
        close_btn.setStyleSheet("""
            QPushButton {
                background-color: #333333;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 8px 16px;
                font-size: 13px;
            }
            QPushButton:hover {
                background-color: #444444;
            }
            QPushButton:pressed {
                background-color: #2a2a2a;
            }
        """)
        
        btn_layout.addWidget(new_btn)
        if self.deployments:
            btn_layout.addWidget(self.cancel_btn)
        btn_layout.addStretch()
        btn_layout.addWidget(close_btn)
        
        layout.addLayout(btn_layout)
        
        # Connect signals
        new_btn.clicked.connect(self.new_schedule)
        if self.deployments:
            self.cancel_btn.clicked.connect(self.cancel_selected)
        close_btn.clicked.connect(self.accept)
    
    def add_deployment_to_list(self, deployment):
        """Add a deployment to the list widget with formatted display"""
        timestamp = deployment.get("timestamp", 0)
        dt = datetime.fromtimestamp(timestamp)
        
        # Format the basic info
        site_name = deployment.get("site_name", "Unknown")
        scheduled_time = dt.strftime("%Y-%m-%d %H:%M:%S")
        
        # Display if it's recurring
        recurring_text = ""
        if deployment.get("recurring", False):
            interval_display = deployment.get("interval_display", "")
            recurring_text = f" (Recurring: {interval_display})"
            
        # Create the display text
        display_text = f"{site_name}: {scheduled_time}{recurring_text}"
        
        # Create countdown text
        seconds_left = max(0, timestamp - time.time())
        countdown = self.format_countdown(seconds_left)
        
        # Full item text
        full_text = f"{display_text}\nCountdown: {countdown}"
        
        # Create list item
        item = QListWidgetItem(full_text)
        item.setData(Qt.ItemDataRole.UserRole, deployment.get("id"))
        
        self.list_widget.addItem(item)
    
    def format_countdown(self, seconds):
        """Format seconds into a human-readable countdown"""
        if seconds <= 0:
            return "Ready to deploy"
            
        days, remainder = divmod(seconds, 86400)
        hours, remainder = divmod(remainder, 3600)
        minutes, seconds = divmod(remainder, 60)
        
        parts = []
        if days > 0:
            parts.append(f"{int(days)} day{'s' if days != 1 else ''}")
        if hours > 0 or days > 0:
            parts.append(f"{int(hours)} hour{'s' if hours != 1 else ''}")
        if minutes > 0 or hours > 0 or days > 0:
            parts.append(f"{int(minutes)} minute{'s' if minutes != 1 else ''}")
        parts.append(f"{int(seconds)} second{'s' if seconds != 1 else ''}")
        
        return ", ".join(parts)
    
    def update_countdowns(self):
        """Update all countdown displays"""
        if not hasattr(self, "list_widget"):
            return
            
        for i in range(self.list_widget.count()):
            item = self.list_widget.item(i)
            deployment_id = item.data(Qt.ItemDataRole.UserRole)
            
            # Find the deployment
            for deployment in self.deployments:
                if deployment.get("id") == deployment_id:
                    timestamp = deployment.get("timestamp", 0)
                    seconds_left = max(0, timestamp - time.time())
                    
                    # Get the display text without countdown
                    display_text = item.text().split("\n")[0]
                    
                    # Update with new countdown
                    countdown = self.format_countdown(seconds_left)
                    item.setText(f"{display_text}\nCountdown: {countdown}")
                    break
    
    def new_schedule(self):
        """Open dialog to create a new scheduled deployment"""
        dialog = ScheduleDeploymentDialog(self.parent(), self.scheduler)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.accept()
            # Reopen the manage dialog with updated data
            self.scheduler.show_manage_dialog()
    
    def cancel_selected(self):
        """Cancel the selected scheduled deployment"""
        selected_items = self.list_widget.selectedItems()
        if not selected_items:
            QMessageBox.warning(self, "No Selection", "Please select a scheduled deployment to cancel")
            return
            
        item = selected_items[0]
        deployment_id = item.data(Qt.ItemDataRole.UserRole)
        
        # Confirm cancellation
        msg_box = QMessageBox(self)
        msg_box.setWindowTitle("Confirm Cancellation")
        msg_box.setText("Are you sure you want to cancel this scheduled deployment?")
        msg_box.setStandardButtons(QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        msg_box.setDefaultButton(QMessageBox.StandardButton.No)
        msg_box.setStyleSheet("""
            QMessageBox {
                background-color: #1e1e1e;
                color: #d4d4d4;
            }
            QPushButton {
                background-color: #333333;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 8px 16px;
                font-size: 13px;
            }
            QPushButton:hover {
                background-color: #444444;
            }
        """)
        
        if msg_box.exec() == QMessageBox.StandardButton.Yes:
            if self.scheduler.cancel_deployment(deployment_id):
                self.list_widget.takeItem(self.list_widget.row(item))
                if self.list_widget.count() == 0:
                    self.accept()
                    # Reopen the manage dialog with updated (empty) data
                    self.scheduler.show_manage_dialog() 