"""
Environment Variable Manager Module for Netlify Deployer
Securely manage and deploy environment variables for Netlify sites
"""

import os
import json
from datetime import datetime
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QPushButton, QLabel,
    QTableWidget, QTableWidgetItem, QLineEdit, QMessageBox,
    QHeaderView, QComboBox, QCheckBox, QFileDialog
)
from PyQt6.QtCore import Qt, QSize

class EnvironmentManager:
    """Manager for environment variables"""
    
    def __init__(self, main_window):
        self.main_window = main_window
        self.env_vars_file = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            'settings',
            'environment_vars.json'
        )
        self.env_vars = self.load_env_vars()
    
    def load_env_vars(self):
        """Load environment variables from file"""
        os.makedirs(os.path.dirname(self.env_vars_file), exist_ok=True)
        
        if os.path.exists(self.env_vars_file):
            try:
                with open(self.env_vars_file, 'r') as f:
                    # Load and decrypt
                    encrypted_data = json.load(f)
                    decrypted_data = {}
                    
                    # Decrypt each site's variables
                    for site_name, vars_data in encrypted_data.items():
                        decrypted_data[site_name] = []
                        for var in vars_data:
                            if 'value' in var and var['value']:
                                try:
                                    var['value'] = self.main_window.security.decrypt(var['value'])
                                except Exception:
                                    # If decryption fails, set to empty string
                                    var['value'] = ""
                            decrypted_data[site_name].append(var)
                    
                    return decrypted_data
            except Exception:
                return {}
        else:
            return {}
    
    def save_env_vars(self):
        """Save environment variables to file"""
        os.makedirs(os.path.dirname(self.env_vars_file), exist_ok=True)
        
        # Create copy for encryption
        encrypted_data = {}
        
        # Encrypt each site's variables
        for site_name, vars_data in self.env_vars.items():
            encrypted_data[site_name] = []
            for var in vars_data:
                # Create a copy to avoid modifying the original
                var_copy = var.copy()
                if 'value' in var_copy and var_copy['value']:
                    try:
                        var_copy['value'] = self.main_window.security.encrypt(var_copy['value'])
                    except Exception:
                        var_copy['value'] = ""
                encrypted_data[site_name].append(var_copy)
        
        with open(self.env_vars_file, 'w') as f:
            json.dump(encrypted_data, f, indent=4)
    
    def get_vars_for_site(self, site_name):
        """Get environment variables for a specific site"""
        if site_name not in self.env_vars:
            return []
        return self.env_vars[site_name]
    
    def add_var_to_site(self, site_name, key, value, is_sensitive=False):
        """Add or update an environment variable for a site"""
        if site_name not in self.env_vars:
            self.env_vars[site_name] = []
        
        # Check if key already exists
        for var in self.env_vars[site_name]:
            if var['key'] == key:
                var['value'] = value
                var['sensitive'] = is_sensitive
                var['updated_at'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                self.save_env_vars()
                return True
        
        # Add new var
        self.env_vars[site_name].append({
            'key': key,
            'value': value,
            'sensitive': is_sensitive,
            'created_at': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            'updated_at': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        })
        self.save_env_vars()
        return True
    
    def delete_var_from_site(self, site_name, key):
        """Delete an environment variable from a site"""
        if site_name not in self.env_vars:
            return False
            
        for i, var in enumerate(self.env_vars[site_name]):
            if var['key'] == key:
                self.env_vars[site_name].pop(i)
                self.save_env_vars()
                return True
                
        return False
    
    def import_from_dotenv(self, site_name, file_path):
        """Import environment variables from a .env file"""
        if not os.path.exists(file_path):
            return False
            
        try:
            with open(file_path, 'r') as f:
                lines = f.readlines()
                
            count = 0
            for line in lines:
                line = line.strip()
                # Skip comments and empty lines
                if not line or line.startswith('#'):
                    continue
                
                # Split only at the first equals sign
                parts = line.split('=', 1)
                if len(parts) == 2:
                    key = parts[0].strip()
                    value = parts[1].strip()
                    
                    # Remove quotes if present
                    if (value.startswith('"') and value.endswith('"')) or \
                       (value.startswith("'") and value.endswith("'")):
                        value = value[1:-1]
                        
                    self.add_var_to_site(site_name, key, value)
                    count += 1
                    
            return count
        except Exception:
            return False
    
    def export_to_dotenv(self, site_name, file_path):
        """Export environment variables to a .env file"""
        if site_name not in self.env_vars:
            return False
            
        try:
            with open(file_path, 'w') as f:
                f.write("# Environment variables for Netlify site: {}\n".format(site_name))
                f.write("# Generated by Netlify Deployer on {}\n\n".format(
                    datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                ))
                
                for var in self.env_vars[site_name]:
                    f.write("{}={}\n".format(var['key'], var['value']))
                    
            return True
        except Exception:
            return False
    
    def export_to_netlify_cli(self, site_name, file_path):
        """Export environment variables to a shell script for Netlify CLI"""
        if site_name not in self.env_vars:
            return False
            
        try:
            with open(file_path, 'w') as f:
                f.write("#!/bin/bash\n\n")
                f.write("# Netlify environment variables for site: {}\n".format(site_name))
                f.write("# Generated by Netlify Deployer on {}\n".format(
                    datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                ))
                f.write("# Run this script to set up variables with Netlify CLI\n\n")
                
                for var in self.env_vars[site_name]:
                    f.write("netlify env:set {} \"{}\"\n".format(var['key'], var['value']))
                    
            return True
        except Exception:
            return False
    
    def deploy_env_vars(self, site_name, site_id, netlify_token):
        """Deploy environment variables to Netlify site via API"""
        # To be implemented with Netlify API integration
        # This requires making API calls to: https://api.netlify.com/api/v1/sites/{site_id}/env?access_token={netlify_token}
        pass
    
    def show_env_manager_dialog(self):
        """Show dialog for managing environment variables"""
        dialog = EnvManagerDialog(self.main_window, self)
        dialog.exec()
        return True

class EnvManagerDialog(QDialog):
    """Dialog for managing environment variables"""
    
    def __init__(self, parent, env_manager):
        super().__init__(parent)
        self.env_manager = env_manager
        self.main_window = parent
        
        # Get current site
        self.current_site = self.main_window.site_name.text()
        
        self.setWindowTitle("Environment Variables Manager")
        self.setMinimumWidth(800)
        self.setMinimumHeight(500)
        self.setStyleSheet("""
            QDialog {
                background-color: #1e1e1e;
                color: #d4d4d4;
            }
        """)
        
        self.setup_ui()
        
    def setup_ui(self):
        layout = QVBoxLayout(self)
        
        # Header
        header_layout = QHBoxLayout()
        
        header_label = QLabel("Environment Variables Manager")
        header_label.setStyleSheet("font-size: 16px; font-weight: bold; margin-bottom: 10px;")
        
        site_selector_layout = QHBoxLayout()
        site_label = QLabel("Site:")
        site_label.setStyleSheet("margin-right: 5px;")
        
        self.site_selector = QComboBox()
        self.site_selector.setStyleSheet("""
            QComboBox {
                background-color: #252525;
                color: #d4d4d4;
                border: 1px solid #3c3c3c;
                border-radius: 4px;
                padding: 5px;
                min-width: 200px;
            }
            QComboBox::drop-down {
                border: 0px;
            }
            QComboBox QAbstractItemView {
                background-color: #252525;
                color: #d4d4d4;
                selection-background-color: #0e639c;
            }
        """)
        
        # Fill site selector with available sites
        sites = list(self.env_manager.env_vars.keys())
        if self.current_site and self.current_site not in sites:
            sites.append(self.current_site)
            
        if sites:
            self.site_selector.addItems(sites)
            # Set current site if available
            if self.current_site:
                index = self.site_selector.findText(self.current_site)
                if index >= 0:
                    self.site_selector.setCurrentIndex(index)
        else:
            # No sites yet, add current if available
            if self.current_site:
                self.site_selector.addItem(self.current_site)
            else:
                self.site_selector.addItem("New Site")
                
        site_selector_layout.addWidget(site_label)
        site_selector_layout.addWidget(self.site_selector)
        
        header_layout.addWidget(header_label)
        header_layout.addStretch()
        header_layout.addLayout(site_selector_layout)
        
        layout.addLayout(header_layout)
        
        # Variables table
        self.vars_table = QTableWidget(0, 3)  # Rows will be added dynamically
        self.vars_table.setHorizontalHeaderLabels(["Key", "Value", "Sensitive"])
        self.vars_table.horizontalHeader().setStretchLastSection(False)
        self.vars_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.vars_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.vars_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        self.vars_table.setStyleSheet("""
            QTableWidget {
                background-color: #252525;
                color: #d4d4d4;
                border: 1px solid #3c3c3c;
                border-radius: 4px;
            }
            QTableWidget::item {
                padding: 8px;
            }
            QTableWidget::item:selected {
                background-color: #094771;
            }
            QHeaderView::section {
                background-color: #2d2d2d;
                color: #d4d4d4;
                padding: 5px;
                border: none;
                font-weight: bold;
            }
        """)
        
        layout.addWidget(self.vars_table)
        
        # Add variable section
        add_var_layout = QHBoxLayout()
        
        self.key_edit = QLineEdit()
        self.key_edit.setPlaceholderText("Variable Name")
        self.key_edit.setStyleSheet("""
            QLineEdit {
                background-color: #252525;
                color: #d4d4d4;
                border: 1px solid #3c3c3c;
                border-radius: 4px;
                padding: 5px;
            }
        """)
        
        self.value_edit = QLineEdit()
        self.value_edit.setPlaceholderText("Variable Value")
        self.value_edit.setStyleSheet(self.key_edit.styleSheet())
        
        self.sensitive_cb = QCheckBox("Sensitive")
        self.sensitive_cb.setStyleSheet("""
            QCheckBox {
                color: #d4d4d4;
                padding: 5px;
            }
            QCheckBox::indicator {
                width: 16px;
                height: 16px;
                border: 1px solid #3c3c3c;
                border-radius: 3px;
                background-color: #252525;
            }
            QCheckBox::indicator:checked {
                background-color: #0e639c;
            }
        """)
        
        add_btn = QPushButton("Add")
        add_btn.setStyleSheet("""
            QPushButton {
                background-color: #0e639c;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 5px 16px;
                font-size: 13px;
            }
            QPushButton:hover {
                background-color: #1177bb;
            }
            QPushButton:pressed {
                background-color: #0d5989;
            }
        """)
        
        add_var_layout.addWidget(self.key_edit)
        add_var_layout.addWidget(self.value_edit)
        add_var_layout.addWidget(self.sensitive_cb)
        add_var_layout.addWidget(add_btn)
        
        layout.addLayout(add_var_layout)
        
        # Action buttons
        action_layout = QHBoxLayout()
        
        delete_btn = QPushButton("Delete Selected")
        delete_btn.setStyleSheet("""
            QPushButton {
                background-color: #c72c41;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 8px 16px;
                font-size: 13px;
            }
            QPushButton:hover {
                background-color: #d13651;
            }
            QPushButton:pressed {
                background-color: #b02739;
            }
        """)
        
        import_btn = QPushButton("Import from .env")
        import_btn.setStyleSheet("""
            QPushButton {
                background-color: #333333;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 8px 16px;
                font-size: 13px;
            }
            QPushButton:hover {
                background-color: #444444;
            }
            QPushButton:pressed {
                background-color: #2a2a2a;
            }
        """)
        
        export_btn = QPushButton("Export")
        export_btn.setStyleSheet(import_btn.styleSheet())
        
        deploy_btn = QPushButton("Deploy to Netlify")
        deploy_btn.setStyleSheet("""
            QPushButton {
                background-color: #0e639c;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 8px 16px;
                font-size: 13px;
            }
            QPushButton:hover {
                background-color: #1177bb;
            }
            QPushButton:pressed {
                background-color: #0d5989;
            }
        """)
        
        close_btn = QPushButton("Close")
        close_btn.setStyleSheet(import_btn.styleSheet())
        
        action_layout.addWidget(delete_btn)
        action_layout.addWidget(import_btn)
        action_layout.addWidget(export_btn)
        action_layout.addStretch()
        action_layout.addWidget(deploy_btn)
        action_layout.addWidget(close_btn)
        
        layout.addLayout(action_layout)
        
        # Connect signals
        self.site_selector.currentIndexChanged.connect(self.load_site_vars)
        add_btn.clicked.connect(self.add_variable)
        delete_btn.clicked.connect(self.delete_variable)
        import_btn.clicked.connect(self.import_from_dotenv)
        export_btn.clicked.connect(self.show_export_options)
        deploy_btn.clicked.connect(self.deploy_variables)
        close_btn.clicked.connect(self.accept)
        
        # Load variables for current site
        self.load_site_vars()
        
    def load_site_vars(self):
        """Load environment variables for the selected site"""
        site_name = self.site_selector.currentText()
        
        # Clear table
        self.vars_table.setRowCount(0)
        
        # Load variables
        vars_data = self.env_manager.get_vars_for_site(site_name)
        
        for i, var in enumerate(vars_data):
            key = var.get('key', '')
            value = var.get('value', '')
            sensitive = var.get('sensitive', False)
            
            self.vars_table.insertRow(i)
            
            # Key item
            key_item = QTableWidgetItem(key)
            self.vars_table.setItem(i, 0, key_item)
            
            # Value item - mask if sensitive
            value_display = '••••••••' if sensitive else value
            value_item = QTableWidgetItem(value_display)
            value_item.setData(Qt.ItemDataRole.UserRole, value)  # Store actual value
            self.vars_table.setItem(i, 1, value_item)
            
            # Sensitive checkbox
            sensitive_item = QTableWidgetItem()
            sensitive_item.setFlags(Qt.ItemFlag.ItemIsUserCheckable | Qt.ItemFlag.ItemIsEnabled)
            sensitive_item.setCheckState(Qt.CheckState.Checked if sensitive else Qt.CheckState.Unchecked)
            self.vars_table.setItem(i, 2, sensitive_item)
            
    def add_variable(self):
        """Add a new environment variable"""
        key = self.key_edit.text().strip()
        value = self.value_edit.text().strip()
        sensitive = self.sensitive_cb.isChecked()
        site_name = self.site_selector.currentText()
        
        if not key:
            QMessageBox.warning(self, "Missing Key", "Variable name is required")
            return
            
        # Add to manager
        if self.env_manager.add_var_to_site(site_name, key, value, sensitive):
            # Clear inputs
            self.key_edit.clear()
            self.value_edit.clear()
            self.sensitive_cb.setChecked(False)
            
            # Reload vars
            self.load_site_vars()
            
    def delete_variable(self):
        """Delete selected environment variable"""
        selected_rows = set([index.row() for index in self.vars_table.selectedIndexes()])
        
        if not selected_rows:
            QMessageBox.warning(self, "No Selection", "Please select a variable to delete")
            return
            
        site_name = self.site_selector.currentText()
        
        for row in sorted(list(selected_rows), reverse=True):
            key = self.vars_table.item(row, 0).text()
            self.env_manager.delete_var_from_site(site_name, key)
            
        # Reload vars
        self.load_site_vars()
        
    def import_from_dotenv(self):
        """Import variables from a .env file"""
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Select .env File",
            "",
            "Environment Files (*.env);;All Files (*.*)"
        )
        
        if file_path:
            site_name = self.site_selector.currentText()
            count = self.env_manager.import_from_dotenv(site_name, file_path)
            
            if count:
                QMessageBox.information(
                    self,
                    "Import Successful",
                    f"Successfully imported {count} environment variables"
                )
                # Reload vars
                self.load_site_vars()
            else:
                QMessageBox.warning(
                    self,
                    "Import Failed",
                    "Failed to import environment variables"
                )
                
    def show_export_options(self):
        """Show export options dialog"""
        dialog = ExportOptionsDialog(self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            export_type = dialog.selected_option
            site_name = self.site_selector.currentText()
            
            if export_type == "dotenv":
                self.export_to_dotenv(site_name)
            elif export_type == "netlify_cli":
                self.export_to_netlify_cli(site_name)
    
    def export_to_dotenv(self, site_name):
        """Export variables to a .env file"""
        file_path, _ = QFileDialog.getSaveFileName(
            self,
            "Save .env File",
            f"{site_name}.env",
            "Environment Files (*.env);;All Files (*.*)"
        )
        
        if file_path:
            if self.env_manager.export_to_dotenv(site_name, file_path):
                QMessageBox.information(
                    self,
                    "Export Successful",
                    "Environment variables successfully exported to .env file"
                )
            else:
                QMessageBox.warning(
                    self,
                    "Export Failed",
                    "Failed to export environment variables"
                )
    
    def export_to_netlify_cli(self, site_name):
        """Export variables to a Netlify CLI script"""
        file_path, _ = QFileDialog.getSaveFileName(
            self,
            "Save Netlify CLI Script",
            f"{site_name}_netlify_env.sh",
            "Shell Scripts (*.sh);;All Files (*.*)"
        )
        
        if file_path:
            if self.env_manager.export_to_netlify_cli(site_name, file_path):
                QMessageBox.information(
                    self,
                    "Export Successful",
                    "Environment variables successfully exported to Netlify CLI script"
                )
            else:
                QMessageBox.warning(
                    self,
                    "Export Failed",
                    "Failed to export environment variables"
                )
                
    def deploy_variables(self):
        """Deploy variables to Netlify site"""
        site_name = self.site_selector.currentText()
        token = getattr(self.main_window, "persistent_token", "")
        
        if not token:
            QMessageBox.warning(
                self,
                "Missing Token",
                "Netlify API token is required to deploy environment variables"
            )
            return
            
        # This would need to be implemented with Netlify API integration
        QMessageBox.information(
            self,
            "Feature Coming Soon",
            "Direct deployment of environment variables will be available soon!"
        )

class ExportOptionsDialog(QDialog):
    """Dialog for selecting export options"""
    
    def __init__(self, parent):
        super().__init__(parent)
        self.selected_option = "dotenv"  # Default
        
        self.setWindowTitle("Export Options")
        self.setMinimumWidth(400)
        self.setStyleSheet("""
            QDialog {
                background-color: #1e1e1e;
                color: #d4d4d4;
            }
        """)
        
        self.setup_ui()
        
    def setup_ui(self):
        layout = QVBoxLayout(self)
        
        header_label = QLabel("Select Export Format")
        header_label.setStyleSheet("font-size: 14px; font-weight: bold; margin-bottom: 10px;")
        layout.addWidget(header_label)
        
        # Option: .env file
        self.dotenv_rb = QCheckBox(".env file (for local development)")
        self.dotenv_rb.setChecked(True)
        self.dotenv_rb.setStyleSheet("""
            QCheckBox {
                color: #d4d4d4;
                padding: 5px;
                font-size: 13px;
            }
            QCheckBox::indicator {
                width: 16px;
                height: 16px;
                border: 1px solid #3c3c3c;
                border-radius: 3px;
                background-color: #252525;
            }
            QCheckBox::indicator:checked {
                background-color: #0e639c;
            }
        """)
        layout.addWidget(self.dotenv_rb)
        
        # Option: Netlify CLI script
        self.netlify_cli_rb = QCheckBox("Netlify CLI script (for deployment)")
        self.netlify_cli_rb.setStyleSheet(self.dotenv_rb.styleSheet())
        layout.addWidget(self.netlify_cli_rb)
        
        # Buttons
        btn_layout = QHBoxLayout()
        
        export_btn = QPushButton("Export")
        export_btn.setStyleSheet("""
            QPushButton {
                background-color: #0e639c;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 8px 16px;
                font-size: 13px;
            }
            QPushButton:hover {
                background-color: #1177bb;
            }
            QPushButton:pressed {
                background-color: #0d5989;
            }
        """)
        
        cancel_btn = QPushButton("Cancel")
        cancel_btn.setStyleSheet("""
            QPushButton {
                background-color: #333333;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 8px 16px;
                font-size: 13px;
            }
            QPushButton:hover {
                background-color: #444444;
            }
            QPushButton:pressed {
                background-color: #2a2a2a;
            }
        """)
        
        btn_layout.addStretch()
        btn_layout.addWidget(export_btn)
        btn_layout.addWidget(cancel_btn)
        
        layout.addStretch()
        layout.addLayout(btn_layout)
        
        # Connect signals
        self.dotenv_rb.toggled.connect(self.on_option_toggled)
        self.netlify_cli_rb.toggled.connect(self.on_option_toggled)
        export_btn.clicked.connect(self.accept)
        cancel_btn.clicked.connect(self.reject)
        
    def on_option_toggled(self):
        """Handle option selection"""
        if self.sender() == self.dotenv_rb and self.dotenv_rb.isChecked():
            self.netlify_cli_rb.setChecked(False)
            self.selected_option = "dotenv"
        elif self.sender() == self.netlify_cli_rb and self.netlify_cli_rb.isChecked():
            self.dotenv_rb.setChecked(False)
            self.selected_option = "netlify_cli" 