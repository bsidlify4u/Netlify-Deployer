"""
Feature Integration Module for Netlify Deployer
Integrates all the new features into the main application
"""

import os
import sys
import logging

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("feature_integration")

from PyQt6.QtWidgets import QMenu, QMessageBox, QDialog
from PyQt6.QtCore import QObject
from PyQt6.QtGui import QAction

# Log Python path to help diagnose import issues
logger.info(f"Python path: {sys.path}")
logger.info(f"Current directory: {os.getcwd()}")

# Import the feature modules
try:
    from project_templates import TemplateManager
    TEMPLATES_AVAILABLE = True
    logger.info("Loaded project_templates module")
except ImportError as e:
    TEMPLATES_AVAILABLE = False
    logger.error(f"Failed to import project_templates: {str(e)}")

try:
    from deployment_scheduler import DeploymentScheduler
    SCHEDULER_AVAILABLE = True
    logger.info("Loaded deployment_scheduler module")
except ImportError as e:
    SCHEDULER_AVAILABLE = False
    logger.error(f"Failed to import deployment_scheduler: {str(e)}")

try:
    from env_manager import EnvironmentManager
    ENV_MANAGER_AVAILABLE = True
    logger.info("Loaded env_manager module")
except ImportError as e:
    ENV_MANAGER_AVAILABLE = False
    logger.error(f"Failed to import env_manager: {str(e)}")

try:
    from analytics_dashboard import AnalyticsDashboard
    ANALYTICS_AVAILABLE = True
    logger.info("Loaded analytics_dashboard module")
except ImportError as e:
    ANALYTICS_AVAILABLE = False
    logger.error(f"Failed to import analytics_dashboard: {str(e)}")

try:
    from multisite_manager import MultisiteManager
    MULTISITE_AVAILABLE = True
    logger.info("Loaded multisite_manager module")
except ImportError as e:
    MULTISITE_AVAILABLE = False
    logger.error(f"Failed to import multisite_manager: {str(e)}")

try:
    from ab_testing import ABTestingManager
    AB_TESTING_AVAILABLE = True
    logger.info("Loaded ab_testing module")
except ImportError as e:
    AB_TESTING_AVAILABLE = False
    logger.error(f"Failed to import ab_testing: {str(e)}")

try:
    from deployment_previews import DeploymentPreviewManager
    PREVIEW_AVAILABLE = True
    logger.info("Loaded deployment_previews module")
except ImportError as e:
    PREVIEW_AVAILABLE = False
    logger.error(f"Failed to import deployment_previews: {str(e)}")

# Webhook notifications feature has been removed
WEBHOOKS_AVAILABLE = False
logger.info("Webhook notifications feature has been removed")

# Check if GitHub integration is available
try:
    from github_integration import GitHubManager
    GITHUB_AVAILABLE = True
    logger.info("Loaded github_integration module")
except ImportError as e:
    GITHUB_AVAILABLE = False
    logger.error(f"Failed to import github_integration: {str(e)}")

logger.info(f"Features available: Templates={TEMPLATES_AVAILABLE}, Scheduler={SCHEDULER_AVAILABLE}, Env={ENV_MANAGER_AVAILABLE}, Analytics={ANALYTICS_AVAILABLE}, Multisite={MULTISITE_AVAILABLE}, AB={AB_TESTING_AVAILABLE}, Preview={PREVIEW_AVAILABLE}, Webhooks={WEBHOOKS_AVAILABLE}, GitHub={GITHUB_AVAILABLE}")

class FeatureIntegration(QObject):
    """Class to integrate all features with the main application"""
    
    def __init__(self, main_window):
        super().__init__(None)  # Pass None instead of main_window to QObject constructor
        self.main_window = main_window
        
        # Initialize feature managers
        self.feature_managers = {}
        self.init_feature_managers()
        
        # Connect deployment scheduler to main window
        if SCHEDULER_AVAILABLE:
            self.feature_managers["scheduler"].deployment_ready.connect(
                self.handle_scheduled_deployment
            )
    
    def init_feature_managers(self):
        """Initialize all feature managers"""
        if TEMPLATES_AVAILABLE:
            self.feature_managers["templates"] = TemplateManager(self.main_window)
            
        if SCHEDULER_AVAILABLE:
            self.feature_managers["scheduler"] = DeploymentScheduler(self.main_window)
            
        if ENV_MANAGER_AVAILABLE:
            self.feature_managers["env_manager"] = EnvironmentManager(self.main_window)
            
        if ANALYTICS_AVAILABLE:
            self.feature_managers["analytics"] = AnalyticsDashboard(self.main_window)
            
        if MULTISITE_AVAILABLE:
            self.feature_managers["multisite"] = MultisiteManager(self.main_window)
            
        if AB_TESTING_AVAILABLE:
            self.feature_managers["ab_testing"] = ABTestingManager(self.main_window)
            
        if PREVIEW_AVAILABLE:
            self.feature_managers["preview"] = DeploymentPreviewManager(self.main_window)
            
        # Initialize GitHub integration
        if GITHUB_AVAILABLE:
            from github_integration import GitHubManager
            self.feature_managers["github"] = GitHubManager(self.main_window)
            self.github_manager = self.feature_managers["github"]
    
    def add_menus(self, menubar):
        """Add feature menus to menubar"""
        self.add_templates_menu(menubar)
        self.add_deployment_menu(menubar)
        self.add_tools_menu(menubar)
        
    def add_templates_menu(self, menubar):
        """Add Templates menu items to Configuration menu"""
        # Find Configuration menu
        config_menu = None
        for action in menubar.actions():
            if action.text() == "&Configuration":
                config_menu = action.menu()
                break
        
        if not config_menu:
            return
            
        if TEMPLATES_AVAILABLE:
            # Add Templates submenu
            templates_menu = QMenu("Project &Templates", self.main_window)
            templates_menu.setStyleSheet("""
                QMenu {
                    background-color: #252526;
                    color: #cccccc;
                    border: 1px solid #3c3c3c;
                }
                QMenu::item:selected {
                    background-color: #094771;
                }
            """)
            
            save_template_action = QAction("Save Current as Template", self.main_window)
            save_template_action.triggered.connect(self.save_template)
            templates_menu.addAction(save_template_action)
            
            manage_templates_action = QAction("Manage Templates", self.main_window)
            manage_templates_action.triggered.connect(self.manage_templates)
            templates_menu.addAction(manage_templates_action)
            
            # Add templates from manager
            if "templates" in self.feature_managers:
                manager = self.feature_managers["templates"]
                if manager.templates:
                    templates_menu.addSeparator()
                    
                    for template in manager.templates:
                        action = QAction(template['name'], self.main_window)
                        action.triggered.connect(
                            lambda checked=False, idx=manager.templates.index(template): 
                            self.load_template(idx)
                        )
                        templates_menu.addAction(action)
            
            # Add as first item in Configuration menu
            if config_menu.actions():
                config_menu.insertMenu(config_menu.actions()[0], templates_menu)
            else:
                config_menu.addMenu(templates_menu)
    
    def add_deployment_menu(self, menubar):
        """Add or enhance Deployment menu"""
        # Look for existing Deploy menu
        deploy_menu = None
        for action in menubar.actions():
            if action.text() == "&Deploy":
                deploy_menu = action.menu()
                break
                
        # If no Deploy menu exists, create one
        if not deploy_menu:
            deploy_menu = menubar.addMenu("&Deploy")
        
        # Add one-click deployment action
        deploy_action = QAction("Deploy Now", self.main_window)
        deploy_action.triggered.connect(self.main_window.start_deployment)
        deploy_menu.addAction(deploy_action)
        
        # Add scheduled deployment
        if SCHEDULER_AVAILABLE:
            schedule_menu = QMenu("&Deployment Scheduler", self.main_window)
            schedule_menu.setStyleSheet("""
                QMenu {
                    background-color: #252526;
                    color: #cccccc;
                    border: 1px solid #3c3c3c;
                }
                QMenu::item:selected {
                    background-color: #094771;
                }
            """)
            
            schedule_action = QAction("Schedule Deployment", self.main_window)
            schedule_action.triggered.connect(self.schedule_deployment)
            schedule_menu.addAction(schedule_action)
            
            manage_schedules_action = QAction("Manage Scheduled Deployments", self.main_window)
            manage_schedules_action.triggered.connect(self.manage_schedules)
            schedule_menu.addAction(manage_schedules_action)
            
            deploy_menu.addMenu(schedule_menu)
            
        # Add deployment preview
        if PREVIEW_AVAILABLE:
            preview_menu = QMenu("&Depoyment Preview", self.main_window)
            preview_menu.setStyleSheet("""
                QMenu {
                    background-color: #252526;
                    color: #cccccc;
                    border: 1px solid #3c3c3c;
                }
                QMenu::item:selected {
                    background-color: #094771;
                }
            """)
            
            preview_action = QAction("Create Preview Deployment", self.main_window)
            preview_action.triggered.connect(self.create_preview)
            preview_menu.addAction(preview_action)
            
            preview_action = QAction("Deployment Previews", self.main_window)
            preview_action.triggered.connect(self.show_deployment_preview)
            preview_menu.addAction(preview_action)
            
            deploy_menu.addMenu(preview_menu)

        if AB_TESTING_AVAILABLE:
            ab_menu = QMenu("&A/B Testing", self.main_window)
            ab_menu.setStyleSheet("""
                QMenu {
                    background-color: #252526;
                    color: #cccccc;
                    border: 1px solid #3c3c3c;
                }
                QMenu::item:selected {
                    background-color: #094771;
                }
            """)
            
            ab_action = QAction("Create A/B Test Deployment", self.main_window)
            ab_action.triggered.connect(self.create_ab_test)
            ab_menu.addAction(ab_action)
            
            ab_action = QAction("A/B Testing", self.main_window)
            ab_action.triggered.connect(self.show_ab_testing)
            ab_menu.addAction(ab_action)
            
            deploy_menu.addMenu(ab_menu)
    
    def add_tools_menu(self, menubar):
        """Add Tools menu for various utilities"""
        tools_menu = menubar.addMenu("&Tools")
        
        # Add environment variables manager
        if ENV_MANAGER_AVAILABLE:
            env_action = QAction("Environment Variables Manager", self.main_window)
            env_action.triggered.connect(self.show_env_manager)
            tools_menu.addAction(env_action)
        
        # Add analytics dashboard
        if ANALYTICS_AVAILABLE:
            analytics_action = QAction("Analytics Dashboard", self.main_window)
            analytics_action.triggered.connect(self.show_analytics)
            tools_menu.addAction(analytics_action)
        
        # Add multisite management
        if MULTISITE_AVAILABLE:
            multisite_action = QAction("Manage Multiple Sites", self.main_window)
            multisite_action.triggered.connect(self.show_multisite)
            tools_menu.addAction(multisite_action)
            
        # Add A/B testing
        if AB_TESTING_AVAILABLE:
            ab_action = QAction("A/B Testing", self.main_window)
            ab_action.triggered.connect(self.show_ab_testing)
            tools_menu.addAction(ab_action)
            
        # Add deployment previews
        if PREVIEW_AVAILABLE:
            preview_action = QAction("Deployment Previews", self.main_window)
            preview_action.triggered.connect(self.show_deployment_preview)
            tools_menu.addAction(preview_action)
            
        # Add GitHub integration
        if GITHUB_AVAILABLE:
            # Create GitHub submenu
            github_menu = QMenu("&GitHub Integration", self.main_window)
            
            # GitHub authentication
            auth_action = QAction("Connect to GitHub", self.main_window)
            auth_action.setStatusTip("Configure GitHub authentication and repository")
            auth_action.triggered.connect(self.show_github_connect)
            github_menu.addAction(auth_action)
            
            github_menu.addSeparator()
            
            # GitHub basic operations
            pull_action = QAction("&Pull Changes", self.main_window)
            pull_action.setStatusTip("Pull changes from remote repository")
            pull_action.triggered.connect(self.show_github_pull)
            github_menu.addAction(pull_action)
            
            push_action = QAction("P&ush Changes", self.main_window)
            push_action.setStatusTip("Commit and push changes to remote repository")
            push_action.triggered.connect(self.show_github_push)
            github_menu.addAction(push_action)
            
            # GitHub advanced features
            history_action = QAction("View &Commit History", self.main_window)
            history_action.setStatusTip("View repository commit history")
            history_action.triggered.connect(self.show_github_history)
            github_menu.addAction(history_action)
            
            pr_action = QAction("Manage &Pull Requests", self.main_window)
            pr_action.setStatusTip("View and manage pull requests")
            pr_action.triggered.connect(self.show_github_pr)
            github_menu.addAction(pr_action)
            
            # Add separator for advanced configuration
            github_menu.addSeparator()
            
            # Remote repository configuration
            remote_action = QAction("Configure &Remote Repository", self.main_window)
            remote_action.setStatusTip("Set up or change remote repository URL")
            remote_action.triggered.connect(self.show_github_remote_config)
            github_menu.addAction(remote_action)
            
            # Add the GitHub submenu to the Tools menu
            tools_menu.addMenu(github_menu)
            
        # Debug message
        logger.info("Adding GitHub menu to Tools menu")
    
    def add_tools_menu_items(self, menu):
        """
        Add standard items to the Tools menu
        
        Args:
            menu: The Tools menu object
        """
        try:
            # Analytics action
            analytics_action = QAction("&Analytics Dashboard", self.main_window)
            analytics_action.setStatusTip("View site analytics and metrics")
            analytics_action.triggered.connect(self.show_analytics_placeholder)
            menu.addAction(analytics_action)
            
            # Environment variables manager
            env_manager_action = QAction("&Environment Variables", self.main_window)
            env_manager_action.setStatusTip("Manage environment variables for deployments")
            env_manager_action.triggered.connect(self.show_env_manager_placeholder)
            menu.addAction(env_manager_action)
            
            # Add separator before GitHub section
            menu.addSeparator()
            
            # GitHub integration submenu
            github_menu = QMenu("&GitHub", self.main_window)
            
            # Repository actions
            repo_action = QAction("&Connect Repository", self.main_window)
            repo_action.setStatusTip("Connect to a GitHub repository")
            repo_action.triggered.connect(self.show_github_connect)
            github_menu.addAction(repo_action)
            
            pull_action = QAction("&Pull Changes", self.main_window)
            pull_action.setStatusTip("Pull latest changes from GitHub")
            pull_action.triggered.connect(self.show_github_pull)
            github_menu.addAction(pull_action)
            
            push_action = QAction("P&ush Changes", self.main_window)
            push_action.setStatusTip("Push local changes to GitHub")
            push_action.triggered.connect(self.show_github_push)
            github_menu.addAction(push_action)
            
            # Add separator
            github_menu.addSeparator()
            
            # GitHub advanced features
            history_action = QAction("View &Commit History", self.main_window)
            history_action.setStatusTip("View repository commit history")
            history_action.triggered.connect(self.show_github_history)
            github_menu.addAction(history_action)
            
            pr_action = QAction("Manage &Pull Requests", self.main_window)
            pr_action.setStatusTip("View and manage pull requests")
            pr_action.triggered.connect(self.show_github_pr)
            github_menu.addAction(pr_action)
            
            # Add separator for advanced configuration
            github_menu.addSeparator()
            
            # Remote repository configuration
            remote_action = QAction("Configure &Remote Repository", self.main_window)
            remote_action.setStatusTip("Add or update remote repository URL")
            remote_action.triggered.connect(self.show_github_remote_config)
            github_menu.addAction(remote_action)
            
            # Add the GitHub submenu to the Tools menu
            menu.addMenu(github_menu)
            
        except Exception as e:
            logger.error(f"Failed to add tools menu items: {str(e)}")
            
    # ----- Template features -----
    def save_template(self):
        """Save current configuration as template"""
        if "templates" in self.feature_managers:
            self.feature_managers["templates"].save_current_as_template()
    
    def load_template(self, index):
        """Load a template by index"""
        if "templates" in self.feature_managers:
            self.feature_managers["templates"].load_template(index)
    
    def manage_templates(self):
        """Show template management dialog"""
        if "templates" in self.feature_managers:
            self.feature_managers["templates"].show_management_dialog()
    
    # ----- Scheduling features -----
    def schedule_deployment(self):
        """Schedule a deployment"""
        if "scheduler" in self.feature_managers:
            self.feature_managers["scheduler"].show_schedule_dialog()
    
    def manage_schedules(self):
        """Manage scheduled deployments"""
        if "scheduler" in self.feature_managers:
            self.feature_managers["scheduler"].show_manage_dialog()
    
    def handle_scheduled_deployment(self, deployment_config):
        """Handle a deployment that is ready to be run"""
        # Set the values from the deployment config
        self.main_window.project_dir.setText(deployment_config.get("project_dir", ""))
        self.main_window.publish_dir.setText(deployment_config.get("publish_dir", ""))
        self.main_window.site_name.setText(deployment_config.get("site_name", ""))
        
        # Set token and team if available
        if "token" in deployment_config and deployment_config["token"]:
            self.main_window.persistent_token = deployment_config["token"]
            
        if "team_name" in deployment_config and deployment_config["team_name"]:
            self.main_window.persistent_team = deployment_config["team_name"]
            
        # Save persistent settings
        self.main_window.save_persistent_settings()
        
        # Check if we should run a build first
        if deployment_config.get("build", False):
            if deployment_config.get("production_build", False):
                self.main_window.build_production()
            else:
                self.main_window.build_project()
                
        # Start the deployment
        QMessageBox.information(
            self.main_window,
            "Scheduled Deployment",
            f"Starting scheduled deployment for {deployment_config.get('site_name', '')}"
        )
        self.main_window.start_deployment()
        
        # If deployment is recurring, schedule next one
        if deployment_config.get("recurring", False) and "recurring_interval" in deployment_config:
            # Create a copy of the config for the next deployment
            next_config = deployment_config.copy()
            next_config["timestamp"] = deployment_config["timestamp"] + deployment_config["recurring_interval"]
            
            # Schedule the next deployment
            self.feature_managers["scheduler"].schedule_deployment(next_config)
            
            # Log the next scheduled deployment
            import time
            from datetime import datetime
            next_time = datetime.fromtimestamp(next_config["timestamp"]).strftime("%Y-%m-%d %H:%M:%S")
            self.main_window.log_text.append(
                f"<span style='color: #569cd6'>Next deployment scheduled for {next_time}</span>"
            )
    
    # ----- Environment Manager features -----
    def show_env_manager(self):
        """Show environment variables manager"""
        if "env_manager" in self.feature_managers:
            self.feature_managers["env_manager"].show_env_manager_dialog()
    
    # ----- Analytics features -----
    def show_analytics(self):
        """Show analytics dashboard"""
        if "analytics" in self.feature_managers:
            # Ensure the analytics dashboard has the latest token
            if hasattr(self.main_window, 'persistent_token'):
                self.feature_managers["analytics"].api_token = self.main_window.persistent_token
                logger.info("Updated analytics dashboard with token from main_window.persistent_token")
            elif hasattr(self.main_window, 'settings') and 'persistent_token' in self.main_window.settings:
                self.feature_managers["analytics"].api_token = self.main_window.settings['persistent_token']
                logger.info("Updated analytics dashboard with token from main_window.settings")
                
            self.feature_managers["analytics"].show_dashboard()
        else:
            try:
                from analytics_dashboard import AnalyticsDashboard
                analytics = AnalyticsDashboard(self.main_window)
                
                # Ensure the analytics dashboard has the latest token
                if hasattr(self.main_window, 'persistent_token'):
                    analytics.api_token = self.main_window.persistent_token
                    logger.info("Set token on new analytics dashboard from main_window.persistent_token")
                elif hasattr(self.main_window, 'settings') and 'persistent_token' in self.main_window.settings:
                    analytics.api_token = self.main_window.settings['persistent_token']
                    logger.info("Set token on new analytics dashboard from main_window.settings")
                    
                analytics.show_dashboard()
            except Exception as e:
                QMessageBox.critical(
                    self.main_window,
                    "Error",
                    f"Failed to open Analytics Dashboard: {str(e)}"
                )
    
    # ----- Multisite features -----
    def show_multisite(self):
        """Show multisite manager"""
        if "multisite" in self.feature_managers:
            try:
                logger.info("Opening Multi-Site Manager from feature manager")
                self.feature_managers["multisite"].show_manager_dialog()
            except Exception as e:
                logger.error(f"Error opening Multi-Site Manager: {str(e)}")
                QMessageBox.critical(
                    self.main_window,
                    "Error",
                    f"Failed to open Multi-Site Manager: {str(e)}"
                )
        else:
            try:
                logger.info("Opening Multi-Site Manager directly")
                from multisite_manager import show_multisite_manager
                show_multisite_manager(self.main_window)
            except Exception as e:
                logger.error(f"Error opening Multi-Site Manager: {str(e)}")
                QMessageBox.critical(
                    self.main_window,
                    "Error",
                    f"Failed to open Multi-Site Manager: {str(e)}"
                )
    
    # ----- A/B Testing features -----
    def show_ab_testing(self):
        """
        Show A/B testing interface
        """
        try:
            from ab_testing import ABTestingManager
            
            # Initialize A/B testing manager if not already
            if not hasattr(self, 'ab_manager'):
                self.ab_manager = ABTestingManager(self.main_window)
                
            # Show A/B testing interface
            self.ab_manager.show_ab_testing_interface()
        except ImportError as e:
            self.main_window.log_text.append(
                f"<span style='color: #ce9178'>Error loading A/B testing: {str(e)}</span>"
            )
            QMessageBox.warning(
                self.main_window,
                "Feature Not Available",
                f"A/B testing is not available: {str(e)}"
            )
    
    def create_ab_test(self):
        """Create A/B test deployment"""
        if "ab_testing" in self.feature_managers:
            self.feature_managers["ab_testing"].create_ab_test()
        else:
            self.show_ab_testing()
    
    # ----- Preview features -----
    def show_deployment_preview(self):
        """Show deployment previews interface"""
        if "preview" in self.feature_managers:
            self.feature_managers["preview"].show_previews_interface()
        else:
            QMessageBox.information(
                self.main_window,
                "Coming Soon",
                "Deployment Preview Links is coming soon!"
            )
    
    def create_preview(self):
        """Create a new preview deployment"""
        if PREVIEW_AVAILABLE:
            self.feature_managers["preview"].create_preview()
        else:
            QMessageBox.warning(
                self.main_window,
                "Feature Not Available",
                "Deployment Preview feature is not available."
            )
            
        # Webhook functionality has been removed 

    # GitHub integration methods
    def show_github_connect(self):
        """
        Show GitHub repository connection dialog
        """
        try:
            from github_integration import GitHubManager, GitHubConnectDialog
            
            # Initialize GitHub manager if not already
            if not hasattr(self, 'github_manager'):
                self.github_manager = GitHubManager(self.main_window)
                
            # Show repository connection dialog
            connect_dialog = GitHubConnectDialog(self.main_window, self.github_manager)
            connect_dialog.exec()
            
            # Update feature managers
            self.feature_managers['github'] = self.github_manager
            
            # Log connection status
            if self.github_manager.current_repo:
                self.main_window.log_text.append(
                    f"<span style='color: #569cd6'>Connected to GitHub repository at {self.github_manager.current_repo}</span>"
                )
        except ImportError as e:
            self.main_window.log_text.append(
                f"<span style='color: #ce9178'>Error loading GitHub integration: {str(e)}</span>"
            )
            QMessageBox.warning(
                self.main_window,
                "GitHub Integration Error",
                f"Failed to load GitHub integration: {str(e)}"
            )
    
    def show_github_pull(self):
        """
        Show GitHub pull changes dialog
        """
        try:
            from github_integration import GitHubManager, GitHubPullDialog
            
            # Initialize GitHub manager if not already
            if not hasattr(self, 'github_manager'):
                self.github_manager = GitHubManager(self.main_window)
                
            # Show pull dialog
            pull_dialog = GitHubPullDialog(self.main_window, self.github_manager)
            if pull_dialog.exec() == 1:  # QDialog.DialogCode.Accepted value is 1
                # Log successful pull
                self.main_window.log_text.append(
                    "<span style='color: #569cd6'>Successfully pulled changes from GitHub</span>"
                )
        except ImportError as e:
            self.main_window.log_text.append(
                f"<span style='color: #ce9178'>Error loading GitHub pull dialog: {str(e)}</span>"
            )
            QMessageBox.warning(
                self.main_window,
                "GitHub Integration Error",
                f"Failed to load GitHub pull dialog: {str(e)}"
            )
    
    def show_github_push(self):
        """
        Show GitHub push changes dialog
        """
        try:
            from github_integration import GitHubManager, GitHubPushDialog
            
            # Initialize GitHub manager if not already
            if not hasattr(self, 'github_manager'):
                self.github_manager = GitHubManager(self.main_window)
                
            # Show push dialog
            push_dialog = GitHubPushDialog(self.main_window, self.github_manager)
            if push_dialog.exec() == 1:  # QDialog.DialogCode.Accepted value is 1
                # Log successful push
                self.main_window.log_text.append(
                    "<span style='color: #569cd6'>Successfully pushed changes to GitHub</span>"
                )
        except ImportError as e:
            self.main_window.log_text.append(
                f"<span style='color: #ce9178'>Error loading GitHub push dialog: {str(e)}</span>"
            )
            QMessageBox.warning(
                self.main_window,
                "GitHub Integration Error",
                f"Failed to load GitHub push dialog: {str(e)}"
            )
    
    def show_github_history(self):
        """
        Show GitHub commit history dialog
        """
        try:
            from github_integration import GitHubManager, GitHubHistoryDialog
            
            # Initialize GitHub manager if not already
            if not hasattr(self, 'github_manager'):
                self.github_manager = GitHubManager(self.main_window)
                
            # Show history dialog
            history_dialog = GitHubHistoryDialog(self.main_window, self.github_manager)
            history_dialog.exec()
        except ImportError as e:
            self.main_window.log_text.append(
                f"<span style='color: #ce9178'>Error loading GitHub history dialog: {str(e)}</span>"
            )
            QMessageBox.warning(
                self.main_window,
                "GitHub Integration Error",
                f"Failed to load GitHub history dialog: {str(e)}"
            )
    
    def show_github_pr(self):
        """
        Show GitHub pull request management dialog
        """
        try:
            from github_integration import GitHubManager, GitHubPRDialog
            
            # Initialize GitHub manager if not already
            if not hasattr(self, 'github_manager'):
                self.github_manager = GitHubManager(self.main_window)
                
            # Show PR dialog
            pr_dialog = GitHubPRDialog(self.main_window, self.github_manager)
            pr_dialog.exec()
        except ImportError as e:
            self.main_window.log_text.append(
                f"<span style='color: #ce9178'>Error loading GitHub PR dialog: {str(e)}</span>"
            )
            QMessageBox.warning(
                self.main_window,
                "GitHub Integration Error",
                f"Failed to load GitHub PR dialog: {str(e)}"
            )
            
    def show_github_remote_config(self):
        """
        Show GitHub remote repository configuration dialog
        """
        try:
            from github_integration import GitHubManager, RemoteRepositoryDialog
            
            # Initialize GitHub manager if not already
            if not hasattr(self, 'github_manager'):
                self.github_manager = GitHubManager(self.main_window)
                
            # Check if a repository is connected
            if not self.github_manager.current_repo:
                QMessageBox.warning(
                    self.main_window,
                    "No Repository",
                    "Please connect to a repository first using the 'Connect to GitHub' option."
                )
                return
                
            # Show remote configuration dialog
            remote_dialog = RemoteRepositoryDialog(self.main_window, self.github_manager)
            remote_dialog.exec()
        except ImportError as e:
            self.main_window.log_text.append(
                f"<span style='color: #ce9178'>Error loading GitHub remote configuration dialog: {str(e)}</span>"
            )
            QMessageBox.warning(
                self.main_window,
                "GitHub Integration Error",
                f"Failed to load GitHub remote configuration dialog: {str(e)}"
            )

    def show_analytics_placeholder(self):
        """
        Show placeholder for analytics dashboard
        """
        QMessageBox.information(
            self.main_window,
            "Analytics Dashboard",
            "The Analytics Dashboard will be available in a future update."
        )

    def show_env_manager_placeholder(self):
        """
        Show placeholder for environment variables manager
        """
        QMessageBox.information(
            self.main_window,
            "Environment Variables Manager",
            "The Environment Variables Manager will be available in a future update."
        ) 