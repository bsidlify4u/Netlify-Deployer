"""
GitHub API Integration Module for Netlify Deployer
Provides a wrapper around GitHub REST API
"""

import os
import json
import logging
import requests
import base64
from datetime import datetime

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("github_api")

class GitHubAPI:
    """
    GitHub API wrapper for interacting with GitHub repositories
    """
    
    def __init__(self, token=None):
        self.base_url = "https://api.github.com"
        self.token = token
        self.user_info = None
        
    def set_token(self, token):
        """Set the OAuth access token"""
        self.token = token
        
    def get_headers(self):
        """Get the headers for API requests"""
        headers = {
            'Accept': 'application/vnd.github.v3+json'
        }
        
        if self.token:
            headers['Authorization'] = f'token {self.token}'
            
        return headers
        
    def get_user_info(self):
        """Get authenticated user info"""
        try:
            response = requests.get(f"{self.base_url}/user", headers=self.get_headers())
            
            if response.status_code == 200:
                self.user_info = response.json()
                return self.user_info
            else:
                logger.error(f"Error getting user info: {response.status_code} - {response.text}")
                return None
        except Exception as e:
            logger.error(f"Error getting user info: {str(e)}")
            return None
            
    def list_repositories(self, visibility="all"):
        """List repositories for the authenticated user"""
        try:
            response = requests.get(
                f"{self.base_url}/user/repos",
                params={'visibility': visibility, 'per_page': 100},
                headers=self.get_headers()
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                logger.error(f"Error listing repositories: {response.status_code} - {response.text}")
                return []
        except Exception as e:
            logger.error(f"Error listing repositories: {str(e)}")
            return []
            
    def create_repository(self, name, description="", private=False):
        """Create a new repository"""
        try:
            payload = {
                'name': name,
                'description': description,
                'private': private,
                'auto_init': False  # Don't initialize with README
            }
            
            response = requests.post(
                f"{self.base_url}/user/repos",
                headers=self.get_headers(),
                json=payload
            )
            
            if response.status_code in (201, 200):
                return response.json()
            else:
                logger.error(f"Error creating repository: {response.status_code} - {response.text}")
                return None
        except Exception as e:
            logger.error(f"Error creating repository: {str(e)}")
            return None
            
    def get_repository(self, owner, repo):
        """Get repository info"""
        try:
            response = requests.get(
                f"{self.base_url}/repos/{owner}/{repo}",
                headers=self.get_headers()
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                logger.error(f"Error getting repository: {response.status_code} - {response.text}")
                return None
        except Exception as e:
            logger.error(f"Error getting repository: {str(e)}")
            return None
            
    def list_branches(self, owner, repo):
        """List branches in repository"""
        try:
            response = requests.get(
                f"{self.base_url}/repos/{owner}/{repo}/branches",
                headers=self.get_headers()
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                logger.error(f"Error listing branches: {response.status_code} - {response.text}")
                return []
        except Exception as e:
            logger.error(f"Error listing branches: {str(e)}")
            return []
            
    def create_branch(self, owner, repo, branch_name, base_branch="main"):
        """Create a new branch"""
        try:
            # Get the SHA of the base branch
            base_ref = self.get_branch(owner, repo, base_branch)
            if not base_ref:
                return None
                
            sha = base_ref.get("commit", {}).get("sha")
            if not sha:
                logger.error("Could not get SHA of base branch")
                return None
                
            # Create a reference for the new branch
            payload = {
                'ref': f"refs/heads/{branch_name}",
                'sha': sha
            }
            
            response = requests.post(
                f"{self.base_url}/repos/{owner}/{repo}/git/refs",
                headers=self.get_headers(),
                json=payload
            )
            
            if response.status_code == 201:
                return response.json()
            else:
                logger.error(f"Error creating branch: {response.status_code} - {response.text}")
                return None
        except Exception as e:
            logger.error(f"Error creating branch: {str(e)}")
            return None
            
    def get_branch(self, owner, repo, branch):
        """Get branch info"""
        try:
            response = requests.get(
                f"{self.base_url}/repos/{owner}/{repo}/branches/{branch}",
                headers=self.get_headers()
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                logger.error(f"Error getting branch: {response.status_code} - {response.text}")
                return None
        except Exception as e:
            logger.error(f"Error getting branch: {str(e)}")
            return None
            
    def create_commit(self, owner, repo, message, branch, files):
        """Create a commit with file changes"""
        try:
            # Get the latest commit of the branch to get the tree SHA
            branch_data = self.get_branch(owner, repo, branch)
            if not branch_data:
                return None
                
            parent_sha = branch_data["commit"]["sha"]
            base_tree = branch_data["commit"]["commit"]["tree"]["sha"]
            
            # Create blobs for each file
            blobs = []
            for file_path, content in files.items():
                blob = self.create_blob(owner, repo, content)
                if blob:
                    blobs.append({
                        "path": file_path,
                        "mode": "100644",  # Regular file
                        "type": "blob",
                        "sha": blob["sha"]
                    })
                else:
                    logger.error(f"Failed to create blob for {file_path}")
                    
            if not blobs:
                logger.error("No valid file blobs created")
                return None
                
            # Create a new tree with the blobs
            tree = self.create_tree(owner, repo, blobs, base_tree)
            if not tree:
                return None
                
            # Create commit
            commit = self.create_commit_object(owner, repo, message, tree["sha"], [parent_sha])
            if not commit:
                return None
                
            # Update branch reference
            ref_update = self.update_reference(owner, repo, f"heads/{branch}", commit["sha"])
            if not ref_update:
                return None
                
            return commit
        except Exception as e:
            logger.error(f"Error creating commit: {str(e)}")
            return None
            
    def create_blob(self, owner, repo, content, encoding="utf-8"):
        """Create a blob for a file"""
        try:
            payload = {
                'content': content,
                'encoding': 'utf-8'  # or 'base64' if binary
            }
            
            response = requests.post(
                f"{self.base_url}/repos/{owner}/{repo}/git/blobs",
                headers=self.get_headers(),
                json=payload
            )
            
            if response.status_code == 201:
                return response.json()
            else:
                logger.error(f"Error creating blob: {response.status_code} - {response.text}")
                return None
        except Exception as e:
            logger.error(f"Error creating blob: {str(e)}")
            return None
            
    def create_tree(self, owner, repo, tree_items, base_tree=None):
        """Create a git tree"""
        try:
            payload = {
                'tree': tree_items
            }
            
            if base_tree:
                payload['base_tree'] = base_tree
                
            response = requests.post(
                f"{self.base_url}/repos/{owner}/{repo}/git/trees",
                headers=self.get_headers(),
                json=payload
            )
            
            if response.status_code == 201:
                return response.json()
            else:
                logger.error(f"Error creating tree: {response.status_code} - {response.text}")
                return None
        except Exception as e:
            logger.error(f"Error creating tree: {str(e)}")
            return None
            
    def create_commit_object(self, owner, repo, message, tree_sha, parent_shas):
        """Create a commit object"""
        try:
            payload = {
                'message': message,
                'tree': tree_sha,
                'parents': parent_shas
            }
            
            response = requests.post(
                f"{self.base_url}/repos/{owner}/{repo}/git/commits",
                headers=self.get_headers(),
                json=payload
            )
            
            if response.status_code == 201:
                return response.json()
            else:
                logger.error(f"Error creating commit object: {response.status_code} - {response.text}")
                return None
        except Exception as e:
            logger.error(f"Error creating commit object: {str(e)}")
            return None
            
    def update_reference(self, owner, repo, ref, sha, force=False):
        """Update a reference (branch or tag)"""
        try:
            payload = {
                'sha': sha,
                'force': force
            }
            
            response = requests.patch(
                f"{self.base_url}/repos/{owner}/{repo}/git/refs/{ref}",
                headers=self.get_headers(),
                json=payload
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                logger.error(f"Error updating reference: {response.status_code} - {response.text}")
                return None
        except Exception as e:
            logger.error(f"Error updating reference: {str(e)}")
            return None
            
    def get_commits(self, owner, repo, branch=None, path=None, limit=30):
        """Get commit history for a repository"""
        try:
            params = {'per_page': min(limit, 100)}
            if branch:
                params['sha'] = branch
            if path:
                params['path'] = path
                
            response = requests.get(
                f"{self.base_url}/repos/{owner}/{repo}/commits",
                headers=self.get_headers(),
                params=params
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                logger.error(f"Error getting commits: {response.status_code} - {response.text}")
                return []
        except Exception as e:
            logger.error(f"Error getting commits: {str(e)}")
            return []
            
    def get_commit(self, owner, repo, commit_sha):
        """Get details of a specific commit"""
        try:
            response = requests.get(
                f"{self.base_url}/repos/{owner}/{repo}/commits/{commit_sha}",
                headers=self.get_headers()
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                logger.error(f"Error getting commit: {response.status_code} - {response.text}")
                return None
        except Exception as e:
            logger.error(f"Error getting commit: {str(e)}")
            return None
            
    def list_pull_requests(self, owner, repo, state="open"):
        """List pull requests"""
        try:
            params = {'state': state, 'per_page': 100}
            
            response = requests.get(
                f"{self.base_url}/repos/{owner}/{repo}/pulls",
                headers=self.get_headers(),
                params=params
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                logger.error(f"Error listing pull requests: {response.status_code} - {response.text}")
                return []
        except Exception as e:
            logger.error(f"Error listing pull requests: {str(e)}")
            return []
            
    def create_pull_request(self, owner, repo, title, head, base, body=""):
        """Create a pull request"""
        try:
            payload = {
                'title': title,
                'head': head,
                'base': base,
                'body': body
            }
            
            response = requests.post(
                f"{self.base_url}/repos/{owner}/{repo}/pulls",
                headers=self.get_headers(),
                json=payload
            )
            
            if response.status_code == 201:
                return response.json()
            else:
                logger.error(f"Error creating pull request: {response.status_code} - {response.text}")
                return None
        except Exception as e:
            logger.error(f"Error creating pull request: {str(e)}")
            return None
            
    def get_pull_request(self, owner, repo, pr_number):
        """Get a pull request"""
        try:
            response = requests.get(
                f"{self.base_url}/repos/{owner}/{repo}/pulls/{pr_number}",
                headers=self.get_headers()
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                logger.error(f"Error getting pull request: {response.status_code} - {response.text}")
                return None
        except Exception as e:
            logger.error(f"Error getting pull request: {str(e)}")
            return None
            
    def merge_pull_request(self, owner, repo, pr_number, commit_message=None):
        """Merge a pull request"""
        try:
            payload = {}
            if commit_message:
                payload['commit_message'] = commit_message
                
            response = requests.put(
                f"{self.base_url}/repos/{owner}/{repo}/pulls/{pr_number}/merge",
                headers=self.get_headers(),
                json=payload
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                logger.error(f"Error merging pull request: {response.status_code} - {response.text}")
                return None
        except Exception as e:
            logger.error(f"Error merging pull request: {str(e)}")
            return None
            
    def get_repository_content(self, owner, repo, path="", ref=None):
        """Get contents of a file or directory"""
        try:
            params = {}
            if ref:
                params['ref'] = ref
                
            response = requests.get(
                f"{self.base_url}/repos/{owner}/{repo}/contents/{path}",
                headers=self.get_headers(),
                params=params
            )
            
            if response.status_code == 200:
                content = response.json()
                
                # If it's a file, decode content
                if isinstance(content, dict) and 'content' in content and content.get('type') == 'file':
                    content['decoded_content'] = base64.b64decode(content['content']).decode('utf-8')
                    
                return content
            else:
                logger.error(f"Error getting repository content: {response.status_code} - {response.text}")
                return None
        except Exception as e:
            logger.error(f"Error getting repository content: {str(e)}")
            return None
            
    def update_file(self, owner, repo, path, content, message, branch, sha=None):
        """Update or create a file"""
        try:
            # First check if file exists to get the SHA
            if not sha:
                file_info = self.get_repository_content(owner, repo, path, branch)
                if file_info and isinstance(file_info, dict):
                    sha = file_info.get('sha')
                    
            # Prepare payload
            payload = {
                'message': message,
                'content': base64.b64encode(content.encode('utf-8')).decode('utf-8'),
                'branch': branch
            }
            
            # If updating existing file, include SHA
            if sha:
                payload['sha'] = sha
                
            response = requests.put(
                f"{self.base_url}/repos/{owner}/{repo}/contents/{path}",
                headers=self.get_headers(),
                json=payload
            )
            
            if response.status_code in (200, 201):
                return response.json()
            else:
                logger.error(f"Error updating file: {response.status_code} - {response.text}")
                return None
        except Exception as e:
            logger.error(f"Error updating file: {str(e)}")
            return None
            
    def delete_file(self, owner, repo, path, message, branch, sha):
        """Delete a file"""
        try:
            payload = {
                'message': message,
                'sha': sha,
                'branch': branch
            }
            
            response = requests.delete(
                f"{self.base_url}/repos/{owner}/{repo}/contents/{path}",
                headers=self.get_headers(),
                json=payload
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                logger.error(f"Error deleting file: {response.status_code} - {response.text}")
                return None
        except Exception as e:
            logger.error(f"Error deleting file: {str(e)}")
            return None 