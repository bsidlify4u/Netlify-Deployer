import os
import json
import logging
import subprocess
from subprocess import CompletedProcess, SubprocessError
from pathlib import Path
from typing import Dict, List, Tuple, Optional, Any, Union, Protocol, TypeVar, TypedDict, Sequence, cast

from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton,
    QTextEdit, QComboBox, QMessageBox, QFormLayout, QCheckBox, QRadioButton,
    QDialogButtonBox, QFileDialog, QFrame, QTreeWidget,
    QTreeWidgetItem, QHeaderView, QWidget, QLayout
)
from PyQt6.QtCore import Qt, QObject
from PyQt6.QtCore.Qt import ConnectionType

# Configure logging
logger = logging.getLogger(__name__)

# Type aliases and protocols
class GitHubAPI(Protocol):
    """Protocol defining the interface for GitHub API interactions"""
    def set_token(self, token: Optional[str]) -> None: ...
    def get_user_info(self) -> Dict[str, Any]: ...
    def create_repository(self, name: str, description: str = "", private: bool = False) -> Dict[str, Any]: ...

class GitHubSettings(TypedDict, total=False):
    """Type for GitHub settings"""
    current_repo: str
    github_username: str
    github_token: str

class OAuthTokenInfo(TypedDict):
    """Type for OAuth token information"""
    access_token: str
    user: Dict[str, Any]  # Optional user information

class GitCommit(TypedDict):
    """Type for Git commit information"""
    hash: str
    author: str
    date: str
    message: str
    time: str

class GitHubRepo(TypedDict):
    """Type for GitHub repository information"""
    clone_url: str
    name: str
    full_name: str
    private: bool
    description: str

# Type aliases
StrPath = Union[str, Path]
GitBranches = List[str]
GitResult = Tuple[bool, str]  # (success, message)
SubprocessResult = CompletedProcess[str]  # Type for subprocess.run results

# Constants
DIALOG_ACCEPTED = QDialogButtonBox.StandardButton.Ok

# Import GitHub related modules
api_available: bool = False
GitHubOAuthDialog: Optional[Any] = None
load_oauth_token: Optional[Any] = None
is_token_valid: Optional[Any] = None

try:
    from github_oauth import GitHubOAuthDialog, load_oauth_token, is_token_valid
    api_available = True
    logger.info("GitHub OAuth and API modules loaded successfully")
except ImportError as e:
    logger.error(f"Failed to import GitHub OAuth or API modules: {str(e)}")

class GitHubManager:
    """
    Class to manage GitHub API interactions and repository operations
    """
    main_window: QWidget
    settings_file: str
    settings: GitHubSettings
    current_repo: str
    oauth_token: Optional[OAuthTokenInfo]
    github_api: GitHubAPI

    def __init__(self, main_window: QWidget) -> None:
        """Initialize GitHub manager.
        
        Args:
            main_window: Parent window for dialogs
        """
        self.main_window = main_window
        self.settings_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'github_settings.json')
        self.settings = self._load_settings()
        self.current_repo = self.settings.get('current_repo', '')
        self.oauth_token = None
        self.github_api = GitHubAPI()
        
        # Try to initialize API with saved token
        self._init_api_from_saved_token()

    def _init_api_from_saved_token(self) -> None:
        """Initialize GitHub API with saved OAuth token if available"""
        if api_available and load_oauth_token is not None and is_token_valid is not None:
            try:
                # Try to load saved token
                token_info: Optional[OAuthTokenInfo] = load_oauth_token()
                
                # Check if token is valid
                if token_info is not None and is_token_valid(token_info):
                    self.oauth_token = token_info
                    self.github_api.set_token(token_info['access_token'])
                    logger.info("Initialized GitHub API with saved OAuth token")
                    
                    # Store username in settings
                    user_info: Optional[Dict[str, Any]] = self.github_api.get_user_info()
                    if user_info and 'login' in user_info:
                        self.settings['github_username'] = user_info['login']
                        self._save_settings()
                else:
                    logger.info("No valid OAuth token found")
            except Exception as e:
                logger.error(f"Error initializing GitHub API: {str(e)}")

    def _load_settings(self) -> GitHubSettings:
        """Load GitHub settings"""
        if os.path.exists(self.settings_file):
            try:
                with open(self.settings_file, 'r') as f:
                    return json.load(f)
            except Exception as e:
                logger.error(f"Error loading GitHub settings: {str(e)}")
        return {}

    def save_settings(self) -> None:
        """Save GitHub settings"""
        try:
            with open(self.settings_file, 'w') as f:
                json.dump(self.settings, f, indent=2)
        except Exception as e:
            logger.error(f"Error saving GitHub settings: {str(e)}")

    def is_git_installed(self) -> bool:
        """Check if git is installed on the system"""
        try:
            result: SubprocessResult = subprocess.run(
                ['git', '--version'],
                check=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            return True
        except (SubprocessError, FileNotFoundError):
            logger.error("Git is not installed or not in PATH")
            return False

    def is_repo_initialized(self, directory: StrPath) -> bool:
        """Check if the directory is a git repository"""
        try:
            result: SubprocessResult = subprocess.run(
                ['git', 'rev-parse', '--is-inside-work-tree'],
                cwd=str(directory),
                check=False,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            return result.returncode == 0 and result.stdout.strip() == 'true'
        except Exception as e:
            logger.error(f"Error checking if repo is initialized: {str(e)}")
            return False
            
    def init_repository(self, directory: StrPath) -> bool:
        """Initialize a git repository"""
        try:
            subprocess.run(['git', 'init'], cwd=str(directory), check=True, text=True)
            return True
        except SubprocessError as e:
            logger.error(f"Error initializing git repo: {str(e)}")
            return False

    def clone_repository(self, repo_url: str, target_directory: StrPath) -> GitResult:
        """Clone a repository from URL to target directory"""
        try:
            result: SubprocessResult = subprocess.run(
                ['git', 'clone', repo_url, str(target_directory)],
                check=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            return True, "Repository cloned successfully"
        except SubprocessError as e:
            logger.error(f"Error cloning repository: {str(e)}")
            return False, f"Error cloning repository: {str(e)}"
            
    def pull_changes(self, directory: StrPath, branch: str = 'main') -> GitResult:
        """Pull changes from remote repository"""
        try:
            # Ensure branch name is not empty
            if not branch:
                branch = 'main'  # Default to main if branch is empty
            
            # Check if repository has a remote 'origin'
            try:
                # Check if origin exists
                check_remote = subprocess.run(
                    ['git', 'remote', 'get-url', 'origin'], 
                    cwd=str(directory), 
                    check=False,  # Don't raise error if command fails
                    stdout=subprocess.PIPE, 
                    stderr=subprocess.PIPE, 
                    text=True
                )
                
                if check_remote.returncode != 0:
                    return False, "No remote 'origin' configured. Please set up remote repository first."
            except Exception as e:
                logger.error(f"Error checking for remote: {str(e)}")
                return False, f"Error checking remote: {str(e)}"
            
            # Pull changes
            pull_result = subprocess.run(
                ['git', 'pull', 'origin', branch],
                cwd=str(directory),
                check=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            
            return True, f"Successfully pulled from origin/{branch}: {pull_result.stdout.strip()}"
        except SubprocessError as e:
            logger.error(f"Error pulling changes: {str(e)}")
            return False, f"Error pulling changes: {str(e)}"
            
    def push_changes(self, directory: StrPath, branch: str = 'main') -> GitResult:
        """Push changes to remote repository"""
        try:
            # Ensure branch name is not empty
            if not branch:
                branch = 'main'  # Default to main if branch is empty
            
            # Check if repository has a remote 'origin'
            try:
                # Check if origin exists
                check_remote = subprocess.run(
                    ['git', 'remote', 'get-url', 'origin'], 
                    cwd=str(directory), 
                    check=False,  # Don't raise error if command fails
                    stdout=subprocess.PIPE, 
                    stderr=subprocess.PIPE, 
                    text=True
                )
                
                if check_remote.returncode != 0:
                    return False, "No remote 'origin' configured. Please set up remote repository first."
            except Exception as e:
                logger.error(f"Error checking for remote: {str(e)}")
                return False, f"Error checking remote: {str(e)}"
            
            # Push changes
            push_result = subprocess.run(
                ['git', 'push', 'origin', branch],
                cwd=str(directory),
                check=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            
            return True, f"Successfully pushed to origin/{branch}"
        except SubprocessError as e:
            logger.error(f"Error pushing changes: {str(e)}")
            return False, f"Error pushing changes: {str(e)}"
            
    def commit_changes(self, directory: StrPath, message: str) -> GitResult:
        """Commit changes with message"""
        try:
            # Check if Git user and email are configured
            name_check = subprocess.run(
                ['git', 'config', 'user.name'],
                cwd=str(directory),
                check=False,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            
            email_check = subprocess.run(
                ['git', 'config', 'user.email'],
                cwd=str(directory),
                check=False,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            
            # If user name or email is not configured, set default values
            if name_check.returncode != 0 or not name_check.stdout.strip():
                subprocess.run(
                    ['git', 'config', 'user.name', 'Netlify Deployer'],
                    cwd=str(directory),
                    check=True
                )
            
            if email_check.returncode != 0 or not email_check.stdout.strip():
                subprocess.run(
                    ['git', 'config', 'user.email', 'netlify-deployer@localhost'],
                    cwd=str(directory),
                    check=True
                )
            
            # Stage all changes
            subprocess.run(['git', 'add', '.'], cwd=str(directory), check=True)
            
            # Commit changes
            commit_result = subprocess.run(
                ['git', 'commit', '-m', message],
                cwd=str(directory),
                check=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            
            commit_output = commit_result.stdout.strip()
            if commit_output:
                return True, commit_output
            else:
                return True, "Changes committed successfully"
        except SubprocessError as e:
            logger.error(f"Error committing changes: {str(e)}")
            return False, f"Error committing changes: {str(e)}"
            
    def get_status(self, directory: StrPath) -> str:
        """Get repository status"""
        try:
            result = subprocess.run(['git', 'status', '--porcelain'], 
                cwd=str(directory), check=True, stdout=subprocess.PIPE, text=True)
            return result.stdout.strip()
        except SubprocessError as e:
            logger.error(f"Error getting status: {str(e)}")
            return ""
            
    def get_commit_history(self, directory: StrPath, count: int = 20) -> List[GitCommit]:
        """Get commit history"""
        try:
            format_string = "--pretty=format:%h|%an|%ar|%s"
            result = subprocess.run(
                ['git', 'log', format_string, f'-{count}'], 
                cwd=str(directory), 
                check=True, 
                stdout=subprocess.PIPE, 
                text=True
            )
            commits = []
            for line in result.stdout.strip().split('\n'):
                if line:
                    hash_id, author, time, message = line.split('|', 3)
                    commits.append({
                        'hash': hash_id,
                        'author': author,
                        'time': time,
                        'message': message
                    })
            return commits
        except SubprocessError as e:
            logger.error(f"Error getting commit history: {str(e)}")
            return []
            
    def get_branches(self, directory: StrPath) -> GitBranches:
        """Get branches list"""
        try:
            result = subprocess.run(['git', 'branch'], 
                cwd=str(directory), check=True, stdout=subprocess.PIPE, text=True)
            branches = []
            for line in result.stdout.strip().split('\n'):
                branch = line.strip()
                if branch.startswith('*'):
                    branch = branch[1:].strip()
                    branches.insert(0, branch)  # Put current branch first
                else:
                    branches.append(branch)
            return branches
        except SubprocessError as e:
            logger.error(f"Error getting branches: {str(e)}")
            return []
            
    def checkout_branch(self, directory: StrPath, branch: str) -> GitResult:
        """Checkout a branch"""
        try:
            subprocess.run(['git', 'checkout', branch], cwd=str(directory), check=True)
            return True, f"Switched to branch '{branch}'"
        except SubprocessError as e:
            logger.error(f"Error checking out branch: {str(e)}")
            return False, f"Error checking out branch: {str(e)}"

    def create_branch(self, directory: StrPath, branch_name: str) -> GitResult:
        """Create a new branch"""
        try:
            # Check if branch already exists
            branches = self.get_branches(directory)
            if branch_name in branches:
                return False, f"Branch '{branch_name}' already exists"
            
            # Check if there are uncommitted changes that might interfere
            status = self.get_status(directory)
            if status:
                # There are changes, warn but proceed
                logger.warning(f"Creating branch with uncommitted changes: {status}")
            
            # Ensure Git user configuration before creating branch
            name_check = subprocess.run(
                ['git', 'config', 'user.name'],
                cwd=str(directory),
                check=False,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            
            email_check = subprocess.run(
                ['git', 'config', 'user.email'],
                cwd=str(directory),
                check=False,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            
            # Set default values if not configured
            if name_check.returncode != 0 or not name_check.stdout.strip():
                subprocess.run(
                    ['git', 'config', 'user.name', 'Netlify Deployer'],
                    cwd=str(directory),
                    check=True
                )
            
            if email_check.returncode != 0 or not email_check.stdout.strip():
                subprocess.run(
                    ['git', 'config', 'user.email', 'netlify-deployer@localhost'],
                    cwd=str(directory),
                    check=True
                )
                
            # Create the branch
            result = subprocess.run(
                ['git', 'checkout', '-b', branch_name],
                cwd=str(directory),
                check=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            return True, f"Created and switched to branch '{branch_name}'"
        except SubprocessError as e:
            error_msg = str(e)
            
            # Provide more user-friendly error messages
            if "already exists" in error_msg:
                return False, f"Branch '{branch_name}' already exists"
            elif "fatal: not a valid object name" in error_msg:
                return False, "Cannot create branch: no commit history. Create an initial commit first."
            elif "pathspec" in error_msg and "did not match" in error_msg:
                return False, f"Invalid branch name: '{branch_name}'"
            
            logger.error(f"Error creating branch: {error_msg}")
            return False, f"Error creating branch: {error_msg}"

    def configure_github_auth(self, directory: StrPath, username: str, token: str) -> GitResult:
        """Configure GitHub authentication"""
        try:
            # Set user configuration
            subprocess.run(['git', 'config', 'user.name', username], cwd=str(directory), check=True)
            
            # Set user email if not already set (using GitHub format)
            subprocess.run(['git', 'config', 'user.email', f"{username}@users.noreply.github.com"], cwd=str(directory), check=True)
            
            # Store credential helper for token
            if os.name == 'nt':  # Windows
                credential_command = f'!f() {{ echo "username={username}\\npassword={token}"; }}; f'
                subprocess.run(['git', 'config', '--local', 'credential.helper', credential_command], 
                               cwd=str(directory), check=True, shell=True)
            else:  # Unix-like
                credential_command = f'!f() {{ echo "username={username}\\npassword={token}"; }}; f'
                subprocess.run(['git', 'config', '--local', 'credential.helper', credential_command], 
                               cwd=str(directory), check=True, shell=True)
                
            # Save credentials in settings
            self.settings['github_username'] = username
            self.settings['github_token'] = token  # Note: in production, handle tokens more securely
            self._save_settings()
            
            return True, "GitHub authentication configured successfully"
        except SubprocessError as e:
            logger.error(f"Error configuring GitHub auth: {str(e)}")
            return False, f"Error configuring GitHub auth: {str(e)}"
            
    def add_remote(self, directory: StrPath, remote_url: str, remote_name: str = "origin") -> GitResult:
        """Add a remote repository to git config
        
        Args:
            directory: Repository directory
            remote_url: URL of the remote repository (e.g., https://github.com/username/repo.git)
            remote_name: Name of the remote (default: origin)
            
        Returns:
            tuple: (success, message)
        """
        try:
            # Check if remote already exists
            check_remote = subprocess.run(
                ['git', 'remote'], 
                cwd=str(directory), 
                check=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            
            remotes = check_remote.stdout.strip().split('\n')
            remotes = [r.strip() for r in remotes if r.strip()]
            
            if remote_name in remotes:
                # Remote exists, update it
                subprocess.run(
                    ['git', 'remote', 'set-url', remote_name, remote_url],
                    cwd=str(directory),
                    check=True
                )
                return True, f"Updated remote '{remote_name}' to {remote_url}"
            else:
                # Add new remote
                subprocess.run(
                    ['git', 'remote', 'add', remote_name, remote_url],
                    cwd=str(directory),
                    check=True
                )
                return True, f"Added remote '{remote_name}' with URL {remote_url}"
                
        except SubprocessError as e:
            logger.error(f"Error adding remote: {str(e)}")
            return False, f"Error adding remote: {str(e)}"
            
    def has_remote(self, directory: StrPath, remote_name: str = "origin") -> bool:
        """Check if the git repository has the specified remote
        
        Args:
            directory: Repository directory
            remote_name: Name of the remote to check (default: origin)
            
        Returns:
            bool: True if remote exists, False otherwise
        """
        try:
            result = subprocess.run(
                ['git', 'remote', 'get-url', remote_name],
                cwd=str(directory),
                check=False,  # Don't raise exception if remote doesn't exist
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            return result.returncode == 0
        except Exception:
            return False

    def create_remote_repository(self, name: str, description: str = "", private: bool = False) -> GitResult:
        """Create a new repository on GitHub via API
        
        Args:
            name: Repository name
            description: Repository description
            private: Whether the repository should be private
            
        Returns:
            tuple: (success, result or error message)
        """
        if not api_available or not self.is_authenticated():
            return False, "GitHub API not available or not authenticated"
            
        try:
            repo = self.github_api.create_repository(name, description, private)
            if repo:
                return True, repo
            else:
                return False, "Failed to create repository"
        except Exception as e:
            logger.error(f"Error creating remote repository: {str(e)}")
            return False, f"Error creating repository: {str(e)}"
            
    def connect_and_push(self, directory: StrPath, repo_name: str, description: str = "", private: bool = False) -> GitResult:
        """Create a remote repository and push local code to it
        
        Args:
            directory: Local directory with Git repository
            repo_name: Name for the remote repository
            description: Repository description
            private: Whether the repository should be private
            
        Returns:
            tuple: (success, message)
        """
        if not api_available or not self.is_authenticated():
            return False, "GitHub API not available or not authenticated"
            
        try:
            # First check if directory is a Git repository
            if not self.is_repo_initialized(directory):
                # Initialize Git repository
                init_success = self.init_repository(directory)
                if not init_success:
                    return False, "Failed to initialize Git repository"
                    
                # Add all files and make initial commit
                self.commit_changes(directory, "Initial commit")
            
            # Check if there are any commits
            try:
                check_commits = subprocess.run(
                    ['git', 'log', '-1'], 
                    cwd=str(directory),
                    check=False,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE
                )
                
                if check_commits.returncode != 0:
                    # No commits yet, create initial commit
                    self.commit_changes(directory, "Initial commit")
            except Exception:
                # Assume no commits, create initial commit
                self.commit_changes(directory, "Initial commit")
            
            # Create repository on GitHub
            success, result = self.create_remote_repository(repo_name, description, private)
            if not success:
                return False, f"Failed to create remote repository: {result}"
                
            # Get the repository URL
            clone_url = result.get("clone_url")
            if not clone_url:
                return False, "Remote repository created but URL not found"
                
            # Add remote
            add_remote_success, add_remote_msg = self.add_remote(directory, clone_url)
            if not add_remote_success:
                return False, f"Failed to add remote: {add_remote_msg}"
                
            # Push to remote
            push_success, push_msg = self.push_changes(directory)
            if not push_success:
                return False, f"Failed to push to remote: {push_msg}"
                
            return True, f"Successfully created and pushed to {clone_url}"
            
        except Exception as e:
            logger.error(f"Error connecting and pushing: {str(e)}")
            return False, f"Error connecting and pushing: {str(e)}"

    def _handle_oauth_success(self, token_info: OAuthTokenInfo) -> None:
        """Handle successful OAuth authentication
        
        Args:
            token_info: OAuth token information including access token and user data
        """
        try:
            self.oauth_token = token_info
            self.github_api.set_token(token_info['access_token'])
            
            # Store username in settings
            if 'user' in token_info and 'login' in token_info['user']:
                self.settings['github_username'] = token_info['user']['login']
                self._save_settings()
                
            logger.info("OAuth authentication successful")
            
        except Exception as e:
            logger.error(f"Error handling OAuth success: {str(e)}")
    
    def is_authenticated(self) -> bool:
        """Check if the user is authenticated with GitHub"""
        return self.oauth_token is not None and api_available and is_token_valid(self.oauth_token)

    def logout(self) -> bool:
        """Log out from GitHub by clearing the OAuth token and resetting manager state."""
        try:
            if api_available:
                from github_oauth import clear_oauth_token
                clear_oauth_token()

            # Reset attributes
            self.oauth_token = None
            if hasattr(self, 'github_api') and self.github_api:
                self.github_api.set_token(None)

            # Clear stored credentials from settings
            if 'github_username' in self.settings:
                del self.settings['github_username']
            if 'github_token' in self.settings:
                del self.settings['github_token']
            self._save_settings()

            logger.info("Successfully logged out from GitHub.")
            return True
        except Exception as e:
            logger.error(f"Error during logout: {str(e)}")
            return False

    def authenticate_with_oauth(self, parent: Optional[QWidget] = None) -> bool:
        """Start OAuth authentication flow

        Args:
            parent: Optional parent widget for dialogs

        Returns:
            bool: True if authentication was successful, False otherwise
        """
        if not api_available:
            logger.error("OAuth authentication not available - missing dependencies")
            QMessageBox.critical(
                parent or self.main_window,
                "GitHub Authentication Error",
                "OAuth authentication is not available. Please install required dependencies."
            )
            return False
            
        try:
            # Create and show OAuth dialog
            oauth_dialog = GitHubOAuthDialog(parent or self.main_window)
            
            # Connect signals
            oauth_dialog.auth_complete.connect(self._handle_oauth_success)
            
            # Show dialog
            if oauth_dialog.exec() == DIALOG_ACCEPTED:
                return True
            
            return False
            
        except Exception as e:
            logger.error(f"Error during OAuth authentication: {str(e)}")
            QMessageBox.critical(
                parent or self.main_window,
                "GitHub Authentication Error",
                f"Failed to authenticate with GitHub: {str(e)}"
            )
            return False

class GitHubConnectDialog(QDialog):
    """Dialog for connecting to GitHub repository"""
    
    def __init__(self, parent_widget: Optional[QWidget] = None, github_manager: Optional[GitHubManager] = None) -> None:
        super().__init__(parent_widget)
        self._parent_widget: Optional[QWidget] = parent_widget
        if github_manager is None:
            raise ValueError("github_manager is required")
        self._github_manager: GitHubManager = github_manager
        self.setup_ui()
        
    def setup_ui(self) -> None:
        """Set up the UI components"""
        self.setWindowTitle("Connect to GitHub Repository")
        self.setMinimumWidth(500)
        
        layout = QVBoxLayout()
        
        # Repository connection options
        connect_group = QVBoxLayout()
        
        # Connection mode radio buttons
        self.local_repo_radio = QRadioButton("Connect to Local Repository")
        self.local_repo_radio.setChecked(True)
        connect_group.addWidget(self.local_repo_radio)
        
        self.create_repo_radio = QRadioButton("Create New GitHub Repository")
        if not api_available or not self.github_manager.is_authenticated():
            self.create_repo_radio.setEnabled(False)
            self.create_repo_radio.setToolTip("GitHub API not available or not authenticated")
        connect_group.addWidget(self.create_repo_radio)
        
        self.clone_repo_radio = QRadioButton("Clone Existing Repository")
        connect_group.addWidget(self.clone_repo_radio)
        
        # Connect radio button signals
        self.local_repo_radio.toggled.connect(self.toggle_fields)
        self.create_repo_radio.toggled.connect(self.toggle_fields)
        self.clone_repo_radio.toggled.connect(self.toggle_fields)
        
        layout.addLayout(connect_group)
        
        # Authentication section
        auth_layout = QVBoxLayout()
        
        # OAuth authentication
        if api_available:
            auth_label = QLabel("Authentication:")
            auth_layout.addWidget(auth_label)
            
            oauth_layout = QHBoxLayout()
            
            # Show authentication status
            if self.github_manager.is_authenticated():
                user_info = self.github_manager.oauth_token.get('user', {})
                username = user_info.get('login', 'Unknown user')
                self.auth_status = QLabel(f"Authenticated as: <b>{username}</b>")
                self.auth_status.setStyleSheet("color: #2ecc71;")
                oauth_layout.addWidget(self.auth_status)
                
                self.logout_button = QPushButton("Log Out")
                self.logout_button.clicked.connect(self.github_manager.logout)
                oauth_layout.addWidget(self.logout_button)
            else:
                self.auth_status = QLabel("Not authenticated with GitHub")
                self.auth_status.setStyleSheet("color: #e74c3c;")
                oauth_layout.addWidget(self.auth_status)
                
                self.auth_button = QPushButton("Authenticate with GitHub")
                self.auth_button.setStyleSheet("background-color: #3498db; color: white; font-weight: bold;")
                self.auth_button.clicked.connect(self.authenticate)
                oauth_layout.addWidget(self.auth_button)
                
            auth_layout.addLayout(oauth_layout)
            layout.addLayout(auth_layout)
        
        # Horizontal line separator
        separator = QFrame()
        separator.setFrameShape(QFrame.Shape.HLine)
        separator.setFrameShadow(QFrame.Shadow.Sunken)
        layout.addWidget(separator)
        
        # Form layout for inputs
        form_layout = QFormLayout()
        
        # Local repository section
        self.local_dir_label = QLabel("Local Repository Directory:")
        form_layout.addRow(self.local_dir_label)
        
        # Create a container widget for the local_dir_layout
        self.local_dir_layout = QHBoxLayout()
        self.local_dir = QLineEdit()
        if self.github_manager and self.github_manager.current_repo:
            self.local_dir.setText(self.github_manager.current_repo)
        self.local_dir_layout.addWidget(self.local_dir)
        
        self.browse_button = QPushButton("Browse...")
        self.browse_button.clicked.connect(self.browse_directory)
        self.local_dir_layout.addWidget(self.browse_button)
        
        # Create a container widget for the layout
        self.local_dir_container = QWidget()
        self.local_dir_container.setLayout(self.local_dir_layout)
        form_layout.addRow("", self.local_dir_container)
        
        # Create repository section (hidden initially)
        self.repo_name_label = QLabel("Repository Name:")
        self.repo_name = QLineEdit()
        form_layout.addRow(self.repo_name_label, self.repo_name)
        
        self.repo_description_label = QLabel("Description:")
        self.repo_description = QLineEdit()
        form_layout.addRow(self.repo_description_label, self.repo_description)
        
        self.private_repo_label = QLabel("Private Repository:")
        self.private_repo = QCheckBox()
        self.private_repo.setChecked(True)
        form_layout.addRow(self.private_repo_label, self.private_repo)
        
        # Clone repository section (hidden initially)
        self.clone_url_label = QLabel("Repository URL:")
        self.clone_url = QLineEdit()
        self.clone_url.setPlaceholderText("https://github.com/username/repository.git")
        form_layout.addRow(self.clone_url_label, self.clone_url)
        
        self.clone_dir_label = QLabel("Clone To:")
        
        # Create a container widget for the clone_dir_layout
        self.clone_dir_layout = QHBoxLayout()
        self.clone_dir = QLineEdit()
        self.clone_dir_layout.addWidget(self.clone_dir)
        
        self.clone_browse_button = QPushButton("Browse...")
        self.clone_browse_button.clicked.connect(lambda: self.browse_directory(True))
        self.clone_dir_layout.addWidget(self.clone_browse_button)
        
        # Create a container widget for the layout
        self.clone_dir_container = QWidget()
        self.clone_dir_container.setLayout(self.clone_dir_layout)
        form_layout.addRow(self.clone_dir_label, self.clone_dir_container)
        
        layout.addLayout(form_layout)
        
        # Initialize state of form fields
        self.toggle_fields()
        
        # Buttons
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(self.connect_repository)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
        
        self.setLayout(layout)
        
    def authenticate(self):
        """Start GitHub OAuth authentication flow"""
        if self.github_manager.authenticate_with_oauth(self):
            # Update UI to show authenticated status
            if self.github_manager.oauth_token and 'user' in self.github_manager.oauth_token:
                username = self.github_manager.oauth_token['user'].get('login', 'Unknown user')
                self.auth_status.setText(f"Authenticated as: <b>{username}</b>")
                self.auth_status.setStyleSheet("color: #2ecc71;")
                
                # Replace authenticate button with logout button
                self.auth_button.setParent(None)
                self.auth_button.deleteLater()
                
                self.logout_button = QPushButton("Log Out")
                self.logout_button.clicked.connect(self.github_manager.logout)  # This is FIXED
                
                # Find the layout containing the auth_status
                for i in range(self.layout().count()):
                    item = self.layout().itemAt(i)
                    if isinstance(item, QVBoxLayout):
                        # Check if this layout contains auth_status
                        for j in range(item.count()):
                            sub_item = item.itemAt(j)
                            if isinstance(sub_item, QHBoxLayout) and sub_item.indexOf(self.auth_status) != -1:
                                sub_item.addWidget(self.logout_button)
                                break
                
                # Enable create repository option
                self.create_repo_radio.setEnabled(True)
                self.create_repo_radio.setToolTip("")
            
    def logout(self):
        """Log out from GitHub by clearing the OAuth token and resetting settings."""
        try:
            # Clear OAuth token
            from github_oauth import clear_oauth_token
            clear_oauth_token()
            
            # Reset attributes
            self.oauth_token = None
            
            # Only try to set token on github_api if it exists
            if hasattr(self, 'github_api') and self.github_api is not None:
                self.github_api.set_token(None)
            
            # Remove username and token from settings
            if 'github_username' in self.settings:
                del self.settings['github_username']
            if 'github_token' in self.settings:
                del self.settings['github_token']
            self._save_settings()
            
            logger.info("Logged out from GitHub")
            return True
            
        except Exception as e:
            logger.error(f"Error during logout: {str(e)}")
            return False
        
    def toggle_fields(self):
        """Show/hide fields based on selected mode"""
        local_mode = self.local_repo_radio.isChecked()
        create_mode = self.create_repo_radio.isChecked()
        clone_mode = self.clone_repo_radio.isChecked()
        
        # Local repository fields
        self.local_dir_label.setVisible(local_mode)
        self.local_dir_container.setVisible(local_mode)
        
        # Create repository fields
        self.repo_name_label.setVisible(create_mode)
        self.repo_name.setVisible(create_mode)
        self.repo_description_label.setVisible(create_mode)
        self.repo_description.setVisible(create_mode)
        self.private_repo_label.setVisible(create_mode)
        self.private_repo.setVisible(create_mode)
        
        # Clone repository fields
        self.clone_url_label.setVisible(clone_mode)
        self.clone_url.setVisible(clone_mode)
        self.clone_dir_label.setVisible(clone_mode)
        self.clone_dir_container.setVisible(clone_mode)
        
    def browse_directory(self, for_clone=False):
        """Open directory browser dialog"""
        directory = QFileDialog.getExistingDirectory(self, "Select Directory")
        if directory:
            if for_clone:
                self.clone_dir.setText(directory)
            else:
                self.local_dir.setText(directory)
        
    def connect_repository(self):
        """Connect to the repository based on selected mode"""
        if not self.github_manager.is_git_installed():
            QMessageBox.critical(self, "Error", "Git is not installed or not in PATH")
            return
        
        if self.local_repo_radio.isChecked():
            # Connect to local repository
            directory = self.local_dir.text()
            if not directory:
                QMessageBox.warning(self, "Input Error", "Please select a directory")
                return
                
            if not os.path.exists(directory):
                QMessageBox.warning(self, "Directory Error", "Directory does not exist")
                return
                
            # Check if directory is a git repository
            if not self.github_manager.is_repo_initialized(directory):
                response = QMessageBox.question(
                    self,
                    "Initialize Repository",
                    "The selected directory is not a Git repository. Would you like to initialize it?",
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
                )
                
                if response == QMessageBox.StandardButton.Yes:
                    success = self.github_manager.init_repository(directory)
                    if not success:
                        QMessageBox.critical(self, "Error", "Failed to initialize Git repository")
                        return
                else:
                    return
            
            # Set current repository
            self.github_manager.current_repo = directory
            self.github_manager.settings['current_repo'] = directory
            self.github_manager.save_settings()
            
            QMessageBox.information(self, "Success", f"Connected to repository at {directory}")
            self.accept()
            
        elif self.create_repo_radio.isChecked():
            # Create new repository on GitHub
            if not api_available or not self.github_manager.is_authenticated():
                QMessageBox.critical(self, "Authentication Error", "You must authenticate with GitHub first")
                return
                
            # Get repository information
            repo_name = self.repo_name.text().strip()
            description = self.repo_description.text().strip()
            private = self.private_repo.isChecked()
            directory = self.local_dir.text()
            
            if not repo_name:
                QMessageBox.warning(self, "Input Error", "Please enter a repository name")
                return
                
            if not directory:
                QMessageBox.warning(self, "Input Error", "Please select a directory")
                return
                
            if not os.path.exists(directory):
                QMessageBox.warning(self, "Directory Error", "Directory does not exist")
                return
                
            # Create repository and push to GitHub
            success, result = self.github_manager.connect_and_push(directory, repo_name, description, private)
            
            if success:
                # Set current repository
                self.github_manager.current_repo = directory
                self.github_manager.settings['current_repo'] = directory
                self.github_manager.save_settings()
                
                QMessageBox.information(self, "Success", f"Created and pushed to {result}")
                self.accept()
            else:
                QMessageBox.critical(self, "Error", f"Failed to create repository: {result}")
            
        elif self.clone_repo_radio.isChecked():
            # Clone repository
            url = self.clone_url.text().strip()
            directory = self.clone_dir.text().strip()
            
            if not url:
                QMessageBox.warning(self, "Input Error", "Please enter a repository URL")
                return
                
            if not directory:
                QMessageBox.warning(self, "Input Error", "Please select a target directory")
                return
                
            if not os.path.exists(directory):
                QMessageBox.warning(self, "Directory Error", "Directory does not exist")
                return
                
            # Check if directory is empty
            if os.listdir(directory):
                QMessageBox.warning(self, "Directory Error", "Target directory is not empty")
                return
                
            # Clone repository
            success = self.github_manager.clone_repository(url, directory)
            
            if success:
                # Set current repository
                self.github_manager.current_repo = directory
                self.github_manager.settings['current_repo'] = directory
                self.github_manager.save_settings()
                
                QMessageBox.information(self, "Success", f"Cloned repository to {directory}")
                self.accept()
            else:
                QMessageBox.critical(self, "Error", "Failed to clone repository")
        else:
            QMessageBox.warning(self, "Error", "Please select a connection method")
            return


class GitHubPullDialog(QDialog):
    """Dialog for pulling changes from GitHub"""
    
    def __init__(self, parent=None, github_manager=None):
        super().__init__(parent)
        self.parent = parent
        self.github_manager = github_manager
        self.setup_ui()
        
    def setup_ui(self):
        """Set up the UI components"""
        self.setWindowTitle("Pull Changes from GitHub")
        self.setMinimumWidth(400)
        
        layout = QVBoxLayout()
        
        # Repository info
        if self.github_manager.current_repo:
            repo_label = QLabel(f"Current repository: {self.github_manager.current_repo}")
            layout.addWidget(repo_label)
            
            # Get branches
            branches = self.github_manager.get_branches(self.github_manager.current_repo)
            
            # Branch selection with create branch button
            branch_layout = QHBoxLayout()
            branch_form = QFormLayout()
            
            self.branch_combo = QComboBox()
            if branches:
                self.branch_combo.addItems(branches)
            else:
                self.branch_combo.addItem("main")
            branch_form.addRow("Branch to pull:", self.branch_combo)
            branch_layout.addLayout(branch_form)
            
            # Create branch button
            create_branch_btn = QPushButton("Create Branch")
            create_branch_btn.clicked.connect(self.show_create_branch_dialog)
            branch_layout.addWidget(create_branch_btn)
            
            layout.addLayout(branch_layout)
            
            # Status display
            status = self.github_manager.get_status(self.github_manager.current_repo)
            if status:
                status_label = QLabel("Warning: You have uncommitted changes:")
                layout.addWidget(status_label)
                
                status_text = QTextEdit()
                status_text.setReadOnly(True)
                status_text.setPlainText(status)
                status_text.setMaximumHeight(100)
                layout.addWidget(status_text)
                
            # Options
            self.stash_option = QCheckBox("Stash local changes before pulling")
            layout.addWidget(self.stash_option)
            
            # Buttons
            buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
            buttons.accepted.connect(self.pull_changes)
            buttons.rejected.connect(self.reject)
            layout.addWidget(buttons)
        else:
            error_label = QLabel("No repository is connected. Please connect to a repository first.")
            layout.addWidget(error_label)
            
            connect_button = QPushButton("Connect Repository")
            connect_button.clicked.connect(self.open_connect_dialog)
            layout.addWidget(connect_button)
            
            cancel_button = QPushButton("Cancel")
            cancel_button.clicked.connect(self.reject)
            layout.addWidget(cancel_button)
        
        self.setLayout(layout)
        
    def open_connect_dialog(self):
        """Open connect repository dialog"""
        self.reject()  # Close current dialog
        if hasattr(self.parent, 'show_github_connect'):
            self.parent.show_github_connect()
            
    def show_create_branch_dialog(self):
        """Show dialog to create a new branch"""
        dialog = CreateBranchDialog(self, self.github_manager)
        if dialog.exec() == DIALOG_ACCEPTED and dialog.new_branch_name:
            # Refresh branch combo and select the new branch
            branches = self.github_manager.get_branches(self.github_manager.current_repo)
            self.branch_combo.clear()
            if branches:
                self.branch_combo.addItems(branches)
                # Select the new branch
                index = self.branch_combo.findText(dialog.new_branch_name)
                if index >= 0:
                    self.branch_combo.setCurrentIndex(index)
            
    def pull_changes(self):
        """Pull changes from remote"""
        repository = self.github_manager.current_repo
        branch = self.branch_combo.currentText()
        
        # Check if remote repository is configured
        if not self.github_manager.has_remote(repository):
            response = QMessageBox.question(
                self,
                "No Remote Repository",
                "No remote repository is configured. Would you like to configure one now?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            
            if response == QMessageBox.StandardButton.Yes:
                self.show_remote_config_dialog()
                return
            else:
                return
        
        # Stash changes if option selected
        if self.stash_option.isChecked():
            try:
                # Ensure Git user configuration before stashing
                name_check = subprocess.run(
                    ['git', 'config', 'user.name'],
                    cwd=repository,
                    check=False,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True
                )
                
                email_check = subprocess.run(
                    ['git', 'config', 'user.email'],
                    cwd=repository,
                    check=False,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True
                )
                
                # Set default values if not configured
                if name_check.returncode != 0 or not name_check.stdout.strip():
                    subprocess.run(
                        ['git', 'config', 'user.name', 'Netlify Deployer'],
                        cwd=repository,
                        check=True
                    )
                
                if email_check.returncode != 0 or not email_check.stdout.strip():
                    subprocess.run(
                        ['git', 'config', 'user.email', 'netlify-deployer@localhost'],
                        cwd=repository,
                        check=True
                    )
                
                # Now stash changes
                subprocess.run(['git', 'stash'], cwd=repository, check=True)
            except subprocess.SubprocessError as e:
                QMessageBox.warning(self, "Warning", f"Failed to stash changes: {str(e)}")
                return
        
        # Pull changes
        success, message = self.github_manager.pull_changes(repository, branch)
        
        # Apply stash if needed
        if self.stash_option.isChecked() and success:
            try:
                subprocess.run(['git', 'stash', 'pop'], cwd=repository, check=True)
            except subprocess.SubprocessError as e:
                QMessageBox.warning(self, "Warning", 
                    f"Changes pulled successfully but failed to apply stashed changes: {str(e)}")
                self.accept()
                return
        
        if success:
            QMessageBox.information(self, "Success", message)
            self.accept()
        else:
            QMessageBox.critical(self, "Error", message)
            
    def show_remote_config_dialog(self):
        """Show remote repository configuration dialog"""
        dialog = RemoteRepositoryDialog(self.parent, self.github_manager)
        if dialog.exec() == DIALOG_ACCEPTED:
            # Try pull again if remote was configured successfully
            self.pull_changes()


class GitHubPushDialog(QDialog):
    """Dialog for pushing changes to GitHub"""
    
    def __init__(self, parent=None, github_manager=None):
        super().__init__(parent)
        self.parent = parent
        self.github_manager = github_manager
        self.setup_ui()
        
    def setup_ui(self):
        """Set up the UI components"""
        self.setWindowTitle("Push Changes to GitHub")
        self.setMinimumWidth(450)
        
        layout = QVBoxLayout()
        
        # Repository info
        if self.github_manager.current_repo:
            repo_label = QLabel(f"Current repository: {self.github_manager.current_repo}")
            layout.addWidget(repo_label)
            
            # Get status
            status = self.github_manager.get_status(self.github_manager.current_repo)
            
            # Status display
            status_label = QLabel("Current changes:")
            layout.addWidget(status_label)
            
            self.status_text = QTextEdit()
            self.status_text.setReadOnly(True)
            self.status_text.setPlainText(status if status else "No changes detected")
            self.status_text.setMaximumHeight(120)
            layout.addWidget(self.status_text)
            
            # Commit message
            commit_layout = QFormLayout()
            self.commit_message = QLineEdit()
            commit_layout.addRow("Commit message:", self.commit_message)
            layout.addLayout(commit_layout)
            
            # Branch selection with create branch button
            branch_layout = QHBoxLayout()
            branch_form = QFormLayout()
            
            self.branch_combo = QComboBox()
            branches = self.github_manager.get_branches(self.github_manager.current_repo)
            if branches:
                self.branch_combo.addItems(branches)
            else:
                self.branch_combo.addItem("main")
            branch_form.addRow("Branch to push:", self.branch_combo)
            branch_layout.addLayout(branch_form)
            
            # Create branch button
            create_branch_btn = QPushButton("Create Branch")
            create_branch_btn.clicked.connect(self.show_create_branch_dialog)
            branch_layout.addWidget(create_branch_btn)
            
            layout.addLayout(branch_layout)
            
            # Buttons
            buttons_layout = QHBoxLayout()
            
            self.commit_button = QPushButton("Commit Changes")
            self.commit_button.clicked.connect(self.commit_changes)
            self.commit_button.setEnabled(bool(status))
            buttons_layout.addWidget(self.commit_button)
            
            self.push_button = QPushButton("Push to GitHub")
            self.push_button.clicked.connect(self.push_changes)
            buttons_layout.addWidget(self.push_button)
            
            cancel_button = QPushButton("Cancel")
            cancel_button.clicked.connect(self.reject)
            buttons_layout.addWidget(cancel_button)
            
            layout.addLayout(buttons_layout)
        else:
            error_label = QLabel("No repository is connected. Please connect to a repository first.")
            layout.addWidget(error_label)
            
            connect_button = QPushButton("Connect Repository")
            connect_button.clicked.connect(self.open_connect_dialog)
            layout.addWidget(connect_button)
            
            cancel_button = QPushButton("Cancel")
            cancel_button.clicked.connect(self.reject)
            layout.addWidget(cancel_button)
        
        self.setLayout(layout)
        
    def open_connect_dialog(self):
        """Open connect repository dialog"""
        self.reject()  # Close current dialog
        if hasattr(self.parent, 'show_github_connect'):
            self.parent.show_github_connect()
            
                    self.branch_combo.setCurrentIndex(index)
            
    def commit_changes(self):
        """Commit local changes"""
        if not self.commit_message.text():
            QMessageBox.warning(self, "Input Error", "Please enter a commit message")
            return
            
        repository = self.github_manager.current_repo
        message = self.commit_message.text()
        
        success, result_message = self.github_manager.commit_changes(repository, message)
        
        if success:
            QMessageBox.information(self, "Success", result_message)
            
            # Refresh status
            status = self.github_manager.get_status(repository)
            self.status_text.setPlainText(status if status else "No changes detected")
            self.commit_button.setEnabled(bool(status))
        else:
            QMessageBox.critical(self, "Error", result_message)
            
    def push_changes(self):
        """Push changes to remote"""
        repository = self.github_manager.current_repo
        branch = self.branch_combo.currentText()
        
        # Check if remote repository is configured
        if not self.github_manager.has_remote(repository):
            response = QMessageBox.question(
                self,
                "No Remote Repository",
                "No remote repository is configured. Would you like to configure one now?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            
            if response == QMessageBox.StandardButton.Yes:
                self.show_remote_config_dialog()
                return
            else:
                return
        
        success, message = self.github_manager.push_changes(repository, branch)
        
        if success:
            QMessageBox.information(self, "Success", message)
            self.accept()
        else:
            QMessageBox.critical(self, "Error", message)
            
    def show_remote_config_dialog(self):
        """Show remote repository configuration dialog"""
        dialog = RemoteRepositoryDialog(self.parent, self.github_manager)
        if dialog.exec() == DIALOG_ACCEPTED:
            # Try push again if remote was configured successfully
            self.push_changes()


class GitHubHistoryDialog(QDialog):
    """Dialog for viewing GitHub commit history"""
    
    def __init__(self, parent=None, github_manager=None):
        super().__init__(parent)
        self.parent = parent
        self.github_manager = github_manager
        self.setup_ui()
        
    def setup_ui(self):
        """Set up the UI components"""
        self.setWindowTitle("GitHub Commit History")
        self.setMinimumWidth(650)
        self.setMinimumHeight(400)
        
        layout = QVBoxLayout()
        
        # Repository info
        if self.github_manager.current_repo:
            repo_layout = QHBoxLayout()
            repo_label = QLabel(f"Repository: {self.github_manager.current_repo}")
            repo_layout.addWidget(repo_label)
            
            # Branch selection
            self.branch_combo = QComboBox()
            branches = self.github_manager.get_branches(self.github_manager.current_repo)
            if branches:
                self.branch_combo.addItems(branches)
            else:
                self.branch_combo.addItem("main")
            self.branch_combo.currentIndexChanged.connect(self.refresh_history)
            
            branch_layout = QHBoxLayout()
            branch_label = QLabel("Branch:")
            branch_layout.addWidget(branch_label)
            branch_layout.addWidget(self.branch_combo)
            repo_layout.addLayout(branch_layout)
            
            # Refresh button
            refresh_button = QPushButton("Refresh")
            refresh_button.clicked.connect(self.refresh_history)
            repo_layout.addWidget(refresh_button)
            
            layout.addLayout(repo_layout)            # History tree
            self.history_tree = QTreeWidget()
            self.history_tree.setHeaderLabels(["Commit", "Author", "Date", "Message"])
            self.history_tree.header().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
            self.history_tree.header().setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
            self.history_tree.header().setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
            self.history_tree.header().setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)
            layout.addWidget(self.history_tree)
            
            # Details view
            details_label = QLabel("Commit Details")
            layout.addWidget(details_label)
            
            self.details_text = QTextEdit()
            self.details_text.setReadOnly(True)
            self.details_text.setMaximumHeight(100)
            layout.addWidget(self.details_text)
            
            # Connect item clicked
            self.history_tree.itemClicked.connect(self.show_commit_details)
            
            # Load commit history
            self.load_commit_history()
            
            # Buttons
            buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
            buttons.rejected.connect(self.reject)
            layout.addWidget(buttons)
        else:
            error_label = QLabel("No repository is connected. Please connect to a repository first.")
            layout.addWidget(error_label)
            
            connect_button = QPushButton("Connect Repository")
            connect_button.clicked.connect(self.open_connect_dialog)
            layout.addWidget(connect_button)
            
            cancel_button = QPushButton("Cancel")
            cancel_button.clicked.connect(self.reject)
            layout.addWidget(cancel_button)
        
        self.setLayout(layout)
        
    def open_connect_dialog(self):
        """Open connect repository dialog"""
        self.reject()  # Close current dialog
        if hasattr(self.parent, 'show_github_connect'):
            self.parent.show_github_connect()
            
    def load_commit_history(self):
        """Load commit history"""
        repository = self.github_manager.current_repo
        
        # Clear current history
        self.history_tree.clear()
        
        # Check if a branch is selected
        branch = self.branch_combo.currentText()
        if branch:
            try:
                # Checkout the branch first
                self.github_manager.checkout_branch(repository, branch)
                
                # Get commits
                commits = self.github_manager.get_commit_history(repository)
                  # Add commits to tree
                for commit in commits:
                    item = QTreeWidgetItem(self.history_tree)
                    item.setText(0, commit['hash'])
                    item.setText(1, commit['author'])
                    item.setText(2, commit['time'])
                    item.setText(3, commit['message'])
                    item.setData(0, Qt.ItemDataRole.UserRole, commit)
            except Exception as e:                QMessageBox.warning(self, "Error", f"Failed to load commit history: {str(e)}")

    def refresh_history(self):
        """Refresh commit history"""
        self.load_commit_history()

    def show_commit_details(self, item, column):
        """Show details for selected commit"""
        commit_data = item.data(0, Qt.ItemDataRole.UserRole)
        if commit_data:
            # Get full commit details
            repository = self.github_manager.current_repo
            try:
                result = subprocess.run(
                    ['git', 'show', commit_data['hash']], 
                    cwd=repository, 
                    check=True, 
                    stdout=subprocess.PIPE, 
                    text=True
                )
                self.details_text.setPlainText(result.stdout)
            except subprocess.SubprocessError as e:
                self.details_text.setPlainText(f"Error getting commit details: {str(e)}")


class GitHubPRDialog(QDialog):
    """Dialog for managing Pull Requests"""
    
    def __init__(self, parent=None, github_manager=None):
        super().__init__(parent)
        self.parent = parent
        self.github_manager = github_manager
        self.setup_ui()
        
    def setup_ui(self):
        """Set up the UI components"""
        self.setWindowTitle("GitHub Pull Requests")
        self.setMinimumWidth(700)
        self.setMinimumHeight(500)
        
        layout = QVBoxLayout()
        
        # Add info label
        info_label = QLabel("GitHub Pull Request management requires using the GitHub API which is not yet implemented. Please use the GitHub website to manage pull requests for now.")
        info_label.setWordWrap(True)
        layout.addWidget(info_label)
        
        # Add link to GitHub
        if self.github_manager.current_repo:
            # Extract repo owner/name from git config
            try:
                repo_path = self.github_manager.current_repo
                result = subprocess.run(
                    ['git', 'config', '--get', 'remote.origin.url'], 
                    cwd=repo_path, 
                    check=True, 
                    stdout=subprocess.PIPE, 
                    stderr=subprocess.PIPE,
                    text=True
                )
                remote_url = result.stdout.strip()
                
                # Parse URL to extract owner/repo
                if remote_url:
                    # Handle different URL formats
                    if remote_url.startswith('https://'):
                        # HTTPS format: https://github.com/owner/repo.git
                        parts = remote_url.split('/')
                        if len(parts) >= 5:
                            owner = parts[-2]
                            repo = parts[-1].replace('.git', '')
                            web_url = f"https://github.com/{owner}/{repo}/pulls"
                            
                            link_text = QLabel(f"<a href='{web_url}'>Open Pull Requests on GitHub</a>")
                            link_text.setOpenExternalLinks(True)
                            layout.addWidget(link_text)
                    elif remote_url.startswith('git@'):
                        # SSH format: git@github.com:owner/repo.git
                        parts = remote_url.split(':')
                        if len(parts) >= 2:
                            repo_part = parts[1].replace('.git', '')
                            web_url = f"https://github.com/{repo_part}/pulls"
                            
                            link_text = QLabel(f"<a href='{web_url}'>Open Pull Requests on GitHub</a>")
                            link_text.setOpenExternalLinks(True)
                            layout.addWidget(link_text)
            except Exception as e:
                error_label = QLabel(f"Error getting repository URL: {str(e)}")
                layout.addWidget(error_label)
        
        # Close button
        close_button = QPushButton("Close")
        close_button.clicked.connect(self.reject)
        layout.addWidget(close_button)
        
        self.setLayout(layout)

class CreateBranchDialog(QDialog):
    """Dialog for creating a new Git branch"""
    
    def __init__(self, parent=None, github_manager=None):
        super().__init__(parent)
        self.parent = parent
        self.github_manager = github_manager
        self.repository = self.github_manager.current_repo if self.github_manager else None
        self.new_branch_name = None
        self.setup_ui()
        
    def setup_ui(self):
        """Set up the UI components"""
        self.setWindowTitle("Create New Branch")
        self.setMinimumWidth(400)
        
        layout = QVBoxLayout()
        
        # Repository info
        if self.repository:
            repo_label = QLabel(f"Repository: {self.repository}")
            layout.addWidget(repo_label)
            
            # Branch info
            branch_layout = QFormLayout()
            
            # Current branch
            branches = self.github_manager.get_branches(self.repository)
            current_branch = branches[0] if branches else "main"
            current_branch_label = QLabel(current_branch)
            branch_layout.addRow("Current branch:", current_branch_label)
            
            # New branch name input
            self.branch_name = QLineEdit()
            self.branch_name.setPlaceholderText("Enter new branch name")
            branch_layout.addRow("New branch name:", self.branch_name)
            
            # Checkout options
            self.checkout_option = QCheckBox("Checkout new branch after creation")
            self.checkout_option.setChecked(True)
            branch_layout.addRow("", self.checkout_option)
            
            layout.addLayout(branch_layout)
            
            # Buttons
            buttons = QDialogButtonBox(
                QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
            )
            buttons.accepted.connect(self.create_branch)
            buttons.rejected.connect(self.reject)
            layout.addWidget(buttons)
        else:
            error_label = QLabel("No repository is connected. Please connect to a repository first.")
            layout.addWidget(error_label)
            
            cancel_button = QPushButton("Close")
            cancel_button.clicked.connect(self.reject)
            layout.addWidget(cancel_button)
        
        self.setLayout(layout)
    
    def create_branch(self):
        """Create a new branch"""
        branch_name = self.branch_name.text().strip()
        
        if not branch_name:
            QMessageBox.warning(self, "Input Error", "Please enter a branch name")
            return
        
        # Validate branch name (basic validation)
        if ' ' in branch_name or '..' in branch_name or branch_name.startswith('.'):
            QMessageBox.warning(
                self, 
                "Invalid Branch Name", 
                "Branch names cannot contain spaces or '..' and cannot start with '.'"
            )
            return
        
        # Create the branch
        success, message = self.github_manager.create_branch(
            self.repository, branch_name
        )
        
        if success:
            self.new_branch_name = branch_name
            QMessageBox.information(self, "Success", message)
            self.accept()
        else:
            QMessageBox.critical(self, "Error", message)

class RemoteRepositoryDialog(QDialog):
    """Dialog for configuring remote repository"""
    
    def __init__(self, parent=None, github_manager=None):
        super().__init__(parent)
        self.parent = parent
        self.github_manager = github_manager
        self.repository = self.github_manager.current_repo if self.github_manager else None
        self.setup_ui()
        
    def setup_ui(self):
        """Set up the UI components"""
        self.setWindowTitle("Configure Remote Repository")
        self.setMinimumWidth(500)
        
        layout = QVBoxLayout()
        
        # Repository info
        if self.repository:
            repo_label = QLabel(f"Repository: {self.repository}")
            layout.addWidget(repo_label)
            
            # Check if remote exists
            has_remote = self.github_manager.has_remote(self.repository)
            
            if has_remote:
                try:
                    # Get remote URL
                    result = subprocess.run(
                        ['git', 'remote', 'get-url', 'origin'],
                        cwd=self.repository,
                        check=True,
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE,
                        text=True
                    )
                    remote_url = result.stdout.strip()
                    
                    status_label = QLabel(f"Current remote URL: <b>{remote_url}</b>")
                    status_label.setStyleSheet("color: #2ecc71;")
                    layout.addWidget(status_label)
                    
                    # Option to update URL
                    update_label = QLabel("Update remote URL:")
                except Exception:
                    status_label = QLabel("Remote 'origin' exists but URL could not be retrieved")
                    status_label.setStyleSheet("color: #e67e22;")
                    layout.addWidget(status_label)
                    
                    update_label = QLabel("Set remote URL:")
            else:
                status_label = QLabel("No remote 'origin' configured")
                status_label.setStyleSheet("color: #e74c3c;")
                layout.addWidget(status_label)
                
                update_label = QLabel("Set remote URL:")
            
            layout.addWidget(update_label)
            
            # Remote URL input
            self.remote_url = QLineEdit()
            self.remote_url.setPlaceholderText("https://github.com/username/repository.git")
            layout.addWidget(self.remote_url)
            
            # Authentication options
            auth_group = QVBoxLayout()
            auth_label = QLabel("Authentication Method:")
            auth_group.addWidget(auth_label)
            
            # OAuth option
            self.oauth_radio = QRadioButton("Use OAuth Authentication (recommended)")
            if api_available and self.github_manager.is_authenticated():
                self.oauth_radio.setChecked(True)
                user_info = self.github_manager.oauth_token.get('user', {})
                username = user_info.get('login', 'Unknown user')
                oauth_status = QLabel(f"Authenticated as: <b>{username}</b>")
                oauth_status.setStyleSheet("color: #2ecc71; margin-left: 20px;")
                auth_group.addWidget(oauth_status)
            else:
                self.oauth_radio.setEnabled(False)
                self.oauth_radio.setToolTip("OAuth authentication not available")
                
            auth_group.addWidget(self.oauth_radio)
            
            # Manual credentials option
            self.manual_radio = QRadioButton("Use Manual Credentials")
            if not (api_available and self.github_manager.is_authenticated()):
                self.manual_radio.setChecked(True)
            auth_group.addWidget(self.manual_radio)
            
            # Credential fields
            creds_layout = QFormLayout()
            
            self.username = QLineEdit()
            if self.github_manager and 'github_username' in self.github_manager.settings:
                self.username.setText(self.github_manager.settings['github_username'])
            creds_layout.addRow("GitHub Username:", self.username)
            
            self.token = QLineEdit()
            self.token.setEchoMode(QLineEdit.EchoMode.Password)
            if self.github_manager and 'github_token' in self.github_manager.settings:
                self.token.setText(self.github_manager.settings['github_token'])
            creds_layout.addRow("Personal Access Token:", self.token)
            
            auth_group.addLayout(creds_layout)
            layout.addLayout(auth_group)
            
            # Connect radio buttons to enable/disable fields
            self.oauth_radio.toggled.connect(self.toggle_auth_fields)
            self.manual_radio.toggled.connect(self.toggle_auth_fields)
            
            # Initialize state of fields
            self.toggle_auth_fields()
            
            # Buttons
            buttons = QDialogButtonBox(
                QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
            )
            buttons.accepted.connect(self.configure_remote)
            buttons.rejected.connect(self.reject)
            layout.addWidget(buttons)
        else:
            # No repository selected
            error_label = QLabel("No repository is currently selected")
            error_label.setStyleSheet("color: #e74c3c;")
            layout.addWidget(error_label)
            
            close_button = QPushButton("Close")
            close_button.clicked.connect(self.reject)
            layout.addWidget(close_button)
        
        self.setLayout(layout)
        
    def toggle_auth_fields(self):
        """Enable/disable credential fields based on selected authentication method"""
        use_manual = self.manual_radio.isChecked()
        self.username.setEnabled(use_manual)
        self.token.setEnabled(use_manual)
        
    def close_and_connect(self):
        """Close dialog and show connect dialog"""
        self.accept()
        from github_integration import GitHubConnectDialog
        connect_dialog = GitHubConnectDialog(self.parent, self.github_manager)
        connect_dialog.exec()
        
    def configure_remote(self):
        """Configure remote repository"""
        remote_url = self.remote_url.text().strip()
        
        if not remote_url:
            QMessageBox.warning(self, "Input Error", "Please enter a remote repository URL")
            return
            
        # Configure remote
        success = False
        message = ""
        
        if self.oauth_radio.isChecked():
            # Use OAuth token
            if api_available and self.github_manager.is_authenticated():
                # Add remote using existing OAuth token
                success, message = self.github_manager.add_remote(self.repository, remote_url)
            else:
                QMessageBox.critical(self, "Authentication Error", "OAuth authentication is not available")
                return
        else:
            # Use manual credentials
            username = self.username.text().strip()
            token = self.token.text().strip()
            
            if not username or not token:
                QMessageBox.warning(self, "Input Error", "Please enter GitHub username and token")
                return
                
            # Configure authentication
            auth_success, auth_message = self.github_manager.configure_github_auth(
                self.repository, username, token
            )
            
            if not auth_success:
                QMessageBox.critical(self, "Authentication Error", auth_message)
                return
                
            # Add remote
            success, message = self.github_manager.add_remote(self.repository, remote_url)
            
        if success:
            QMessageBox.information(self, "Success", message)
            self.accept()
        else:
            QMessageBox.critical(self, "Error", message)