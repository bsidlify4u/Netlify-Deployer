"""
GitHub OAuth Authentication Module for Netlify Deployer
Provides secure OAuth-based authentication with GitHub
"""

import os
import json
import logging
import webbrowser
import http.server
import socketserver
import urllib.parse
import requests
import secrets
import threading
from urllib.parse import urlencode
from PyQt6.QtWidgets import QDialog, QVBoxLayout, QLabel, QPushButton, QProgressBar, QMessageBox
from PyQt6.QtCore import Qt, pyqtSignal, QThread

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("github_oauth")

# OAuth Configuration - These should be registered with GitHub
# In production, store these securely
GITHUB_CLIENT_ID = "Ov23lipu4QsfjT7sZC14"  # Replace with your GitHub OAuth App client ID
GITHUB_CLIENT_SECRET = "60a6f18aa464b5e1cc0e37e514ea3febf0eaf1d8"  # Replace with your GitHub OAuth App client secret
GITHUB_REDIRECT_URI = "http://localhost:8000/callback"
GITHUB_SCOPES = "repo,user"  # Access to repositories and user info

class OAuthCallbackHandler(http.server.BaseHTTPRequestHandler):
    """HTTP request handler for OAuth callback"""

    def do_GET(self):
        """Handle GET requests to callback URL"""
        try:
            # Parse the URL and extract code parameter
            query = urllib.parse.urlparse(self.path).query
            params = urllib.parse.parse_qs(query)

            if 'code' in params:
                # Store the code for token exchange
                self.server.oauth_code = params['code'][0]

                # Send success page to browser
                self.send_response(200)
                self.send_header('Content-type', 'text/html')
                self.end_headers()

                success_message = """
                <html>
                <head>
                    <title>GitHub Authentication Successful</title>
                    <style>
                        body { font-family: Arial, sans-serif; text-align: center; padding: 50px; }
                        h1 { color: #2ecc71; }
                        p { font-size: 18px; }
                    </style>
                </head>
                <body>
                    <h1>Authentication Successful!</h1>
                    <p>You have successfully authenticated with GitHub.</p>
                    <p>You can close this window and return to the application.</p>
                </body>
                </html>
                """
                self.wfile.write(success_message.encode())

            else:
                # Handle error case
                self.send_response(400)
                self.send_header('Content-type', 'text/html')
                self.end_headers()

                error_message = """
                <html>
                <head>
                    <title>GitHub Authentication Failed</title>
                    <style>
                        body { font-family: Arial, sans-serif; text-align: center; padding: 50px; }
                        h1 { color: #e74c3c; }
                        p { font-size: 18px; }
                    </style>
                </head>
                <body>
                    <h1>Authentication Failed</h1>
                    <p>Failed to authenticate with GitHub. Please try again.</p>
                </body>
                </html>
                """
                self.wfile.write(error_message.encode())

                self.server.oauth_error = "Authorization code not found in response"

        except Exception as e:
            logger.error(f"Error handling OAuth callback: {str(e)}")
            self.send_response(500)
            self.send_header('Content-type', 'text/plain')
            self.end_headers()
            self.wfile.write(f"Error: {str(e)}".encode())
            self.server.oauth_error = str(e)
        finally:
             # Signal the server to stop handling further requests after the current one
            self.server.stop_server = True

    def log_message(self, format, *args):
        """Override to prevent server logs from printing"""
        return


class OAuthCallbackServer(socketserver.TCPServer):
    """Custom server for handling OAuth callback"""

    def __init__(self, server_address, RequestHandlerClass):
        self.oauth_code = None
        self.oauth_error = None
        self.stop_server = False
        # Allow reusing the address
        self.allow_reuse_address = True
        super().__init__(server_address, RequestHandlerClass)

    def serve_until_stopped(self):
        """Serve requests until stop_server flag is set"""
        while not self.stop_server:
            # Handle one request at a time
            self.handle_request()
        # Close the server socket
        self.server_close()


class GitHubOAuthDialog(QDialog):
    """Dialog for OAuth authentication with GitHub"""

    # Signal emitted when authentication is complete
    auth_complete = pyqtSignal(dict)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.parent = parent
        self.setWindowTitle("GitHub Authentication")
        self.setMinimumWidth(450)
        self.setMinimumHeight(300)
        self.callback_server = None
        self.server_thread = None
        self.setup_ui()

        # Connect finished signal to stop the server
        self.finished.connect(self.stop_callback_server)

    def setup_ui(self):
        """Set up the UI components"""
        layout = QVBoxLayout()

        # Title and instruction
        title = QLabel("Connect to GitHub")
        title.setStyleSheet("font-size: 18px; font-weight: bold;")
        layout.addWidget(title)

        # Description text
        desc = QLabel(
            "You'll be redirected to GitHub to authorize access to your "
            "repositories. This allows the application to create repositories, "
            "push/pull changes, and manage issues on your behalf."
        )
        desc.setWordWrap(True)
        layout.addWidget(desc)

        # Permissions list
        perms = QLabel(
            "<b>The application will request these permissions:</b>"
            "<ul>"
            "<li>Read/write access to your repositories</li>"
            "<li>Access to your user information</li>"
            "</ul>"
        )
        perms.setWordWrap(True)
        layout.addWidget(perms)

        # Privacy note
        privacy = QLabel(
            "<small>Your GitHub credentials are never stored by this application. "
            "Access is granted through GitHub's secure OAuth protocol.</small>"
        )
        privacy.setWordWrap(True)
        privacy.setStyleSheet("color: #6c6c6c;")
        layout.addWidget(privacy)

        # Progress bar - hidden initially
        self.progress = QProgressBar()
        self.progress.setVisible(False)
        layout.addWidget(self.progress)

        # Status message - hidden initially
        self.status_label = QLabel()
        self.status_label.setVisible(False)
        self.status_label.setWordWrap(True)
        layout.addWidget(self.status_label)

        # Connect button
        self.connect_button = QPushButton("Connect to GitHub")
        self.connect_button.setStyleSheet("""
            QPushButton {
                background-color: #2ecc71;
                border: none;
                color: white;
                padding: 10px;
                font-weight: bold;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: #27ae60;
            }
            QPushButton:pressed {
                background-color: #1e8449;
            }
        """)
        self.connect_button.clicked.connect(self.start_oauth_flow)
        layout.addWidget(self.connect_button)

        # Cancel button
        self.cancel_button = QPushButton("Cancel")
        self.cancel_button.clicked.connect(self.reject)
        layout.addWidget(self.cancel_button)

        self.setLayout(layout)

    def start_oauth_flow(self):
        """Start the OAuth authentication flow"""
        self.connect_button.setEnabled(False)
        self.progress.setVisible(True)
        self.progress.setRange(0, 0)  # Indeterminate progress
        self.status_label.setVisible(True)
        self.status_label.setText("Connecting to GitHub...")

        try:
            # Generate state parameter for CSRF protection
            state = secrets.token_urlsafe(16)

            # Build GitHub authorization URL with parameters
            auth_params = {
                'client_id': GITHUB_CLIENT_ID,
                'redirect_uri': GITHUB_REDIRECT_URI,
                'scope': GITHUB_SCOPES,
                'state': state
            }
            auth_url = f"https://github.com/login/oauth/authorize?{urlencode(auth_params)}"

            # Open browser to GitHub authorization page
            webbrowser.open(auth_url)

            # Update status
            self.status_label.setText("Waiting for GitHub authorization...")

            # Start local server to receive callback
            self.start_callback_server()

        except Exception as e:
            logger.error(f"Error starting OAuth flow: {str(e)}")
            self.show_error(f"Error connecting to GitHub: {str(e)}")
            self.reset_ui()

    def start_callback_server(self):
        """Start local server to handle OAuth callback"""
        try:
            # Start server in a new thread

            def run_server():
                try:
                    # Create and configure server
                    # Use self.callback_server to store the server instance
                    self.callback_server = OAuthCallbackServer(('localhost', 8000), OAuthCallbackHandler)

                    # Serve until stopped
                    self.callback_server.serve_until_stopped()

                    # Process the result after the server stops
                    if self.callback_server.oauth_code:
                        self.exchange_code_for_token(self.callback_server.oauth_code)
                    elif self.callback_server.oauth_error:
                        self.show_error(self.callback_server.oauth_error)
                        self.reset_ui()
                    else:
                        # This case might happen if the dialog is closed before callback
                        logger.info("Callback server stopped without receiving code or error.")

                except Exception as e:
                    logger.error(f"Error in callback server thread: {str(e)}")
                    # Check if the error is the address already in use error specifically on Windows
                    if isinstance(e, OSError) and e.winerror == 10048:
                         self.show_error(f"Error handling GitHub callback: [WinError 10048] The local callback server address (localhost:8000) is already in use. Please ensure no other instance of the application is running and try again.")
                    else:
                        self.show_error(f"Error handling GitHub callback: {str(e)}")
                    self.reset_ui()
                finally:
                     # Ensure the server is explicitly closed if it wasn't already
                    if self.callback_server:
                        try:
                            self.callback_server.server_close()
                        except Exception as close_e:
                            logger.warning(f"Error closing callback server: {close_e}")
                    self.callback_server = None # Clear the reference

            # Start server thread
            self.server_thread = threading.Thread(target=run_server)
            self.server_thread.daemon = True # Allow the main program to exit even if this thread is running
            self.server_thread.start()

        except Exception as e:
            logger.error(f"Error starting callback server: {str(e)}")
            # Check if the error is the address already in use error specifically on Windows
            if isinstance(e, OSError) and e.winerror == 10048:
                 self.show_error(f"Error handling GitHub callback: [WinError 10048] The local callback server address (localhost:8000) is already in use. Please ensure no other instance of the application is running and try again.")
            else:
                self.show_error(f"Error handling GitHub callback: {str(e)}")
            self.reset_ui()

    def stop_callback_server(self):
        """Stop the local callback server and wait for the thread to finish."""
        if self.callback_server:
            logger.info("Stopping callback server...")
            self.callback_server.stop_server = True
            # Shutdown the server to interrupt serve_forever or handle_request
            # This needs to be done from a different thread than the server thread
            # Using shutdown() might not work directly from the main thread if handle_request is blocking
            # A simpler approach for this specific TCPServer structure is to set the flag and let handle_request finish
            # If handle_request is blocking, this might require a separate shutdown thread or using server.shutdown()
            # For now, rely on the handle_request completing quickly after the redirect.
            # If handle_request blocks indefinitely (e.g., waiting for a second request), server.shutdown() might be needed.
            # server.shutdown() should be called from a thread different from the one running serve_forever/handle_request.

            # Since handle_request processes a single request and then checks stop_server, setting the flag is sufficient.
            # We can wait for the server thread to join to ensure it's fully stopped.
            if self.server_thread and self.server_thread.is_alive():
                logger.info("Joining server thread...")
                # Give the server a moment to process the stop flag and close the socket
                # A small timeout prevents the UI from freezing indefinitely if something goes wrong.
                self.server_thread.join(timeout=1.0)
                if self.server_thread.is_alive():
                    logger.warning("Server thread did not terminate gracefully.")

            self.callback_server = None # Clear the reference
            self.server_thread = None


    def exchange_code_for_token(self, code):
        """Exchange authorization code for access token"""
        try:
            self.status_label.setText("Completing authentication...")

            # Prepare token request
            token_url = "https://github.com/login/oauth/access_token"
            token_params = {
                'client_id': GITHUB_CLIENT_ID,
                'client_secret': GITHUB_CLIENT_SECRET,
                'code': code,
                'redirect_uri': GITHUB_REDIRECT_URI
            }

            # Make token request
            headers = {'Accept': 'application/json'}
            response = requests.post(token_url, data=token_params, headers=headers)

            if response.status_code == 200:
                token_data = response.json()

                if 'access_token' in token_data:
                    # Get user info using the token
                    user_info = self.get_github_user_info(token_data['access_token'])

                    # Combine token and user info
                    result = {
                        'access_token': token_data['access_token'],
                        'token_type': token_data.get('token_type', 'bearer'),
                        'scope': token_data.get('scope', ''),
                        'user': user_info
                    }

                    # Save token information securely
                    self.save_token_info(result)

                    # Emit signal with auth result
                    self.auth_complete.emit(result)

                    # Close dialog with success
                    # Use QTimer.singleShot to ensure this happens after the current event loop iteration
                    # This prevents potential issues with emitting signals and closing the dialog simultaneously
                    from PyQt6.QtCore import QTimer
                    QTimer.singleShot(0, self.accept)

                else:
                    error_msg = token_data.get('error_description', 'Failed to get access token')
                    self.show_error(error_msg)
                    self.reset_ui()
            else:
                self.show_error(f"Token request failed with status: {response.status_code}")
                self.reset_ui()

        except Exception as e:
            logger.error(f"Error exchanging code for token: {str(e)}")
            self.show_error(f"Error completing GitHub authentication: {str(e)}")
            self.reset_ui()

    def get_github_user_info(self, token):
        """Get GitHub user information using the access token"""
        try:
            headers = {
                'Authorization': f'token {token}',
                'Accept': 'application/json'
            }
            response = requests.get('https://api.github.com/user', headers=headers)

            if response.status_code == 200:
                return response.json()
            else:
                logger.error(f"Error getting user info: {response.status_code}")
                return {}

        except Exception as e:
            logger.error(f"Error getting GitHub user info: {str(e)}")
            return {}

    def save_token_info(self, token_info):
        """Save token information securely"""
        try:
            # Create settings directory if needed
            settings_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'settings')
            os.makedirs(settings_dir, exist_ok=True)

            # Save token data to file
            token_file = os.path.join(settings_dir, 'github_oauth_token.json')

            # Use atomic write pattern with temporary file
            temp_file = f"{token_file}.tmp"
            with open(temp_file, 'w') as f:
                json.dump(token_info, f, indent=2)

            # Replace original file with new one
            os.replace(temp_file, token_file)

            # Set strict permissions on token file
            try:
                # On Unix-like systems, set read/write for owner only
                if hasattr(os, 'chmod'):
                    import stat
                    os.chmod(token_file, stat.S_IRUSR | stat.S_IWUSR)
            except Exception as e:
                logger.warning(f"Could not set strict permissions on token file: {e}")

        except Exception as e:
            logger.error(f"Error saving token information: {str(e)}")

    def reset_ui(self):
        """Reset the UI after failed auth attempt"""
        self.connect_button.setEnabled(True)
        self.progress.setVisible(False)
        self.status_label.setVisible(False) # Hide status label on reset

    def show_error(self, message):
        """Show error message"""
        # Use QTimer.singleShot to ensure this happens after the current event loop iteration
        from PyQt6.QtCore import QTimer
        QTimer.singleShot(0, lambda: self._display_error_message(message))

    def _display_error_message(self, message):
         self.status_label.setText(f"Error: {message}")
         self.status_label.setStyleSheet("color: #e74c3c;")
         self.status_label.setVisible(True) # Ensure status label is visible for errors
         QMessageBox.critical(self, "GitHub Authentication Error", message)


def load_oauth_token():
    """Load saved OAuth token if available"""
    try:
        settings_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'settings')
        token_file = os.path.join(settings_dir, 'github_oauth_token.json')

        if os.path.exists(token_file):
            with open(token_file, 'r') as f:
                return json.load(f)
        return None
    except Exception as e:
        logger.error(f"Error loading OAuth token: {str(e)}")
        return None


def is_token_valid(token_info):
    """Check if the token is still valid"""
    try:
        if not token_info or 'access_token' not in token_info:
            return False

        headers = {
            'Authorization': f'token {token_info["access_token"]}',
            'Accept': 'application/json'
        }
        response = requests.get('https://api.github.com/user', headers=headers)
        return response.status_code == 200
    except Exception:
        return False


def clear_oauth_token():
    """Clear saved OAuth token"""
    try:
        settings_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'settings')
        token_file = os.path.join(settings_dir, 'github_oauth_token.json')

        if os.path.exists(token_file):
            os.remove(token_file)
            return True
        return False
    except Exception as e:
        logger.error(f"Error clearing OAuth token: {str(e)}")
        return False