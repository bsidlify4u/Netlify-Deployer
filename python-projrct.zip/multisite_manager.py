#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Multi-Site Management Feature for Netlify Deployer
Allows managing and deploying to multiple Netlify sites from a single interface
"""

import os
import json
import time
import requests
import logging
from datetime import datetime
from typing import Dict, List, Optional, Tuple, Any

from PyQt6.QtCore import Qt, pyqtSignal, QSize, QThread
from PyQt6.QtGui import QIcon, QAction, QPixmap
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, 
    QListWidget, QListWidgetItem, QLineEdit, QComboBox, 
    QTabWidget, QWidget, QFormLayout, QMessageBox, QMenu,
    QTableWidget, QTableWidgetItem, QHeaderView, QFileDialog,
    QCheckBox, QGroupBox, QSplitter, QTextEdit, QToolButton,
    QProgressBar, QApplication
)

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("multisite_manager")

# Constants
SITES_CONFIG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'settings', 'managed_sites.json')


class NetlifyAPIClient:
    """Client for interacting with Netlify API"""
    
    BASE_URL = "https://api.netlify.com/api/v1"
    
    def __init__(self, token: str):
        self.token = token
        self.headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }
    
    def get_sites(self) -> List[Dict[str, Any]]:
        """Get all sites for the authenticated user"""
        try:
            response = requests.get(f"{self.BASE_URL}/sites", headers=self.headers)
            
            if response.status_code == 200:
                return response.json()
            else:
                error_msg = f"Failed to fetch sites: {response.status_code}"
                try:
                    error_data = response.json()
                    if 'message' in error_data:
                        error_msg += f" - {error_data['message']}"
                    else:
                        error_msg += f" - {response.text}"
                except:
                    error_msg += f" - {response.text}"
                
                logger.error(error_msg)
                raise Exception(error_msg)
        except requests.RequestException as e:
            logger.error(f"Network error fetching sites: {str(e)}")
            raise Exception(f"Network error fetching sites: {str(e)}")
    
    def get_site(self, site_id: str) -> Dict[str, Any]:
        """Get details for a specific site"""
        try:
            response = requests.get(f"{self.BASE_URL}/sites/{site_id}", headers=self.headers)
            
            if response.status_code == 200:
                return response.json()
            else:
                error_msg = f"Failed to fetch site details: {response.status_code}"
                try:
                    error_data = response.json()
                    if 'message' in error_data:
                        error_msg += f" - {error_data['message']}"
                    else:
                        error_msg += f" - {response.text}"
                except:
                    error_msg += f" - {response.text}"
                
                logger.error(error_msg)
                raise Exception(error_msg)
        except requests.RequestException as e:
            logger.error(f"Network error fetching site details: {str(e)}")
            raise Exception(f"Network error fetching site details: {str(e)}")
    
    def get_site_deploys(self, site_id: str) -> List[Dict[str, Any]]:
        """Get deployment history for a site"""
        try:
            response = requests.get(f"{self.BASE_URL}/sites/{site_id}/deploys", headers=self.headers)
            
            if response.status_code == 200:
                return response.json()
            else:
                error_msg = f"Failed to fetch deploys: {response.status_code}"
                try:
                    error_data = response.json()
                    if 'message' in error_data:
                        error_msg += f" - {error_data['message']}"
                    else:
                        error_msg += f" - {response.text}"
                except:
                    error_msg += f" - {response.text}"
                
                logger.error(error_msg)
                raise Exception(error_msg)
        except requests.RequestException as e:
            logger.error(f"Network error fetching deploys: {str(e)}")
            raise Exception(f"Network error fetching deploys: {str(e)}")
            
    def delete_site(self, site_id: str) -> bool:
        """Delete a site from Netlify"""
        try:
            response = requests.delete(f"{self.BASE_URL}/sites/{site_id}", headers=self.headers)
            
            if response.status_code in [200, 204]:
                logger.info(f"Successfully deleted site {site_id} from Netlify")
                return True
            else:
                error_msg = f"Failed to delete site: {response.status_code}"
                try:
                    error_data = response.json()
                    if 'message' in error_data:
                        error_msg += f" - {error_data['message']}"
                    else:
                        error_msg += f" - {response.text}"
                except:
                    error_msg += f" - {response.text}"
                
                logger.error(error_msg)
                raise Exception(error_msg)
        except requests.RequestException as e:
            logger.error(f"Network error deleting site: {str(e)}")
            raise Exception(f"Network error deleting site: {str(e)}")


class FetchSitesWorker(QThread):
    """Worker thread for fetching sites from Netlify API"""
    
    sites_fetched = pyqtSignal(list)
    error = pyqtSignal(str)
    
    def __init__(self, token: str):
        super().__init__()
        self.token = token
    
    def run(self):
        """Run the worker thread to fetch sites"""
        try:
            client = NetlifyAPIClient(self.token)
            sites = client.get_sites()
            self.sites_fetched.emit(sites)
        except Exception as e:
            logger.error(f"Error fetching sites: {str(e)}")
            self.error.emit(str(e))


class FetchSiteDeploysWorker(QThread):
    """Worker thread for fetching site deployment history"""
    
    deploys_fetched = pyqtSignal(list)
    error = pyqtSignal(str)
    
    def __init__(self, token: str, site_id: str):
        super().__init__()
        self.token = token
        self.site_id = site_id
    
    def run(self):
        """Run the worker thread to fetch site deploys"""
        try:
            client = NetlifyAPIClient(self.token)
            deploys = client.get_site_deploys(self.site_id)
            self.deploys_fetched.emit(deploys)
        except Exception as e:
            logger.error(f"Error fetching deploys: {str(e)}")
            self.error.emit(str(e))


class DeleteSiteWorker(QThread):
    """Worker thread for deleting a site from Netlify API"""
    
    deletion_complete = pyqtSignal(bool)
    error = pyqtSignal(str)
    
    def __init__(self, token: str, site_id: str):
        super().__init__()
        self.token = token
        self.site_id = site_id
    
    def run(self):
        """Run the worker thread to delete a site"""
        try:
            client = NetlifyAPIClient(self.token)
            result = client.delete_site(self.site_id)
            self.deletion_complete.emit(result)
        except Exception as e:
            logger.error(f"Error deleting site: {str(e)}")
            self.error.emit(str(e))


class Site:
    """Class representing a Netlify site configuration"""
    
    def __init__(self, name: str = "", site_id: str = "", team_id: str = "", 
                 project_dir: str = "", publish_dir: str = "", 
                 build_command: str = "", api_token: str = "",
                 custom_domain: str = "", description: str = "",
                 last_deployed: str = "", status: str = ""):
        self.name = name
        self.site_id = site_id
        self.team_id = team_id
        self.project_dir = project_dir
        self.publish_dir = publish_dir
        self.build_command = build_command
        self.api_token = api_token
        self.custom_domain = custom_domain
        self.description = description
        self.last_deployed = last_deployed
        self.status = status
        self.deployment_history = []
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert site to dictionary for serialization"""
        return {
            "name": self.name,
            "site_id": self.site_id,
            "team_id": self.team_id,
            "project_dir": self.project_dir,
            "publish_dir": self.publish_dir,
            "build_command": self.build_command,
            "api_token": self.api_token,
            "custom_domain": self.custom_domain,
            "description": self.description,
            "last_deployed": self.last_deployed,
            "status": self.status,
            "deployment_history": self.deployment_history
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Site':
        """Create site from dictionary"""
        site = cls(
            name=data.get("name", ""),
            site_id=data.get("site_id", ""),
            team_id=data.get("team_id", ""),
            project_dir=data.get("project_dir", ""),
            publish_dir=data.get("publish_dir", ""),
            build_command=data.get("build_command", ""),
            api_token=data.get("api_token", ""),
            custom_domain=data.get("custom_domain", ""),
            description=data.get("description", ""),
            last_deployed=data.get("last_deployed", ""),
            status=data.get("status", "")
        )
        site.deployment_history = data.get("deployment_history", [])
        return site


class SiteManager:
    """Manager for multiple Netlify sites"""
    
    def __init__(self):
        self.sites: Dict[str, Site] = {}
        self.load_sites()
    
    def load_sites(self) -> None:
        """Load sites from configuration file"""
        os.makedirs(os.path.dirname(SITES_CONFIG_FILE), exist_ok=True)
        
        if not os.path.exists(SITES_CONFIG_FILE):
            self.sites = {}
            self.save_sites()
            return
        
        try:
            with open(SITES_CONFIG_FILE, 'r') as f:
                sites_data = json.load(f)
                
            self.sites = {
                name: Site.from_dict(site_data) 
                for name, site_data in sites_data.items()
            }
        except (json.JSONDecodeError, IOError) as e:
            print(f"Error loading sites: {e}")
            self.sites = {}
    
    def save_sites(self) -> None:
        """Save sites to configuration file"""
        try:
            sites_data = {
                name: site.to_dict() 
                for name, site in self.sites.items()
            }
            
            os.makedirs(os.path.dirname(SITES_CONFIG_FILE), exist_ok=True)
            
            with open(SITES_CONFIG_FILE, 'w') as f:
                json.dump(sites_data, f, indent=4)
        except IOError as e:
            print(f"Error saving sites: {e}")
    
    def add_site(self, site: Site) -> None:
        """Add a new site to the manager"""
        self.sites[site.name] = site
        self.save_sites()
    
    def update_site(self, site: Site) -> None:
        """Update an existing site"""
        self.sites[site.name] = site
        self.save_sites()
    
    def delete_site(self, site_name: str) -> bool:
        """Delete a site from the manager"""
        if site_name in self.sites:
            del self.sites[site_name]
            self.save_sites()
            return True
        return False
    
    def get_site(self, site_name: str) -> Optional[Site]:
        """Get a site by name"""
        return self.sites.get(site_name)
    
    def get_all_sites(self) -> List[Site]:
        """Get all sites"""
        return list(self.sites.values())


class SiteDialog(QDialog):
    """Dialog for adding or editing a site"""
    
    def __init__(self, parent=None, site: Optional[Site] = None):
        super().__init__(parent)
        self.site = site
        self.setWindowTitle("Site Configuration")
        self.resize(600, 500)
        self.setup_ui()
        
        if site:
            self.populate_fields()
    
    def setup_ui(self):
        """Set up the dialog UI"""
        layout = QVBoxLayout()
        self.setLayout(layout)
        
        # Create form layout for site details
        form_layout = QFormLayout()
        
        # Site name
        self.name_edit = QLineEdit()
        form_layout.addRow("Site Name:", self.name_edit)
        
        # Site ID
        self.site_id_edit = QLineEdit()
        form_layout.addRow("Site ID:", self.site_id_edit)
        
        # Team ID
        self.team_id_edit = QLineEdit()
        form_layout.addRow("Team ID:", self.team_id_edit)
        
        # Project directory
        project_layout = QHBoxLayout()
        self.project_dir_edit = QLineEdit()
        self.project_dir_button = QPushButton("Browse...")
        self.project_dir_button.clicked.connect(self.browse_project_dir)
        project_layout.addWidget(self.project_dir_edit)
        project_layout.addWidget(self.project_dir_button)
        form_layout.addRow("Project Directory:", project_layout)
        
        # Publish directory
        self.publish_dir_edit = QLineEdit()
        form_layout.addRow("Publish Directory:", self.publish_dir_edit)
        
        # Build command
        self.build_command_edit = QLineEdit()
        form_layout.addRow("Build Command:", self.build_command_edit)
        
        # API token
        self.api_token_edit = QLineEdit()
        self.api_token_edit.setEchoMode(QLineEdit.EchoMode.Password)
        form_layout.addRow("API Token:", self.api_token_edit)
        
        # Custom domain
        self.custom_domain_edit = QLineEdit()
        form_layout.addRow("Custom Domain:", self.custom_domain_edit)
        
        # Description
        self.description_edit = QTextEdit()
        self.description_edit.setMaximumHeight(100)
        form_layout.addRow("Description:", self.description_edit)
        
        # Add form to layout
        layout.addLayout(form_layout)
        
        # Buttons
        button_layout = QHBoxLayout()
        self.save_button = QPushButton("Save")
        self.save_button.clicked.connect(self.save_site)
        self.cancel_button = QPushButton("Cancel")
        self.cancel_button.clicked.connect(self.reject)
        
        button_layout.addStretch()
        button_layout.addWidget(self.save_button)
        button_layout.addWidget(self.cancel_button)
        
        layout.addLayout(button_layout)
    
    def browse_project_dir(self):
        """Open file dialog to select project directory"""
        directory = QFileDialog.getExistingDirectory(
            self, "Select Project Directory", self.project_dir_edit.text()
        )
        if directory:
            self.project_dir_edit.setText(directory)
    
    def populate_fields(self):
        """Populate fields with site data"""
        if not self.site:
            return
        
        self.name_edit.setText(self.site.name)
        self.site_id_edit.setText(self.site.site_id)
        self.team_id_edit.setText(self.site.team_id)
        self.project_dir_edit.setText(self.site.project_dir)
        self.publish_dir_edit.setText(self.site.publish_dir)
        self.build_command_edit.setText(self.site.build_command)
        self.api_token_edit.setText(self.site.api_token)
        self.custom_domain_edit.setText(self.site.custom_domain)
        self.description_edit.setText(self.site.description)
    
    def save_site(self):
        """Save the site data"""
        name = self.name_edit.text().strip()
        if not name:
            QMessageBox.warning(self, "Validation Error", "Site name is required")
            return
        
        # Create or update site
        if not self.site:
            self.site = Site()
        
        self.site.name = name
        self.site.site_id = self.site_id_edit.text().strip()
        self.site.team_id = self.team_id_edit.text().strip()
        self.site.project_dir = self.project_dir_edit.text().strip()
        self.site.publish_dir = self.publish_dir_edit.text().strip()
        self.site.build_command = self.build_command_edit.text().strip()
        self.site.api_token = self.api_token_edit.text().strip()
        self.site.custom_domain = self.custom_domain_edit.text().strip()
        self.site.description = self.description_edit.toPlainText().strip()
        
        self.accept()


class MultisiteManagerDialog(QDialog):
    """Dialog for managing multiple Netlify sites"""
    
    site_selected = pyqtSignal(Site)
    
    def __init__(self, parent=None, main_window=None):
        super().__init__(parent)
        self.main_window = main_window
        self.site_manager = SiteManager()
        
        # Get API token from main window if available
        self.api_token = ""
        if main_window and hasattr(main_window, 'persistent_token'):
            self.api_token = main_window.persistent_token
        
        self.setWindowTitle("Multi-Site Manager")
        self.resize(900, 600)
        self.setup_ui()
        self.load_sites()
    
    def setup_ui(self):
        """Set up the dialog UI"""
        layout = QVBoxLayout()
        self.setLayout(layout)
        
        # Create splitter for sites list and details
        splitter = QSplitter(Qt.Orientation.Horizontal)
        layout.addWidget(splitter)
        
        # Sites list
        sites_widget = QWidget()
        sites_layout = QVBoxLayout()
        sites_widget.setLayout(sites_layout)
        
        sites_label = QLabel("Managed Sites")
        sites_label.setStyleSheet("font-weight: bold; font-size: 14px;")
        sites_layout.addWidget(sites_label)
        
        # Add fetch sites button
        fetch_layout = QHBoxLayout()
        self.fetch_sites_button = QPushButton("Fetch Sites from Netlify")
        self.fetch_sites_button.clicked.connect(self.fetch_sites_from_netlify)
        fetch_layout.addWidget(self.fetch_sites_button)
        fetch_layout.addStretch()
        sites_layout.addLayout(fetch_layout)
        
        self.sites_list = QListWidget()
        self.sites_list.setMinimumWidth(200)
        self.sites_list.currentItemChanged.connect(self.site_selected_handler)
        sites_layout.addWidget(self.sites_list)
        
        # Buttons for sites list
        sites_buttons = QHBoxLayout()
        self.add_site_button = QPushButton("Add Site")
        self.add_site_button.clicked.connect(self.add_site)
        self.edit_site_button = QPushButton("Edit Site")
        self.edit_site_button.clicked.connect(self.edit_site)
        self.edit_site_button.setEnabled(False)
        self.delete_site_button = QPushButton("Delete Site")
        self.delete_site_button.clicked.connect(self.delete_site)
        self.delete_site_button.setEnabled(False)
        
        sites_buttons.addWidget(self.add_site_button)
        sites_buttons.addWidget(self.edit_site_button)
        sites_buttons.addWidget(self.delete_site_button)
        sites_layout.addLayout(sites_buttons)
        
        splitter.addWidget(sites_widget)
        
        # Site details
        details_widget = QWidget()
        details_layout = QVBoxLayout()
        details_widget.setLayout(details_layout)
        
        self.details_label = QLabel("Site Details")
        self.details_label.setStyleSheet("font-weight: bold; font-size: 14px;")
        details_layout.addWidget(self.details_label)
        
        # Tabs for different aspects of site
        self.tabs = QTabWidget()
        details_layout.addWidget(self.tabs)
        
        # Details tab
        self.details_tab = QWidget()
        details_tab_layout = QFormLayout()
        self.details_tab.setLayout(details_tab_layout)
        
        self.site_name_label = QLabel()
        details_tab_layout.addRow("Site Name:", self.site_name_label)
        
        self.site_id_label = QLabel()
        details_tab_layout.addRow("Site ID:", self.site_id_label)
        
        self.team_id_label = QLabel()
        details_tab_layout.addRow("Team ID:", self.team_id_label)
        
        self.project_dir_label = QLabel()
        details_tab_layout.addRow("Project Directory:", self.project_dir_label)
        
        self.publish_dir_label = QLabel()
        details_tab_layout.addRow("Publish Directory:", self.publish_dir_label)
        
        self.build_command_label = QLabel()
        details_tab_layout.addRow("Build Command:", self.build_command_label)
        
        self.custom_domain_label = QLabel()
        details_tab_layout.addRow("Custom Domain:", self.custom_domain_label)
        
        self.description_label = QLabel()
        self.description_label.setWordWrap(True)
        details_tab_layout.addRow("Description:", self.description_label)
        
        self.last_deployed_label = QLabel()
        details_tab_layout.addRow("Last Deployed:", self.last_deployed_label)
        
        self.status_label = QLabel()
        details_tab_layout.addRow("Status:", self.status_label)
        
        self.tabs.addTab(self.details_tab, "Details")
        
        # Deployment tab
        self.deployment_tab = QWidget()
        deployment_layout = QVBoxLayout()
        self.deployment_tab.setLayout(deployment_layout)
        
        # Deployment buttons
        deploy_buttons = QHBoxLayout()
        
        self.deploy_button = QPushButton("Deploy Site")
        self.deploy_button.clicked.connect(self.deploy_site)
        self.deploy_button.setEnabled(False)
        
        self.build_button = QPushButton("Build Site")
        self.build_button.clicked.connect(self.build_site)
        self.build_button.setEnabled(False)
        
        self.refresh_deploys_button = QPushButton("Refresh Deploys")
        self.refresh_deploys_button.clicked.connect(self.fetch_site_deploys)
        self.refresh_deploys_button.setEnabled(False)
        
        deploy_buttons.addWidget(self.build_button)
        deploy_buttons.addWidget(self.deploy_button)
        deploy_buttons.addWidget(self.refresh_deploys_button)
        deploy_buttons.addStretch()
        
        deployment_layout.addLayout(deploy_buttons)
        
        # Deployment history
        history_label = QLabel("Deployment History")
        history_label.setStyleSheet("font-weight: bold;")
        deployment_layout.addWidget(history_label)
        
        self.history_table = QTableWidget(0, 4)
        self.history_table.setHorizontalHeaderLabels(["Date", "Status", "Duration", "URL"])
        self.history_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        deployment_layout.addWidget(self.history_table)
        
        self.tabs.addTab(self.deployment_tab, "Deployment")
        
        # Analytics tab
        self.analytics_tab = QWidget()
        analytics_layout = QVBoxLayout()
        self.analytics_tab.setLayout(analytics_layout)
        
        # Analytics buttons
        analytics_buttons = QHBoxLayout()
        
        self.refresh_analytics_button = QPushButton("View Analytics")
        self.refresh_analytics_button.clicked.connect(self.view_site_analytics)
        self.refresh_analytics_button.setEnabled(False)
        
        analytics_buttons.addWidget(self.refresh_analytics_button)
        analytics_buttons.addStretch()
        
        analytics_layout.addLayout(analytics_buttons)
        
        # Analytics info
        analytics_info = QLabel("Click 'View Analytics' to open the analytics dashboard for this site.")
        analytics_layout.addWidget(analytics_info)
        
        self.tabs.addTab(self.analytics_tab, "Analytics")
        
        splitter.addWidget(details_widget)
        
        # Set initial splitter sizes
        splitter.setSizes([300, 600])
        
        # Bottom buttons
        button_layout = QHBoxLayout()
        self.load_button = QPushButton("Load Selected Site")
        self.load_button.clicked.connect(self.load_selected_site)
        self.load_button.setEnabled(False)
        
        self.close_button = QPushButton("Close")
        self.close_button.clicked.connect(self.accept)
        
        button_layout.addWidget(self.load_button)
        button_layout.addStretch()
        button_layout.addWidget(self.close_button)
        
        layout.addLayout(button_layout)
        
        # Progress bar
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        layout.addWidget(self.progress_bar)
    
    def fetch_sites_from_netlify(self):
        """Fetch sites from Netlify API"""
        if not self.api_token:
            # Try to get token from main window
            if self.main_window and hasattr(self.main_window, 'persistent_token'):
                self.api_token = self.main_window.persistent_token
            
            if not self.api_token:
                QMessageBox.warning(
                    self,
                    "API Token Required",
                    "Please set your Netlify API token in Settings to fetch sites from Netlify."
                )
                return
        
        # Show progress bar
        self.progress_bar.setVisible(True)
        self.progress_bar.setValue(0)
        self.progress_bar.setRange(0, 0)  # Indeterminate progress
        
        # Disable UI during fetch
        self.setEnabled(False)
        QApplication.processEvents()
        
        # Create and start worker thread
        self.fetch_worker = FetchSitesWorker(self.api_token)
        self.fetch_worker.sites_fetched.connect(self.handle_sites_fetched)
        self.fetch_worker.error.connect(self.handle_fetch_error)
        self.fetch_worker.start()
    
    def handle_sites_fetched(self, sites):
        """Handle fetched sites from Netlify API"""
        # Re-enable UI
        self.setEnabled(True)
        self.progress_bar.setVisible(False)
        
        if not sites:
            QMessageBox.information(
                self,
                "No Sites Found",
                "No sites were found in your Netlify account."
            )
            return
        
        # Ask user if they want to import all sites or select specific ones
        import_dialog = QDialog(self)
        import_dialog.setWindowTitle("Import Sites")
        import_dialog.resize(500, 400)
        
        layout = QVBoxLayout()
        import_dialog.setLayout(layout)
        
        # Instructions
        instructions = QLabel("Select the sites you want to import from Netlify:")
        layout.addWidget(instructions)
        
        # Sites list with checkboxes
        sites_list = QTableWidget(len(sites), 4)
        sites_list.setHorizontalHeaderLabels(["Import", "Name", "URL", "Last Updated"])
        sites_list.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        sites_list.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        
        for i, site in enumerate(sites):
            # Import checkbox
            checkbox = QCheckBox()
            checkbox.setChecked(True)  # Default to checked
            checkbox_widget = QWidget()
            checkbox_layout = QHBoxLayout(checkbox_widget)
            checkbox_layout.addWidget(checkbox)
            checkbox_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
            checkbox_layout.setContentsMargins(0, 0, 0, 0)
            sites_list.setCellWidget(i, 0, checkbox_widget)
            
            # Name
            name_item = QTableWidgetItem(site.get("name", ""))
            sites_list.setItem(i, 1, name_item)
            
            # URL
            url = site.get("url", "")
            url_item = QTableWidgetItem(url)
            sites_list.setItem(i, 2, url_item)
            
            # Last updated
            updated_at = site.get("updated_at", "")
            if updated_at:
                try:
                    # Format the date
                    date_obj = datetime.fromisoformat(updated_at.replace("Z", "+00:00"))
                    formatted_date = date_obj.strftime("%Y-%m-%d %H:%M")
                    updated_item = QTableWidgetItem(formatted_date)
                except:
                    updated_item = QTableWidgetItem(updated_at)
            else:
                updated_item = QTableWidgetItem("")
            sites_list.setItem(i, 3, updated_item)
        
        layout.addWidget(sites_list)
        
        # Buttons
        button_layout = QHBoxLayout()
        select_all_button = QPushButton("Select All")
        select_all_button.clicked.connect(lambda: self.toggle_all_checkboxes(sites_list, True))
        
        select_none_button = QPushButton("Select None")
        select_none_button.clicked.connect(lambda: self.toggle_all_checkboxes(sites_list, False))
        
        import_button = QPushButton("Import Selected")
        import_button.clicked.connect(import_dialog.accept)
        
        cancel_button = QPushButton("Cancel")
        cancel_button.clicked.connect(import_dialog.reject)
        
        button_layout.addWidget(select_all_button)
        button_layout.addWidget(select_none_button)
        button_layout.addStretch()
        button_layout.addWidget(import_button)
        button_layout.addWidget(cancel_button)
        
        layout.addLayout(button_layout)
        
        # Show dialog
        if import_dialog.exec() == QDialog.DialogCode.Accepted:
            # Import selected sites
            imported_count = 0
            for i, site in enumerate(sites):
                checkbox_widget = sites_list.cellWidget(i, 0)
                checkbox = checkbox_widget.findChild(QCheckBox)
                
                if checkbox and checkbox.isChecked():
                    # Create a new Site object
                    new_site = Site(
                        name=site.get("name", ""),
                        site_id=site.get("id", ""),
                        team_id=site.get("account_slug", ""),
                        custom_domain=site.get("custom_domain", ""),
                        description=site.get("description", ""),
                        last_deployed=site.get("published_deploy", {}).get("published_at", ""),
                        status=site.get("published_deploy", {}).get("state", "")
                    )
                    
                    # Add default build settings
                    build_settings = site.get("build_settings", {})
                    if build_settings:
                        new_site.publish_dir = build_settings.get("dir", "")
                        new_site.build_command = build_settings.get("cmd", "")
                    
                    # Set API token
                    new_site.api_token = self.api_token
                    
                    # Add site to manager
                    self.site_manager.add_site(new_site)
                    imported_count += 1
            
            # Reload sites list
            self.load_sites()
            
            QMessageBox.information(
                self,
                "Sites Imported",
                f"Successfully imported {imported_count} sites from Netlify."
            )
    
    def toggle_all_checkboxes(self, table_widget, checked):
        """Toggle all checkboxes in a table widget"""
        for i in range(table_widget.rowCount()):
            checkbox_widget = table_widget.cellWidget(i, 0)
            checkbox = checkbox_widget.findChild(QCheckBox)
            if checkbox:
                checkbox.setChecked(checked)
    
    def handle_fetch_error(self, error_message):
        """Handle error when fetching data"""
        self.setEnabled(True)
        self.progress_bar.setVisible(False)
        
        QMessageBox.critical(
            self,
            "Error Fetching Data",
            f"Failed to fetch data from Netlify: {error_message}"
        )
    
    def fetch_site_deploys(self):
        """Fetch deployment history for the selected site"""
        current_item = self.sites_list.currentItem()
        if not current_item:
            return
        
        site_name = current_item.data(Qt.ItemDataRole.UserRole)
        site = self.site_manager.get_site(site_name)
        
        if not site or not site.site_id:
            QMessageBox.warning(
                self,
                "Site ID Required",
                "This site doesn't have a site ID. Please edit the site and add a site ID."
            )
            return
        
        # Get API token
        token = site.api_token or self.api_token
        if not token:
            QMessageBox.warning(
                self,
                "API Token Required",
                "Please set your Netlify API token in Settings to fetch deployment history."
            )
            return
        
        # Show progress bar
        self.progress_bar.setVisible(True)
        self.progress_bar.setValue(0)
        self.progress_bar.setRange(0, 0)  # Indeterminate progress
        
        # Disable UI during fetch
        self.setEnabled(False)
        QApplication.processEvents()
        
        # Create and start worker thread
        self.deploys_worker = FetchSiteDeploysWorker(token, site.site_id)
        self.deploys_worker.deploys_fetched.connect(lambda deploys: self.handle_deploys_fetched(deploys, site))
        self.deploys_worker.error.connect(self.handle_fetch_error)
        self.deploys_worker.start()
    
    def handle_deploys_fetched(self, deploys, site):
        """Handle fetched deployment history"""
        # Re-enable UI
        self.setEnabled(True)
        self.progress_bar.setVisible(False)
        
        if not deploys:
            QMessageBox.information(
                self,
                "No Deployments Found",
                "No deployment history was found for this site."
            )
            return
        
        # Update site's deployment history
        site.deployment_history = []
        
        for deploy in deploys:
            # Create deployment entry
            deployment = {
                "timestamp": deploy.get("created_at", ""),
                "status": deploy.get("state", ""),
                "duration": self.format_duration(deploy.get("deploy_time", 0)),
                "url": deploy.get("deploy_url", "")
            }
            
            site.deployment_history.append(deployment)
        
        # Update site's last deployed and status
        if deploys:
            latest = deploys[0]  # Assumes deploys are sorted by date
            site.last_deployed = latest.get("created_at", "")
            site.status = latest.get("state", "")
        
        # Save site changes
        self.site_manager.update_site(site)
        
        # Update display
        self.display_site_details(site)
        
        QMessageBox.information(
            self,
            "Deployments Fetched",
            f"Successfully fetched {len(deploys)} deployments from Netlify."
        )
    
    def format_duration(self, seconds):
        """Format duration in seconds to a readable string"""
        if not seconds:
            return "N/A"
        
        minutes, seconds = divmod(int(seconds), 60)
        return f"{minutes}m {seconds}s"
    
    def view_site_analytics(self):
        """View analytics for the selected site"""
        current_item = self.sites_list.currentItem()
        if not current_item:
            return
        
        site_name = current_item.data(Qt.ItemDataRole.UserRole)
        site = self.site_manager.get_site(site_name)
        
        if not site or not site.site_id:
            QMessageBox.warning(
                self,
                "Site ID Required",
                "This site doesn't have a site ID. Please edit the site and add a site ID."
            )
            return
        
        # Get API token
        token = site.api_token or self.api_token
        if not token:
            QMessageBox.warning(
                self,
                "API Token Required",
                "Please set your Netlify API token in Settings to view analytics."
            )
            return
        
        # Show analytics dashboard
        try:
            from analytics_dashboard import AnalyticsDashboard
            
            # Update main window token if needed
            if self.main_window and hasattr(self.main_window, 'persistent_token'):
                self.main_window.persistent_token = token
            
            analytics = AnalyticsDashboard(self.main_window)
            analytics.api_token = token
            analytics.show_dashboard(site.site_id, site.name)
        except Exception as e:
            QMessageBox.critical(
                self,
                "Error",
                f"Failed to open Analytics Dashboard: {str(e)}"
            )
    
    def load_sites(self):
        """Load sites into the list widget"""
        self.sites_list.clear()
        
        for site in self.site_manager.get_all_sites():
            item = QListWidgetItem(site.name)
            item.setData(Qt.ItemDataRole.UserRole, site.name)
            self.sites_list.addItem(item)
    
    def site_selected_handler(self, current, previous):
        """Handle site selection"""
        if current is None:
            self.clear_details()
            self.edit_site_button.setEnabled(False)
            self.delete_site_button.setEnabled(False)
            self.deploy_button.setEnabled(False)
            self.build_button.setEnabled(False)
            self.refresh_deploys_button.setEnabled(False)
            self.refresh_analytics_button.setEnabled(False)
            self.load_button.setEnabled(False)
            return
        
        site_name = current.data(Qt.ItemDataRole.UserRole)
        site = self.site_manager.get_site(site_name)
        
        if site:
            self.display_site_details(site)
            self.edit_site_button.setEnabled(True)
            self.delete_site_button.setEnabled(True)
            self.deploy_button.setEnabled(True)
            self.build_button.setEnabled(True)
            self.load_button.setEnabled(True)
            
            # Enable refresh buttons if site has an ID and we have an API token
            has_api_access = bool(site.site_id and (site.api_token or self.api_token))
            self.refresh_deploys_button.setEnabled(has_api_access)
            self.refresh_analytics_button.setEnabled(has_api_access)
    
    def clear_details(self):
        """Clear site details display"""
        self.site_name_label.setText("")
        self.site_id_label.setText("")
        self.team_id_label.setText("")
        self.project_dir_label.setText("")
        self.publish_dir_label.setText("")
        self.build_command_label.setText("")
        self.custom_domain_label.setText("")
        self.description_label.setText("")
        self.last_deployed_label.setText("")
        self.status_label.setText("")
        self.history_table.setRowCount(0)
    
    def display_site_details(self, site: Site):
        """Display site details"""
        self.site_name_label.setText(site.name)
        self.site_id_label.setText(site.site_id)
        self.team_id_label.setText(site.team_id)
        self.project_dir_label.setText(site.project_dir)
        self.publish_dir_label.setText(site.publish_dir)
        self.build_command_label.setText(site.build_command)
        self.custom_domain_label.setText(site.custom_domain)
        self.description_label.setText(site.description)
        self.last_deployed_label.setText(site.last_deployed or "Never")
        self.status_label.setText(site.status or "Unknown")
        
        # Display deployment history
        self.history_table.setRowCount(0)
        
        for i, deployment in enumerate(reversed(site.deployment_history)):
            self.history_table.insertRow(i)
            
            # Date
            date_item = QTableWidgetItem(deployment.get("timestamp", ""))
            self.history_table.setItem(i, 0, date_item)
            
            # Status
            status_item = QTableWidgetItem(deployment.get("status", ""))
            self.history_table.setItem(i, 1, status_item)
            
            # Duration
            duration_item = QTableWidgetItem(deployment.get("duration", ""))
            self.history_table.setItem(i, 2, duration_item)
            
            # URL
            url_item = QTableWidgetItem(deployment.get("url", ""))
            self.history_table.setItem(i, 3, url_item)
    
    def add_site(self):
        """Add a new site"""
        dialog = SiteDialog(self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.site_manager.add_site(dialog.site)
            self.load_sites()
    
    def edit_site(self):
        """Edit the selected site"""
        current_item = self.sites_list.currentItem()
        if not current_item:
            return
        
        site_name = current_item.data(Qt.ItemDataRole.UserRole)
        site = self.site_manager.get_site(site_name)
        
        if site:
            dialog = SiteDialog(self, site)
            if dialog.exec() == QDialog.DialogCode.Accepted:
                # If the name changed, we need to delete the old one
                if site_name != dialog.site.name:
                    self.site_manager.delete_site(site_name)
                
                self.site_manager.update_site(dialog.site)
                self.load_sites()
                
                # Find and select the edited site
                for i in range(self.sites_list.count()):
                    item = self.sites_list.item(i)
                    if item.data(Qt.ItemDataRole.UserRole) == dialog.site.name:
                        self.sites_list.setCurrentItem(item)
                        break
    
    def delete_site(self):
        """Delete the selected site"""
        current_item = self.sites_list.currentItem()
        if not current_item:
            return
        
        site_name = current_item.data(Qt.ItemDataRole.UserRole)
        site = self.site_manager.get_site(site_name)
        
        if not site:
            return
        
        # Check if site has a site_id and API token
        delete_from_netlify = False
        can_delete_from_netlify = bool(site.site_id and (site.api_token or self.api_token))
        
        if can_delete_from_netlify:
            # Ask if user wants to delete from Netlify as well
            message_box = QMessageBox(self)
            message_box.setWindowTitle("Confirm Deletion")
            message_box.setText(f"Are you sure you want to delete the site '{site_name}'?")
            
            # Provide detailed information about the consequences
            info_text = (
                "Please choose one of the following options:\n\n"
                "• Delete Locally Only: The site will be removed from this app but will remain on Netlify.\n"
                "• Delete from Netlify Too: The site will be permanently deleted from both this app and Netlify.\n\n"
                "Warning: Deleting from Netlify is permanent and cannot be undone."
            )
            message_box.setInformativeText(info_text)
            message_box.setIcon(QMessageBox.Icon.Warning)
            
            # Add buttons
            delete_local_button = message_box.addButton("Delete Locally Only", QMessageBox.ButtonRole.AcceptRole)
            delete_both_button = message_box.addButton("Delete from Netlify Too", QMessageBox.ButtonRole.ActionRole)
            cancel_button = message_box.addButton(QMessageBox.StandardButton.Cancel)
            
            message_box.setDefaultButton(delete_local_button)
            
            # Show dialog
            message_box.exec()
            
            clicked_button = message_box.clickedButton()
            
            if clicked_button == cancel_button:
                return
            elif clicked_button == delete_both_button:
                delete_from_netlify = True
        else:
            # Standard confirmation dialog for local deletion only
            reply = QMessageBox.question(
                self, "Confirm Deletion", 
                f"Are you sure you want to delete the site '{site_name}'?\n\n"
                "The site will be removed from this app only.",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No
            )
            
            if reply != QMessageBox.StandardButton.Yes:
                return
        
        # If user chose to delete from Netlify
        if delete_from_netlify:
            # Get API token
            token = site.api_token or self.api_token
            
            # Show progress bar
            self.progress_bar.setVisible(True)
            self.progress_bar.setValue(0)
            self.progress_bar.setRange(0, 0)  # Indeterminate progress
            
            # Disable UI during deletion
            self.setEnabled(False)
            QApplication.processEvents()
            
            # Create and start worker thread
            self.delete_worker = DeleteSiteWorker(token, site.site_id)
            self.delete_worker.deletion_complete.connect(lambda success: self.handle_netlify_deletion(success, site_name))
            self.delete_worker.error.connect(lambda error: self.handle_netlify_deletion_error(error, site_name))
            self.delete_worker.start()
        else:
            # Just delete locally
            self.site_manager.delete_site(site_name)
            self.load_sites()
            self.clear_details()
            
            # Show confirmation
            QMessageBox.information(
                self,
                "Site Deleted",
                f"The site '{site_name}' has been deleted from local storage only.\n\n"
                "It still exists on Netlify."
            )
    
    def handle_netlify_deletion(self, success: bool, site_name: str):
        """Handle completion of Netlify site deletion"""
        # Re-enable UI
        self.setEnabled(True)
        self.progress_bar.setVisible(False)
        
        if success:
            # Delete from local storage
            self.site_manager.delete_site(site_name)
            self.load_sites()
            self.clear_details()
            
            QMessageBox.information(
                self,
                "Site Deleted",
                f"The site '{site_name}' has been deleted from both Netlify and local storage."
            )
        else:
            QMessageBox.warning(
                self,
                "Deletion Incomplete",
                f"The site was not deleted from Netlify, but it will be removed from local storage."
            )
            
            # Delete from local storage anyway
            self.site_manager.delete_site(site_name)
            self.load_sites()
            self.clear_details()
    
    def handle_netlify_deletion_error(self, error_message: str, site_name: str):
        """Handle error during Netlify site deletion"""
        # Re-enable UI
        self.setEnabled(True)
        self.progress_bar.setVisible(False)
        
        # Ask if user wants to delete locally anyway
        message_box = QMessageBox(self)
        message_box.setWindowTitle("Netlify Deletion Failed")
        message_box.setText(f"Failed to delete site from Netlify: {error_message}")
        message_box.setInformativeText("Do you still want to delete this site from local storage?")
        message_box.setIcon(QMessageBox.Icon.Warning)
        message_box.setStandardButtons(QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        message_box.setDefaultButton(QMessageBox.StandardButton.No)
        
        if message_box.exec() == QMessageBox.StandardButton.Yes:
            # Delete from local storage
            self.site_manager.delete_site(site_name)
            self.load_sites()
            self.clear_details()
    
    def deploy_site(self):
        """Deploy the selected site"""
        current_item = self.sites_list.currentItem()
        if not current_item:
            return
        
        site_name = current_item.data(Qt.ItemDataRole.UserRole)
        site = self.site_manager.get_site(site_name)
        
        if site and self.main_window:
            # Update main window fields
            self.main_window.site_name.setText(site.name)
            self.main_window.project_dir.setText(site.project_dir)
            self.main_window.publish_dir.setText(site.publish_dir)
            
            # Update persistent token if needed
            if site.api_token:
                self.main_window.persistent_token = site.api_token
                self.main_window.save_persistent_settings()
            
            # Update team name if needed
            if site.team_id:
                self.main_window.persistent_team = site.team_id
                self.main_window.save_persistent_settings()
            
            # Start deployment
            self.main_window.start_deployment()
            
            # Record deployment in site history
            now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            site.last_deployed = now
            site.status = "Deploying"
            
            deployment = {
                "timestamp": now,
                "status": "In Progress",
                "duration": "N/A",
                "url": ""
            }
            
            site.deployment_history.append(deployment)
            self.site_manager.update_site(site)
            
            # Close dialog
            self.accept()
    
    def build_site(self):
        """Build the selected site"""
        current_item = self.sites_list.currentItem()
        if not current_item:
            return
        
        site_name = current_item.data(Qt.ItemDataRole.UserRole)
        site = self.site_manager.get_site(site_name)
        
        if site and self.main_window:
            # Update main window fields
            self.main_window.project_dir.setText(site.project_dir)
            self.main_window.publish_dir.setText(site.publish_dir)
            
            # Run build command if specified
            if site.build_command:
                # Set up build command
                self.main_window.run_build_command(
                    site.build_command,
                    f"Building site: {site.name}"
                )
            else:
                # Use default build process
                self.main_window.build_project()
    
    def load_selected_site(self):
        """Load the selected site into the main window without deploying"""
        current_item = self.sites_list.currentItem()
        if not current_item:
            return
        
        site_name = current_item.data(Qt.ItemDataRole.UserRole)
        site = self.site_manager.get_site(site_name)
        
        if site and self.main_window:
            # Update main window fields
            self.main_window.site_name.setText(site.name)
            self.main_window.project_dir.setText(site.project_dir)
            self.main_window.publish_dir.setText(site.publish_dir)
            
            # Update persistent token if needed
            if site.api_token:
                self.main_window.persistent_token = site.api_token
                self.main_window.save_persistent_settings()
            
            # Update team name if needed
            if site.team_id:
                self.main_window.persistent_team = site.team_id
                self.main_window.save_persistent_settings()
            
            # Close dialog
            self.accept()


class MultisiteManager:
    """Manager class for multi-site feature integration"""
    
    def __init__(self, main_window):
        self.main_window = main_window
        self.site_manager = SiteManager()
    
    def show_manager_dialog(self):
        """Show the multi-site manager dialog"""
        dialog = MultisiteManagerDialog(self.main_window, self.main_window)
        dialog.exec()
    
    def update_deployment_history(self, site_name, status, url="", error=None, extra_data=None):
        """Update deployment history for a site"""
        site = self.site_manager.get_site(site_name)
        
        if not site:
            return
        
        # Find the most recent deployment
        if site.deployment_history:
            latest = site.deployment_history[-1]
            
            # Calculate duration if this is completing a deployment
            if latest.get("status") == "In Progress" and status != "In Progress":
                start_time = datetime.strptime(latest.get("timestamp", ""), "%Y-%m-%d %H:%M:%S")
                end_time = datetime.now()
                duration = end_time - start_time
                minutes, seconds = divmod(duration.total_seconds(), 60)
                duration_str = f"{int(minutes)}m {int(seconds)}s"
                
                latest["duration"] = duration_str
            
            latest["status"] = status
            
            if url:
                latest["url"] = url
            
            if error:
                latest["error"] = error
                
            # Add extra data if provided (like deploy_id)
            if extra_data and isinstance(extra_data, dict):
                for key, value in extra_data.items():
                    if value:  # Only add non-empty values
                        latest[key] = value
                        
            # Try to extract deploy_id from URL if not present
            if "deploy_id" not in latest and url and "--" in url:
                try:
                    deploy_id = url.split("//")[1].split("--")[0]
                    latest["deploy_id"] = deploy_id
                except Exception:
                    pass
        
        # Update site status
        site.status = status
        
        # Save changes
        self.site_manager.update_site(site)
        
    def delete_site_from_netlify(self, site_name):
        """Delete a site from Netlify"""
        site = self.site_manager.get_site(site_name)
        
        if not site or not site.site_id:
            return False, "Site not found or missing site ID"
        
        # Get API token
        token = site.api_token
        if not token and hasattr(self.main_window, 'persistent_token'):
            token = self.main_window.persistent_token
            
        if not token:
            return False, "API token not available"
            
        try:
            client = NetlifyAPIClient(token)
            result = client.delete_site(site.site_id)
            
            if result:
                # Delete from local storage
                self.site_manager.delete_site(site_name)
                return True, "Site deleted successfully"
            else:
                return False, "Failed to delete site from Netlify"
        except Exception as e:
            logger.error(f"Error deleting site from Netlify: {str(e)}")
            return False, str(e)


def show_multisite_manager(main_window):
    """Show the Multi-Site Manager dialog"""
    dialog = MultisiteManagerDialog(main_window, main_window)
    dialog.exec()
