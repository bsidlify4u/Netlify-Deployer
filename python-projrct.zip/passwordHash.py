from argon2 import PasswordHasher
ph = PasswordHasher()
print(ph.hash("Physics@12345@"))  # Replace with your desired password