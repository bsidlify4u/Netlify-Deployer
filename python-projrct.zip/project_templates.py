"""
Project Templates Module for Netlify Deployer
Allows users to save, load, and manage deployment templates
"""

import os
import json
from datetime import datetime
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QListWidget, QListWidgetItem,
    QPushButton, QInputDialog, QLabel
)
from PyQt6.QtCore import Qt

class TemplateManager:
    def __init__(self, main_window):
        self.main_window = main_window
        self.templates = []
        self.template_file = os.path.join(
            os.path.dirname(os.path.abspath(__file__)), 
            'settings', 
            'templates.json'
        )
        self.load_templates()
    
    def load_templates(self):
        """Load saved templates from file"""
        os.makedirs(os.path.dirname(self.template_file), exist_ok=True)
        
        if os.path.exists(self.template_file):
            try:
                with open(self.template_file, 'r') as f:
                    self.templates = json.load(f)
            except json.JSONDecodeError:
                self.templates = []
        else:
            self.templates = []
    
    def save_templates(self):
        """Save templates to file"""
        os.makedirs(os.path.dirname(self.template_file), exist_ok=True)
        
        with open(self.template_file, 'w') as f:
            json.dump(self.templates, f, indent=4)
    
    def save_current_as_template(self):
        """Save current configuration as a template"""
        dialog = QInputDialog(self.main_window)
        dialog.setWindowTitle("Save as Template")
        dialog.setLabelText("Template Name:")
        dialog.setWindowIcon(self.main_window.windowIcon())
        dialog.resize(350, 100)
        dialog.setStyleSheet("""
            QInputDialog {
                background-color: #1e1e1e;
                color: #d4d4d4;
            }
            QInputDialog QLabel {
                color: #d4d4d4;
                font-size: 13px;
            }
            QInputDialog QLineEdit {
                background-color: #252525;
                color: #d4d4d4;
                border: 1px solid #3c3c3c;
                border-radius: 4px;
                padding: 5px;
                font-size: 13px;
            }
            QInputDialog QPushButton {
                background-color: #0e639c;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 6px 12px;
                font-size: 13px;
                margin: 5px;
            }
            QInputDialog QPushButton:hover {
                background-color: #1177bb;
            }
            QInputDialog QPushButton:pressed {
                background-color: #0d5989;
            }
        """)
        
        if dialog.exec() == QDialog.DialogCode.Accepted:
            template_name = dialog.textValue().strip()
            if template_name:
                # Create template data from current settings
                template = {
                    'name': template_name,
                    'project_dir': self.main_window.project_dir.text(),
                    'publish_dir': self.main_window.publish_dir.text(),
                    'site_name': self.main_window.site_name.text(),
                    'team_name': self.main_window.persistent_team,
                    'token': self.main_window.security.encrypt(self.main_window.persistent_token) if self.main_window.persistent_token else '',
                    'toml_content': getattr(self.main_window, 'toml_content', ''),
                    'build_type': getattr(self.main_window, 'current_build_type', 'npm'),
                    'created_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                }
                
                # Add to templates list
                self.templates.append(template)
                self.save_templates()
                
                self.main_window.log_text.append(f"<span style='color: #6A9955'>✓ Template '{template_name}' saved successfully.</span>")
                return True
        return False
    
    def load_template(self, index):
        """Apply selected template to current configuration"""
        if 0 <= index < len(self.templates):
            template = self.templates[index]
            
            # Apply template settings
            self.main_window.project_dir.setText(template['project_dir'])
            self.main_window.publish_dir.setText(template['publish_dir'])
            self.main_window.site_name.setText(template['site_name'])
            self.main_window.persistent_team = template.get('team_name', '')
            
            # Load token if it exists
            if template.get('token'):
                try:
                    self.main_window.persistent_token = self.main_window.security.decrypt(template['token'])
                except Exception:
                    self.main_window.persistent_token = ''
                    
            # Load TOML content if it exists
            if 'toml_content' in template:
                self.main_window.toml_content = template['toml_content']
                self.main_window.default_toml = template['toml_content']
            
            # Load build type if it exists
            if 'build_type' in template:
                self.main_window.current_build_type = template['build_type']
                
            if hasattr(self.main_window, 'save_persistent_settings'):
                self.main_window.save_persistent_settings()
            
            self.main_window.log_text.append(f"<span style='color: #6A9955'>✓ Template '{template['name']}' loaded successfully.</span>")
            return True
        return False
    
    def delete_template(self, index):
        """Delete a template by index"""
        if 0 <= index < len(self.templates):
            template_name = self.templates[index]['name']
            del self.templates[index]
            self.save_templates()
            self.main_window.log_text.append(f"<span style='color: #CE9178'>✓ Template '{template_name}' deleted.</span>")
            return True
        return False
    
    def show_management_dialog(self):
        """Show dialog for managing templates"""
        dialog = TemplateManagerDialog(self.main_window, self)
        dialog.exec()
        return True

class TemplateManagerDialog(QDialog):
    def __init__(self, parent, template_manager):
        super().__init__(parent)
        self.template_manager = template_manager
        self.templates = template_manager.templates
        
        self.setWindowTitle("Manage Templates")
        self.setWindowIcon(parent.windowIcon())
        self.setMinimumWidth(500)
        self.setMinimumHeight(400)
        self.setStyleSheet("""
            QDialog {
                background-color: #1e1e1e;
                color: #d4d4d4;
            }
        """)
        
        self.setup_ui()
    
    def setup_ui(self):
        layout = QVBoxLayout(self)
        
        # Header
        header = QLabel("Project Templates")
        header.setStyleSheet("font-size: 16px; font-weight: bold; margin-bottom: 10px;")
        layout.addWidget(header)
        
        # Template list
        self.list_widget = QListWidget()
        self.list_widget.setStyleSheet("""
            QListWidget {
                background-color: #252525;
                color: #d4d4d4;
                border: 1px solid #3c3c3c;
                border-radius: 4px;
                padding: 5px;
                font-size: 13px;
            }
            QListWidget::item {
                padding: 6px;
                border-bottom: 1px solid #333;
            }
            QListWidget::item:selected {
                background-color: #094771;
            }
        """)
        
        for template in self.templates:
            item = QListWidgetItem(f"{template['name']} ({template.get('created_at', 'Unknown date')})")
            item.setData(Qt.ItemDataRole.UserRole, self.templates.index(template))
            self.list_widget.addItem(item)
        
        layout.addWidget(self.list_widget)
        
        # Buttons layout
        btn_layout = QHBoxLayout()
        
        self.load_btn = QPushButton("Load")
        self.load_btn.setStyleSheet("""
            QPushButton {
                background-color: #0e639c;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 8px 16px;
                font-size: 13px;
            }
            QPushButton:hover {
                background-color: #1177bb;
            }
            QPushButton:pressed {
                background-color: #0d5989;
            }
            QPushButton:disabled {
                background-color: #666666;
                color: #aaaaaa;
            }
        """)
        
        self.delete_btn = QPushButton("Delete")
        self.delete_btn.setStyleSheet("""
            QPushButton {
                background-color: #c72c41;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 8px 16px;
                font-size: 13px;
            }
            QPushButton:hover {
                background-color: #d13651;
            }
            QPushButton:pressed {
                background-color: #b02739;
            }
            QPushButton:disabled {
                background-color: #666666;
                color: #aaaaaa;
            }
        """)
        
        self.cancel_btn = QPushButton("Close")
        self.cancel_btn.setStyleSheet("""
            QPushButton {
                background-color: #333333;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 8px 16px;
                font-size: 13px;
            }
            QPushButton:hover {
                background-color: #444444;
            }
            QPushButton:pressed {
                background-color: #2a2a2a;
            }
        """)
        
        btn_layout.addWidget(self.load_btn)
        btn_layout.addWidget(self.delete_btn)
        btn_layout.addStretch()
        btn_layout.addWidget(self.cancel_btn)
        
        layout.addLayout(btn_layout)
        
        # Connect signals
        self.load_btn.clicked.connect(self.load_selected_template)
        self.delete_btn.clicked.connect(self.delete_selected_template)
        self.cancel_btn.clicked.connect(self.reject)
        
        # Double click to load
        self.list_widget.itemDoubleClicked.connect(lambda item: self.load_template(item.data(Qt.ItemDataRole.UserRole)))
        self.list_widget.itemDoubleClicked.connect(self.accept)
        
        # Update button states
        self.update_button_states()
        self.list_widget.itemSelectionChanged.connect(self.update_button_states)
    
    def update_button_states(self):
        """Enable or disable buttons based on selection"""
        has_selection = self.list_widget.currentItem() is not None
        self.load_btn.setEnabled(has_selection)
        self.delete_btn.setEnabled(has_selection)
    
    def load_selected_template(self):
        """Load the selected template"""
        if self.list_widget.currentItem():
            index = self.list_widget.currentItem().data(Qt.ItemDataRole.UserRole)
            if self.template_manager.load_template(index):
                self.accept()
    
    def delete_selected_template(self):
        """Delete the selected template"""
        if self.list_widget.currentItem():
            index = self.list_widget.currentItem().data(Qt.ItemDataRole.UserRole)
            if self.template_manager.delete_template(index):
                self.list_widget.takeItem(self.list_widget.currentRow())
                self.update_button_states() 