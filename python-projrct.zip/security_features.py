"""
Enhanced security features for Netlify Deployer application.
Includes hardware key authentication, deployment protection, and code signing.
"""

import os
import uuid
import json
import hashlib
import hmac
import platform
import datetime
import random
import string
from typing import Optional, Dict, Any, Union, List

# Global security manager instance
security_manager = None

class HardwareAuth:
    """USB Security Key Authentication System"""
    
    def __init__(self):
        self._is_authenticated = False
        self._key_id = None
        self._drive_path = None
        self._last_error = None
        self._usb_serial = None
        self.KEY_FILENAME = ".netlify_hardware_key"
        self._initialized = False
        
        # Try to load the saved USB serial number from the key store file
        try:
            key_store_path = "usb_key_store.json"
            if os.path.exists(key_store_path):
                with open(key_store_path, 'r') as f:
                    key_data = json.load(f)
                    if "usb_serial" in key_data:
                        self._usb_serial = key_data["usb_serial"]
                        self._initialized = True
        except Exception:
            # Failed to load, will need to initialize
            pass
    
    def require_auth(self) -> bool:
        """Force hardware key authentication"""
        return self.is_authenticated(True)
    
    def is_initialized(self) -> bool:
        """Check if the hardware key has been initialized"""
        return self._initialized
    
    def is_authenticated(self, force_check: bool = False) -> bool:
        """Check if the hardware key is authenticated
        
        Args:
            force_check: If True, always check physical USB drives even if already authenticated
        """
        # Return cached result if not forced to recheck
        if self._is_authenticated and not force_check:
            return True
        
        # If key id is missing, we're definitely not authenticated
        if not self._key_id:
            # Try to load from key store before giving up
            try:
                self._load_key_store()
            except Exception as e:
                self._last_error = f"Error loading key store: {str(e)}"
                return False
        
        if not self._key_id:
            self._last_error = "No security key has been initialized"
            return False
        
        # Get the correct serial number
        CORRECT_SERIAL = ""
        
        # First try to load the serial from .env file
        try:
            from dotenv import load_dotenv
            load_dotenv()
            env_serial = os.getenv('USB_KEY_SERIAL')
            if env_serial:
                CORRECT_SERIAL = env_serial
                print(f"DEBUG: Using USB serial from .env: {CORRECT_SERIAL}")
        except Exception as e:
            print(f"DEBUG: Error loading from .env: {e}")
        
        # If no serial from env, try from key store
        if not CORRECT_SERIAL and hasattr(self, '_usb_serial') and self._usb_serial:
            CORRECT_SERIAL = self._usb_serial
            print(f"DEBUG: Using USB serial from key store: {CORRECT_SERIAL}")
        
        # Check if we have a valid serial number
        if not CORRECT_SERIAL:
            self._last_error = "No USB key serial number configured"
            return False
        
        # First, always try to check for a connected USB drive with the correct serial number
        # This uses the PowerShell command directly for the most reliable result
        try:
            import subprocess
            
            # Get the serial number using PowerShell for USB interface type drives
            ps_command = f'Get-WmiObject Win32_DiskDrive | Where-Object {{$_.InterfaceType -eq "USB"}} | Where-Object {{$_.SerialNumber -eq "{CORRECT_SERIAL}"}} | Select-Object SerialNumber'
            process = subprocess.run(
                ["powershell", "-Command", ps_command],
                capture_output=True, text=True
            )
            
            if process.returncode == 0:
                output = process.stdout.strip()
                
                # Check if our known correct serial is in the output
                if CORRECT_SERIAL in output:
                    print(f"DEBUG: Found matching known serial: {CORRECT_SERIAL}")
                    self._is_authenticated = True
                    self._was_authenticated_once = True
                    self._usb_serial = CORRECT_SERIAL
                    return True
        except Exception as e:
            print(f"DEBUG: Error in direct PowerShell check: {e}")
        
        # If we have a USB serial directly set (could be manual identifier)
        if hasattr(self, '_usb_serial') and self._usb_serial:
            # If this was a manual entry, don't try to match with physical drives
            key_store_path = "usb_key_store.json"
            if os.path.exists(key_store_path):
                try:
                    with open(key_store_path, 'r') as f:
                        key_data = json.load(f)
                        if key_data.get("manual_entry", False):
                            self._is_authenticated = True
                            print(f"DEBUG: Using manual entry authentication: {self._usb_serial}")
                            return True
                except Exception as e:
                    print(f"DEBUG: Error checking for manual entry: {e}")
                    # Continue with normal authentication methods
            
        # Try a broader PowerShell search for any USB drives
        try:
            ps_command = 'Get-WmiObject Win32_DiskDrive | Where-Object {$_.InterfaceType -eq "USB"} | Select-Object SerialNumber'
            process = subprocess.run(
                ["powershell", "-Command", ps_command],
                capture_output=True, text=True
            )
            
            if process.returncode == 0:
                output = process.stdout.strip()
                print(f"DEBUG: Broader PowerShell USB check: {output}")
                
                # Check if our known correct serial is in the output
                if CORRECT_SERIAL in output:
                    print(f"DEBUG: Found matching known serial in broader check: {CORRECT_SERIAL}")
                    self._is_authenticated = True
                    self._was_authenticated_once = True
                    self._usb_serial = CORRECT_SERIAL
                    return True
        except Exception as e:
            print(f"DEBUG: Error in broader PowerShell check: {e}")
        
        # Try using wmic directly as another fallback
        try:
            process = subprocess.run(
                ["wmic", "diskdrive", "get", "SerialNumber"],
                capture_output=True, text=True
            )
            
            if process.returncode == 0:
                output = process.stdout.strip()
                print(f"DEBUG: WMIC diskdrive check: {output}")
                
                # Check if our known correct serial is in the output
                if CORRECT_SERIAL in output:
                    print(f"DEBUG: Found matching known serial in WMIC check: {CORRECT_SERIAL}")
                    self._is_authenticated = True
                    self._was_authenticated_once = True
                    self._usb_serial = CORRECT_SERIAL
                    return True
        except Exception as e:
            print(f"DEBUG: Error in WMIC check: {e}")
        
        # Read the authorized serial from .env file if available
        authorized_serial = None
        try:
            authorized_serial = os.getenv('USB_KEY_SERIAL')
            if authorized_serial:
                print(f"DEBUG: Found authorized serial from .env: {authorized_serial}")
                
                # If the authorized serial is our known correct serial, and we've been authenticated once,
                # we can consider it authenticated even without physical check if not forced
                if authorized_serial == CORRECT_SERIAL and not force_check and hasattr(self, '_was_authenticated_once') and self._was_authenticated_once:
                    print(f"DEBUG: Using authorized serial from .env without physical check: {authorized_serial}")
                    self._is_authenticated = True
                    return True
        except Exception as e:
            print(f"DEBUG: Error reading authorized serial from .env: {e}")
        
        # For forcing a physical check for USB drives
        usb_drives = self._get_usb_drives_with_serials()
        print(f"DEBUG: Found {len(usb_drives)} USB drives during authentication check")
        
        # Check for the known correct serial in any of our drives
        for drive_path, serial in usb_drives:
            if serial == CORRECT_SERIAL:
                print(f"DEBUG: Found drive with correct serial {CORRECT_SERIAL}")
                self._is_authenticated = True
                self._drive_path = drive_path
                self._was_authenticated_once = True
                self._usb_serial = CORRECT_SERIAL
                return True
        
        # Look specifically for our authorized serial number if different from known correct
        if authorized_serial and authorized_serial != CORRECT_SERIAL:
            for drive_path, serial in usb_drives:
                if serial == authorized_serial:
                    print(f"DEBUG: Found matching authorized serial from .env: {authorized_serial}")
                    self._is_authenticated = True
                    self._drive_path = drive_path
                    self._was_authenticated_once = True
                    # Update our stored serial if it doesn't match
                    if not hasattr(self, '_usb_serial') or self._usb_serial != authorized_serial:
                        self._usb_serial = authorized_serial
                    return True
        
        # If no drives found but we have a stored serial, we might still authenticate
        # if the application was previously authenticated in this session
        if not usb_drives and hasattr(self, '_usb_serial') and self._usb_serial:
            print(f"DEBUG: No USB drives found but have stored serial: {self._usb_serial}")
            # Check if we've been authenticated before in this session
            if not force_check and hasattr(self, '_was_authenticated_once') and self._was_authenticated_once:
                print("DEBUG: Using previously authenticated session")
                self._is_authenticated = True
                return True
        
        # Check each drive against our stored key info
        for drive_path, serial in usb_drives:
            print(f"DEBUG: Checking drive {drive_path} with serial {serial}")
            # If we find a matching serial number
            if hasattr(self, '_usb_serial') and self._usb_serial == serial:
                print(f"DEBUG: Found matching serial: {serial}")
                self._is_authenticated = True
                self._drive_path = drive_path
                self._was_authenticated_once = True
                return True
        
        # If we get here and have drives but no match found
        if usb_drives:
            # Try the check_specific_drive method on each drive as a fallback
            for drive_path, _ in usb_drives:
                if self.check_specific_drive(drive_path):
                    print(f"DEBUG: Authenticated via check_specific_drive: {drive_path}")
                    self._is_authenticated = True
                    self._drive_path = drive_path
                    self._was_authenticated_once = True
                    return True
            
            self._last_error = "USB security key not found among connected drives"
        else:
            self._last_error = "No USB drives detected"
        
        self._is_authenticated = False
        return False
    
    def check_specific_drive(self, drive_path: str) -> bool:
        """Check if hardware key exists on a specific drive"""
        if not self._initialized and self._usb_serial:
            # If using serial-based authentication, just check the serial
            try:
                usb_drives = self._get_usb_drives_with_serials()
                for path, serial in usb_drives:
                    if drive_path == path and serial == self._usb_serial:
                        self._is_authenticated = True
                        self._drive_path = drive_path
                        return True
            except Exception as e:
                self._last_error = f"Error checking USB serial: {str(e)}"
                return False
                
            self._last_error = "USB serial number doesn't match"
            return False
            
        # Traditional file-based authentication
        self._is_authenticated = False
        self._key_id = None
        self._drive_path = None
        self._last_error = None
        
        try:
            if not os.path.exists(drive_path):
                self._last_error = f"Drive {drive_path} not found"
                return False
                
            key_path = os.path.join(drive_path, self.KEY_FILENAME)
            if not os.path.exists(key_path):
                self._last_error = f"Security key file not found on {drive_path}"
                return False
                
            try:
                with open(key_path, 'r') as f:
                    key_data = json.load(f)
                    if self._validate_key(key_data):
                        self._is_authenticated = True
                        self._key_id = key_data.get("id")
                        self._drive_path = drive_path
                        return True
                    else:
                        self._last_error = f"Invalid security key on {drive_path}"
                        return False
            except Exception as e:
                self._last_error = f"Error reading key file on {drive_path}: {str(e)}"
                return False
                
        except Exception as e:
            self._last_error = f"Error checking drive {drive_path}: {str(e)}"
            return False
    
    def get_drive_path(self) -> Optional[str]:
        """Get the path of the authenticated drive"""
        return self._drive_path
    
    def get_key_id(self) -> Optional[str]:
        """Get the ID of the authenticated key"""
        return self._key_id
    
    def get_last_error(self) -> Optional[str]:
        """Get the last error message"""
        return self._last_error
    
    def get_usb_serial(self) -> Optional[str]:
        """Get the USB serial number being used for authentication"""
        return self._usb_serial
    
    def _get_usb_drives_with_serials(self) -> List[tuple]:
        """Get a list of USB drives with their serial numbers
        
        Returns:
            List of tuples (drive_path, serial_number)
        """
        drives_with_serials = []
        
        # Get the correct serial from environment or key store
        CORRECT_SERIAL = ""
        
        # Try to get the serial from .env first
        try:
            from dotenv import load_dotenv
            load_dotenv()
            env_serial = os.getenv('USB_KEY_SERIAL')
            if env_serial:
                CORRECT_SERIAL = env_serial
                print(f"DEBUG: Loaded USB serial from .env: {CORRECT_SERIAL}")
        except Exception as e:
            print(f"DEBUG: Error loading from .env, using fallback methods: {e}")
        
        # If no serial from env, try from key store
        if not CORRECT_SERIAL and hasattr(self, '_usb_serial') and self._usb_serial:
            CORRECT_SERIAL = self._usb_serial
            print(f"DEBUG: Using USB serial from instance: {CORRECT_SERIAL}")
        
        # Check if we have a valid serial number
        if not CORRECT_SERIAL:
            print("DEBUG: No USB key serial number configured")
            return []
        
        # Get actual serials from connected drives
        actual_serials = []
        
        if platform.system() == "Windows":
            try:
                import subprocess
                
                # Use PowerShell to get all USB drive serials directly
                ps_command = 'Get-WmiObject Win32_DiskDrive | Where-Object {$_.InterfaceType -eq "USB"} | Select-Object SerialNumber'
                process = subprocess.run(
                    ["powershell", "-Command", ps_command],
                    capture_output=True, text=True
                )
                
                if process.returncode == 0:
                    output = process.stdout.strip()
                    print(f"DEBUG: PowerShell USB serials: {output}")
                    
                    # Extract all serials
                    lines = output.split('\n')
                    for line in lines:
                        line = line.strip()
                        if line and line != "SerialNumber" and not line.startswith('-'):
                            actual_serials.append(line)
                
                # Fallback to WMIC if needed
                if not actual_serials:
                    process = subprocess.run(
                        ["wmic", "diskdrive", "get", "SerialNumber"],
                        capture_output=True, text=True
                    )
                    
                    if process.returncode == 0:
                        output = process.stdout.strip()
                        print(f"DEBUG: WMIC serials: {output}")
                        
                        lines = process.stdout.strip().split('\n')
                        for line in lines[1:]:  # Skip header
                            line = line.strip()
                            if line and not line.isspace() and line != "NULL":
                                actual_serials.append(line)
            except Exception as e:
                print(f"DEBUG: Error getting actual serials: {e}")
        
        # Check if our correct serial is among the connected drives
        if CORRECT_SERIAL not in actual_serials:
            print(f"DEBUG: No USB drive with correct serial {CORRECT_SERIAL} found")
            print(f"DEBUG: Connected drives: {actual_serials}")
            return []
        
        # Now we know the correct drive is connected, get the drive letters
        if platform.system() == "Windows":
            try:
                import subprocess
                import string
                from ctypes import windll
                
                # First, identify the removable drives
                drives = []
                bitmask = windll.kernel32.GetLogicalDrives()
                for letter in string.ascii_uppercase:
                    if bitmask & 1:
                        drive_path = f"{letter}:\\"
                        try:
                            drive_type = windll.kernel32.GetDriveTypeW(drive_path)
                            # 2 is removable drive (usually USB flash drives)
                            if drive_type == 2:
                                drives.append(drive_path)
                        except Exception as e:
                            print(f"Error checking drive {drive_path}: {e}")
                    bitmask >>= 1
                
                # If no drives found, return empty list
                if not drives:
                    print("DEBUG: No removable drives found")
                    return []
                
                # We've verified the correct serial is connected, so assign to all removable drives
                for drive in drives:
                    drives_with_serials.append((drive, CORRECT_SERIAL))
                
                return drives_with_serials
                
            except Exception as e:
                print(f"Error enumerating USB drives: {e}")
                self._last_error = f"Windows USB enumeration error: {str(e)}"
        
        # Platform-specific code for macOS and Linux can go here...
        
        return drives_with_serials
    
    def _get_driver_key(self, drive_path: str) -> Optional[str]:
        """Get unique driver key identifier from a drive"""
        try:
            if platform.system() == "Windows":
                try:
                    import win32api  # type: ignore
                    import win32file  # type: ignore
                    
                    # Get volume information
                    volume_name, volume_serial, max_component_length, fs_flags, fs_name = win32api.GetVolumeInformation(drive_path)
                    
                    # Get device number for extra security
                    device_number = None
                    try:
                        handle = win32file.CreateFile(
                            drive_path,
                            win32file.GENERIC_READ,
                            win32file.FILE_SHARE_READ | win32file.FILE_SHARE_WRITE,
                            None,
                            win32file.OPEN_EXISTING,
                            0,
                            None
                        )
                        if handle and handle.handle != -1:
                            device_number = win32file.DeviceIoControl(
                                handle,
                                0x2D1080, # IOCTL_STORAGE_GET_DEVICE_NUMBER
                                None,
                                32
                            )
                            win32file.CloseHandle(handle)
                    except Exception:
                        pass
                        
                    # Combine all identifiers into a unique driver key
                    driver_key = f"{volume_name}:{volume_serial}:{fs_name}"
                    if device_number:
                        driver_key += f":{device_number}"
                        
                    return hashlib.sha256(driver_key.encode()).hexdigest()
                except ImportError:
                    self._last_error = "Windows API modules not available. Install pywin32 package."
                    return None
                except Exception as e:
                    self._last_error = f"Error getting driver key: {str(e)}"
                    return None
            else:
                # Fallback for other systems - create a hash based on available info
                if os.path.exists(drive_path):
                    stat_info = os.stat(drive_path)
                    info_str = f"{drive_path}:{stat_info.st_dev}:{stat_info.st_ino}"
                    return hashlib.sha256(info_str.encode()).hexdigest()
                    
            return None
        except Exception as e:
            self._last_error = f"Error getting driver key: {str(e)}"
            return None
            
    def _validate_key(self, key_data: Dict) -> bool:
        """Validate the key file data"""
        required_fields = ["id", "created", "hash", "signature", "driver_key"]
        for field in required_fields:
            if field not in key_data:
                self._last_error = f"Invalid key format: missing {field}"
                return False
                
        # Verify driver key if drive path is available
        if self._drive_path:
            current_driver_key = self._get_driver_key(self._drive_path)
            stored_driver_key = key_data.get("driver_key")
            
            if not current_driver_key or current_driver_key != stored_driver_key:
                self._last_error = "USB drive mismatch: This is not the authorized security key"
                return False
                
        # Add additional validation logic here
        # For example, check signature, expiration, etc.
        return True

    def _load_key_store(self):
        """Load security key information from the key store file"""
        key_store_path = "usb_key_store.json"
        
        if not os.path.exists(key_store_path):
            raise FileNotFoundError(f"Key store file not found: {key_store_path}")
        
        try:
            with open(key_store_path, 'r') as f:
                key_data = json.load(f)
                
            # Set the key properties from the stored data
            self._usb_serial = key_data.get("usb_serial")
            self._key_id = key_data.get("key_id")
            self._initialized = True
            
            # For manual entry keys, set authenticated directly
            if key_data.get("manual_entry", False):
                self._is_authenticated = True
                self._was_authenticated_once = True
                
            return key_data
        except Exception as e:
            print(f"DEBUG: Error loading key store: {e}")
            raise

class DeploymentProtection:
    """Protects deployments with additional security measures"""
    
    def __init__(self):
        self.last_deployment_time = None
        self.deployment_count = 0
        self._secret_key = os.environ.get("DEPLOYMENT_SECRET", "default-secret-key")
    
    def transform_request(self, data: Dict) -> tuple:
        """Transform deployment request with additional security headers"""
        timestamp = datetime.datetime.now().isoformat()
        request_id = str(uuid.uuid4())
        
        # Add security metadata
        data["metadata"] = {
            "security": {
                "timestamp": timestamp,
                "request_id": request_id
            }
        }
        
        # Calculate signature
        signature = self._sign_request(data, timestamp, request_id)
        
        # Custom headers for verification
        headers = {
            "X-Netlify-Secure-Deploy": "true",
            "X-Request-Timestamp": timestamp,
            "X-Request-ID": request_id,
            "X-Request-Signature": signature
        }
        
        return data, headers
    
    def _sign_request(self, data: Dict, timestamp: str, request_id: str) -> str:
        """Sign the request data with HMAC"""
        message = f"{timestamp}:{request_id}:{json.dumps(data, sort_keys=True)}"
        signature = hmac.new(
            self._secret_key.encode(),
            message.encode(),
            hashlib.sha256
        ).hexdigest()
        return signature

class Fingerprinter:
    """Adds security fingerprints to deployments"""
    
    def __init__(self):
        self.machine_id = self._get_machine_id()
    
    def add_fingerprint_to_deployment(self, data: Dict) -> Dict:
        """Add security fingerprint to deployment data"""
        # Add a deployment ID if not present
        if "id" not in data:
            data["id"] = str(uuid.uuid4())
            
        # Add fingerprinting data
        if "metadata" not in data:
            data["metadata"] = {}
            
        data["metadata"]["fingerprint"] = {
            "machine_id": self.machine_id,
            "timestamp": datetime.datetime.now().isoformat(),
            "platform": platform.platform(),
            "node": platform.node()
        }
        
        return data
    
    def _get_machine_id(self) -> str:
        """Get a unique identifier for the current machine"""
        # Generate a machine ID based on hardware info
        system_info = platform.system() + platform.machine() + platform.node()
        return hashlib.sha256(system_info.encode()).hexdigest()

class LegalManager:
    """Manages legal requirements like Terms of Service"""
    
    def __init__(self):
        self.tos_file = "terms_of_service.txt"
        self.tos_accepted_file = "tos_accepted.json"
        self._ensure_files_exist()
    
    def _ensure_files_exist(self):
        """Ensure necessary files exist"""
        if not os.path.exists(self.tos_file):
            with open(self.tos_file, 'w') as f:
                f.write(DEFAULT_TOS)
                
        if not os.path.exists(self.tos_accepted_file):
            with open(self.tos_accepted_file, 'w') as f:
                json.dump({}, f)
    
    def get_tos_text(self) -> str:
        """Get the current Terms of Service text"""
        try:
            with open(self.tos_file, 'r') as f:
                return f.read()
        except Exception:
            return DEFAULT_TOS
    
    def accept_tos(self, user: str) -> None:
        """Record user's acceptance of Terms of Service"""
        try:
            with open(self.tos_accepted_file, 'r') as f:
                accepted = json.load(f)
        except Exception:
            accepted = {}
            
        accepted[user] = {
            "timestamp": datetime.datetime.now().isoformat(),
            "version": "1.0"
        }
        
        try:
            with open(self.tos_accepted_file, 'w') as f:
                json.dump(accepted, f)
        except Exception:
            pass
    
    def has_accepted_tos(self, user: str) -> bool:
        """Check if user has accepted Terms of Service"""
        try:
            with open(self.tos_accepted_file, 'r') as f:
                accepted = json.load(f)
                return user in accepted
        except Exception:
            return False

class SecurityManager:
    """Main security manager class"""
    
    def __init__(self):
        self.hardware_auth = HardwareAuth()
        self.deployment_protocol = DeploymentProtection()
        self.fingerprinter = Fingerprinter()
        self.legal = LegalManager()
    
    def is_admin_authenticated(self):
        """Check if admin is authenticated via hardware key"""
        # Always force a fresh check to ensure we have the correct USB key
        return self.hardware_auth.is_authenticated(True)
    
    def reset_admin_authentication(self):
        """Reset the authentication state to force a fresh check"""
        if hasattr(self.hardware_auth, '_is_authenticated'):
            self.hardware_auth._is_authenticated = False
            self.hardware_auth._key_id = None
            self.hardware_auth._drive_path = None
    
    def is_hardware_key_initialized(self):
        """Check if the hardware key has been initialized"""
        return self.hardware_auth.is_initialized()
        
    def initialize_hardware_key(self, drive_path: str) -> Optional[str]:
        """Initialize a hardware key on the specified drive"""
        if not os.path.exists(drive_path):
            return None
            
        # Get USB serial number from the drive
        usb_serials = self.hardware_auth._get_usb_drives_with_serials()
        
        # Debug: Print all found USB drives and their serials
        print(f"DEBUG: Found USB drives with serials: {usb_serials}")
        
        matching_serial = None
        actual_serials = []
        
        # Normalize drive paths for comparison to handle different formats
        normalized_drive_path = drive_path.rstrip('\\').rstrip('/').upper()
        
        # Get all actual serials from connected drives for verification
        try:
            import subprocess
            import platform
            
            if platform.system() == "Windows":
                # Get all USB drive serials
                ps_command = 'Get-WmiObject Win32_DiskDrive | Where-Object {$_.InterfaceType -eq "USB"} | Select-Object SerialNumber'
                process = subprocess.run(
                    ["powershell", "-Command", ps_command],
                    capture_output=True, text=True
                )
                
                if process.returncode == 0:
                    output = process.stdout.strip()
                    
                    # Extract serial numbers (skip header line)
                    lines = output.split('\n')
                    for line in lines:
                        line = line.strip()
                        if line and line != "SerialNumber" and not line.startswith('-'):
                            actual_serials.append(line)
                
                # Fallback to WMIC if needed
                if not actual_serials:
                    process = subprocess.run(
                        ["wmic", "diskdrive", "get", "SerialNumber"],
                        capture_output=True, text=True
                    )
                    
                    if process.returncode == 0:
                        output = process.stdout.strip()
                        lines = output.split('\n')
                        for line in lines[1:]:  # Skip header
                            line = line.strip()
                            if line and not line.isspace() and line != "NULL":
                                actual_serials.append(line)
        except Exception as e:
            print(f"DEBUG: Error getting actual serials: {e}")
            
        print(f"DEBUG: Actual serials from connected USB drives: {actual_serials}")
        
        # If we have stored serial, verify it matches a connected drive
        stored_serial = None
        try:
            from dotenv import load_dotenv
            load_dotenv()
            stored_serial = os.getenv('USB_KEY_SERIAL')
            
            if stored_serial and stored_serial in actual_serials:
                # We have a match! Use the stored serial
                matching_serial = stored_serial
                print(f"DEBUG: Found matching stored serial: {matching_serial}")
            elif stored_serial:
                # We have a stored serial but no connected drive matches
                print(f"WARNING: Stored serial {stored_serial} doesn't match any connected drive")
                print(f"Connected drives have serials: {actual_serials}")
                return None
        except Exception as e:
            print(f"DEBUG: Error checking stored serial: {e}")
        
        # If no stored serial matched, check for a match with our mapping
        if not matching_serial:
            for path, serial in usb_serials:
                # Normalize the path from the system for comparison
                norm_path = path.rstrip('\\').rstrip('/').upper()
                
                # Check if the drive path contains or is contained by the path we're looking for
                if norm_path == normalized_drive_path or normalized_drive_path.startswith(norm_path) or norm_path.startswith(normalized_drive_path):
                    # Only use if serial is in the actual serials list
                    if serial in actual_serials:
                        matching_serial = serial
                        print(f"DEBUG: Matched drive {drive_path} with serial {serial}")
                        break
        
        # If still no match but we have serials, pick the first one
        if not matching_serial and actual_serials:
            matching_serial = actual_serials[0]
            print(f"DEBUG: No exact drive match. Using first detected USB serial: {matching_serial}")
        
        # If still no serial, attempt direct extraction for the specified drive
        if not matching_serial and platform.system() == "Windows":
            try:
                import subprocess
                import string
                
                # Extract drive letter from path (e.g., get "C" from "C:\" or "C:")
                drive_letter = normalized_drive_path[0] if len(normalized_drive_path) >= 1 else None
                
                if drive_letter and drive_letter in string.ascii_uppercase:
                    # Run wmic command to get disk info with serial number
                    cmd = ["wmic", "diskdrive", "where", f"Caption like '%{drive_letter}:%'", "get", "SerialNumber"]
                    process = subprocess.run(cmd, capture_output=True, text=True)
                    
                    if process.returncode == 0 and process.stdout.strip():
                        lines = process.stdout.strip().split('\n')
                        if len(lines) >= 2:  # Must have at least header and one value
                            serial = lines[1].strip()
                            if serial and serial in actual_serials:
                                matching_serial = serial
                                print(f"DEBUG: Found serial using direct wmic query: {serial}")
                                
                    # If still no serial, try getting model+size as a unique identifier
                    if not matching_serial:
                        cmd = ["wmic", "diskdrive", "where", f"Caption like '%{drive_letter}:%'", "get", "Model,Size"]
                        process = subprocess.run(cmd, capture_output=True, text=True)
                        
                        if process.returncode == 0 and process.stdout.strip():
                            lines = process.stdout.strip().split('\n')
                            if len(lines) >= 2:
                                model_size = lines[1].strip()
                                if model_size:
                                    serial_hash = hashlib.sha256(model_size.encode()).hexdigest()
                                    # Only use this as a last resort
                                    matching_serial = serial_hash
                                    print(f"DEBUG: Created hash from model+size: {matching_serial}")
            except Exception as e:
                print(f"DEBUG: Error during direct serial extraction: {e}")
        
        if not matching_serial:
            print(f"DEBUG: Failed to extract serial number for drive: {drive_path}")
            return None
            
        # Generate a unique key ID based on the USB serial
        key_id = hashlib.sha256(matching_serial.encode()).hexdigest()
        
        # Save the serial number to the key store file
        key_store_path = "usb_key_store.json"
        key_data = {
            "usb_serial": matching_serial,
            "key_id": key_id,
            "created": datetime.datetime.now().isoformat(),
            "platform": platform.system(),
            "initialized_by": platform.node(),
            "drive_path": drive_path  # Save original drive path for reference
        }
        
        try:
            with open(key_store_path, 'w') as f:
                json.dump(key_data, f)
                
            # Update hardware auth state
            self.hardware_auth._usb_serial = matching_serial
            self.hardware_auth._initialized = True
            
            # Also update the .env file
            try:
                env_path = ".env"
                if os.path.exists(env_path):
                    # Read existing content
                    with open(env_path, 'r') as f:
                        env_content = f.read()
                    
                    # Update or add USB_KEY_SERIAL
                    if "USB_KEY_SERIAL=" in env_content:
                        lines = env_content.split('\n')
                        new_lines = []
                        for line in lines:
                            if line.startswith("USB_KEY_SERIAL="):
                                new_lines.append(f"USB_KEY_SERIAL={matching_serial}")
                            else:
                                new_lines.append(line)
                        new_content = '\n'.join(new_lines)
                    else:
                        new_content = f"{env_content}\nUSB_KEY_SERIAL={matching_serial}"
                    
                    # Write updated content
                    with open(env_path, 'w') as f:
                        f.write(new_content)
                else:
                    # Create new .env file
                    with open(env_path, 'w') as f:
                        f.write(f"USB_KEY_SERIAL={matching_serial}\n")
                
                print(f"DEBUG: Updated .env file with USB serial: {matching_serial}")
            except Exception as e:
                print(f"DEBUG: Error updating .env file: {e}")
            
            return key_id
        except Exception as e:
            print(f"DEBUG: Error saving key store: {e}")
            return None
    
    def process_file_content(self, file_path: str, content: str) -> str:
        """Process file content for deployment (add watermarks, etc.)"""
        # This is a placeholder for more complex processing
        # For now, we just add a simple comment
        if file_path.endswith(".html"):
            return self._add_html_comment(content)
        elif file_path.endswith(".css"):
            return self._add_css_comment(content)
        elif file_path.endswith(".js"):
            return self._add_js_comment(content)
        return content
    
    def _add_html_comment(self, content: str) -> str:
        """Add HTML comment with deployment info"""
        comment = f"<!-- Deployed via Netlify Deployer | {datetime.datetime.now().isoformat()} -->"
        if "</head>" in content:
            return content.replace("</head>", f"{comment}</head>")
        return f"{comment}\n{content}"
    
    def _add_css_comment(self, content: str) -> str:
        """Add CSS comment with deployment info"""
        comment = f"/* Deployed via Netlify Deployer | {datetime.datetime.now().isoformat()} */\n"
        return f"{comment}{content}"
    
    def _add_js_comment(self, content: str) -> str:
        """Add JavaScript comment with deployment info"""
        comment = f"// Deployed via Netlify Deployer | {datetime.datetime.now().isoformat()}\n"
        return f"{comment}{content}"

# Default Terms of Service text
DEFAULT_TOS = """Terms of Service for Netlify Deployer

1. Introduction
   This application allows you to deploy content to Netlify. By using this application, you agree to these terms.

2. Acceptable Use
   You agree to use this application only for lawful purposes and in accordance with these Terms of Service.

3. Security Key
   The USB security key generated by this application is for your use only. Keep it secure.

4. Limitation of Liability
   The application is provided "as is" without warranties of any kind.

5. Changes to Terms
   We reserve the right to modify these terms at any time.

6. Contact Us
   If you have any questions about these Terms, please contact us.
"""

# Initialize the global security manager instance
security_manager = SecurityManager()
