# Modern Professional Color Scheme
DESIGN = {
    'PRIMARY': {
        'MAIN': '#2b5797',     # Microsoft Blue
        'LIGHT': '#366cc0',
        'DARK': '#1e3d6b',
        'CONTRAST': '#ffffff'
    },
    'SECONDARY': {
        'MAIN': '#333333',     # Dark Gray for text
        'LIGHT': '#666666',    # Medium Gray for secondary text
        'DARK': '#1a1a1a',     # Nearly Black for headings
        'CONTRAST': '#ffffff'
    },
    'SURFACE': {
        'MAIN': '#f5f5f5',     # Light Gray Background
        'CARD': '#ffffff',
        'HOVER': '#e8e8e8',
        'BORDER': '#d1d1d1'
    },
    'TAB': {
        'ACTIVE': '#ffffff',
        'INACTIVE': '#f0f0f0',
        'HOVER': '#f8f8f8',
        'BORDER': '#d1d1d1',
        'TEXT': '#333333'
    },
    'ACCENT': {
        'SUCCESS': '#107C10',   # Microsoft Green
        'ERROR': '#C42B1C',    # Microsoft Red
        'WARNING': '#D68B00',  # Microsoft Orange
        'INFO': '#0078D4'      # Microsoft Azure Blue
    },
    'FONT': {
        'FAMILY': '"Segoe UI", "SF Pro Display", system-ui, -apple-system, BlinkMacSystemFont, Roboto, Arial, sans-serif',
        'SIZE': {
            'XS': '11px',
            'SM': '13px',
            'BASE': '14px',
            'LG': '16px',
            'XL': '20px',
            'XXL': '24px'
        },
        'WEIGHT': {
            'REGULAR': '400',
            'MEDIUM': '500',
            'SEMIBOLD': '600',
            'BOLD': '700'
        }
    },
    'SPACING': {
        'XS': '4px',
        'SM': '8px',
        'BASE': '16px',
        'LG': '24px',
        'XL': '32px',
        'XXL': '48px'
    },
    'BORDER_RADIUS': {
        'SM': '4px',
        'BASE': '6px',
        'MD': '8px',
        'LG': '12px',
        'XL': '16px'
    }
}

# Window Style
WINDOW_STYLE = f"""
    QMainWindow {{
        background-color: {DESIGN['SURFACE']['MAIN']};
    }}
"""

# Modern Tab Style
TAB_STYLE = f"""
    QTabWidget {{
        background-color: {DESIGN['SURFACE']['CARD']};
        border: none;
    }}
    QTabWidget::pane {{
        border: none;
        background: {DESIGN['SURFACE']['CARD']};
        padding: 20px 15px;
    }}
    QTabBar::tab {{
        background: {DESIGN['TAB']['INACTIVE']};
        color: {DESIGN['SECONDARY']['MAIN']};
        padding: 12px 25px;
        margin-right: 2px;
        border-top-left-radius: 4px;
        border-top-right-radius: 4px;
        border: 1px solid {DESIGN['TAB']['BORDER']};
        border-bottom: none;
        font-family: {DESIGN['FONT']['FAMILY']};
        font-size: {DESIGN['FONT']['SIZE']['BASE']};
        font-weight: {DESIGN['FONT']['WEIGHT']['MEDIUM']};
    }}
    QTabBar::tab:hover {{
        background: {DESIGN['TAB']['HOVER']};
        color: {DESIGN['PRIMARY']['MAIN']};
    }}
    QTabBar::tab:selected {{
        background: {DESIGN['SURFACE']['CARD']};
        color: {DESIGN['PRIMARY']['MAIN']};
        font-weight: {DESIGN['FONT']['WEIGHT']['SEMIBOLD']};
        border-bottom: none;
        margin-bottom: -1px;
    }}
    QTabBar::tab:disabled {{
        color: {DESIGN['SECONDARY']['LIGHT']};
        background: {DESIGN['SURFACE']['HOVER']};
    }}
"""

# Card Style
CARD_STYLE = f"""
    QFrame.Card {{
        background-color: {DESIGN['SURFACE']['CARD']};
        border: 1px solid {DESIGN['SURFACE']['BORDER']};
        border-radius: {DESIGN['BORDER_RADIUS']['MD']};
    }}
    QFrame.Card:hover {{
        border-color: {DESIGN['PRIMARY']['MAIN']};
    }}
"""

# Glassmorphism Card Style
GLASS_CARD_STYLE = """
QFrame.Card {
    background: rgba(40, 44, 52, 0.65);
    border: 1.5px solid rgba(80, 120, 255, 0.18);
    border-radius: 18px;
    box-shadow: 0 8px 32px 0 rgba(31, 38, 135, 0.18);
}
QFrame.Card:hover {
    border: 1.5px solid #3794ff;
    box-shadow: 0 12px 40px 0 rgba(55, 148, 255, 0.18);
}
"""

# Glassmorphism Dialog Style
GLASS_DIALOG_STYLE = """
QDialog {
    background: rgba(40, 44, 52, 0.85);
    border-radius: 18px;
    border: 1.5px solid rgba(80, 120, 255, 0.18);
    color: #d4d4d4;
    font-family: 'Fira Code', 'JetBrains Mono', 'Consolas', monospace;
}
"""

# Input Style
INPUT_STYLE = f"""
    QLineEdit {{
        background-color: {DESIGN['SURFACE']['MAIN']};
        border: 1px solid {DESIGN['SURFACE']['BORDER']};
        border-radius: {DESIGN['BORDER_RADIUS']['BASE']};
        padding: {DESIGN['SPACING']['SM']} {DESIGN['SPACING']['BASE']};
        font-family: {DESIGN['FONT']['FAMILY']};
        font-size: {DESIGN['FONT']['SIZE']['BASE']};
        color: {DESIGN['SECONDARY']['MAIN']};
        selection-background-color: {DESIGN['PRIMARY']['LIGHT']};
        selection-color: {DESIGN['PRIMARY']['CONTRAST']};
    }}
    QLineEdit:focus {{
        border: 2px solid {DESIGN['PRIMARY']['MAIN']};
        background-color: {DESIGN['SURFACE']['MAIN']};
    }}
    QLineEdit:hover:!focus {{
        background-color: {DESIGN['SURFACE']['HOVER']};
    }}
    QLineEdit:disabled {{
        background-color: {DESIGN['SURFACE']['HOVER']};
        color: {DESIGN['SECONDARY']['LIGHT']};
    }}
"""

# Button Style
BUTTON_STYLE = f"""
    QPushButton {{
        background-color: {DESIGN['PRIMARY']['MAIN']};
        color: {DESIGN['PRIMARY']['CONTRAST']};
        border: none;
        border-radius: {DESIGN['BORDER_RADIUS']['BASE']};
        padding: {DESIGN['SPACING']['SM']} {DESIGN['SPACING']['LG']};
        font-family: {DESIGN['FONT']['FAMILY']};
        font-size: {DESIGN['FONT']['SIZE']['BASE']};
        font-weight: {DESIGN['FONT']['WEIGHT']['MEDIUM']};
        min-height: 36px;
        outline: none;
    }}
    QPushButton:hover {{
        background-color: {DESIGN['PRIMARY']['LIGHT']};
    }}
    QPushButton:pressed {{
        background-color: {DESIGN['PRIMARY']['DARK']};
    }}
    QPushButton:disabled {{
        background-color: {DESIGN['SURFACE']['BORDER']};
        color: {DESIGN['SECONDARY']['LIGHT']};
    }}
"""

# Animated Sidebar Button Style
SIDEBAR_BUTTON_STYLE = """
QPushButton {
    background: transparent;
    border: none;
    color: #b8b8b8;
    border-radius: 12px;
    margin: 4px 0;
}
QPushButton:hover {
    background: rgba(55, 148, 255, 0.12);
    color: #3794ff;
}
QPushButton:checked {
    background: #23272e;
    color: #3794ff;
    border: 1.5px solid #3794ff;
}
"""

# Modern Spinner Style
SPINNER_STYLE = """
QLabel#Spinner {
    min-width: 32px;
    min-height: 32px;
    max-width: 32px;
    max-height: 32px;
    border-radius: 16px;
    background: transparent;
}
"""

# Title Style
TITLE_STYLE = f"""
    QLabel {{
        color: {DESIGN['SECONDARY']['DARK']};
        font-family: {DESIGN['FONT']['FAMILY']};
        font-size: {DESIGN['FONT']['SIZE']['XXL']};
        font-weight: {DESIGN['FONT']['WEIGHT']['SEMIBOLD']};
        padding: {DESIGN['SPACING']['BASE']} 0;
    }}
"""

# Label Style
LABEL_STYLE = f"""
    QLabel {{
        color: {DESIGN['SECONDARY']['DARK']};
        font-family: {DESIGN['FONT']['FAMILY']};
        font-size: {DESIGN['FONT']['SIZE']['BASE']};
        font-weight: {DESIGN['FONT']['WEIGHT']['MEDIUM']};
        padding-bottom: {DESIGN['SPACING']['XS']};
        padding-left: {DESIGN['SPACING']['XS']};
    }}
"""

# Form Label Style
FORM_LABEL_STYLE = f"""
    QLabel {{
        color: {DESIGN['SECONDARY']['DARK']};
        font-family: {DESIGN['FONT']['FAMILY']};
        font-size: {DESIGN['FONT']['SIZE']['BASE']};
        font-weight: {DESIGN['FONT']['WEIGHT']['SEMIBOLD']};
        qproperty-alignment: 'AlignVCenter | AlignRight';
    }}
"""

# Section Title Style
SECTION_TITLE_STYLE = f"""
    QLabel {{
        color: {DESIGN['SECONDARY']['MAIN']};
        font-family: {DESIGN['FONT']['FAMILY']};
        font-size: {DESIGN['FONT']['SIZE']['XL']};
        font-weight: {DESIGN['FONT']['WEIGHT']['SEMIBOLD']};
        padding: {DESIGN['SPACING']['BASE']} 0 {DESIGN['SPACING']['SM']};
    }}
"""

# Combobox Style
COMBOBOX_STYLE = f"""
    QComboBox {{
        background-color: {DESIGN['SURFACE']['MAIN']};
        border: 1px solid {DESIGN['SURFACE']['BORDER']};
        border-radius: {DESIGN['BORDER_RADIUS']['BASE']};
        padding: {DESIGN['SPACING']['SM']} {DESIGN['SPACING']['BASE']};
        font-family: {DESIGN['FONT']['FAMILY']};
        font-size: {DESIGN['FONT']['SIZE']['BASE']};
        color: {DESIGN['SECONDARY']['MAIN']};
        min-height: 36px;
    }}
    QComboBox:hover {{
        background-color: {DESIGN['SURFACE']['HOVER']};
    }}
    QComboBox:focus {{
        border: 2px solid {DESIGN['PRIMARY']['MAIN']};
    }}
    QComboBox::drop-down {{
        border: none;
        width: 20px;
    }}
    QComboBox::down-arrow {{
        width: 12px;
        height: 12px;
        margin-right: 8px;
    }}
"""

# Checkbox Style
CHECKBOX_STYLE = f"""
    QCheckBox {{
        font-family: {DESIGN['FONT']['FAMILY']};
        font-size: {DESIGN['FONT']['SIZE']['BASE']};
        color: {DESIGN['SECONDARY']['MAIN']};
        spacing: 8px;
    }}
    QCheckBox::indicator {{
        width: 18px;
        height: 18px;
        border: 2px solid {DESIGN['SURFACE']['BORDER']};
        border-radius: 4px;
    }}
    QCheckBox::indicator:hover {{
        border-color: {DESIGN['PRIMARY']['MAIN']};
    }}
    QCheckBox::indicator:checked {{
        background-color: {DESIGN['PRIMARY']['MAIN']};
        border-color: {DESIGN['PRIMARY']['MAIN']};
    }}
"""

# Progress Bar Style
PROGRESS_STYLE = f"""
    QProgressBar {{
        border: none;
        border-radius: {DESIGN['BORDER_RADIUS']['BASE']};
        height: 10px;
        text-align: center;
    }}
    QProgressBar::chunk {{
        background-color: {DESIGN['PRIMARY']['MAIN']};
        border-radius: {DESIGN['BORDER_RADIUS']['BASE']};
    }}
"""

# Status Text Style
STATUS_STYLE = f"""
    QTextEdit {{
        background-color: {DESIGN['SURFACE']['CARD']};
        border: 1px solid {DESIGN['SURFACE']['BORDER']};
        border-radius: {DESIGN['BORDER_RADIUS']['MD']};
        padding: {DESIGN['SPACING']['BASE']};
        font-family: "SF Mono", "Cascadia Code", "Consolas", monospace;
        font-size: {DESIGN['FONT']['SIZE']['SM']};
        line-height: 1.5;
        color: {DESIGN['SECONDARY']['MAIN']};
    }}
"""

# Custom Scrollbar for Output Panel
OUTPUT_SCROLLBAR_STYLE = """
QScrollBar:vertical {
    background: #23272e;
    width: 10px;
    margin: 0px 0px 0px 0px;
    border-radius: 5px;
}
QScrollBar::handle:vertical {
    background: #3794ff;
    min-height: 20px;
    border-radius: 5px;
}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
    height: 0px;
}
QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {
    background: none;
}
"""

# Modern Syntax Highlighting for Output Panel
OUTPUT_SYNTAX_STYLE = """
QTextEdit {
    background: rgba(30, 34, 40, 0.95);
    color: #b8e1ff;
    border-radius: 10px;
    border: 1.5px solid #23272e;
    font-family: 'Fira Code', 'JetBrains Mono', 'Consolas', monospace;
    font-size: 14px;
    padding: 12px;
    selection-background-color: #3794ff;
    selection-color: #fff;
}
"""
