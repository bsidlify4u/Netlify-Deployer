"""
Unit tests for the A/B Testing module

This module contains tests for the A/B Testing functionality, including
test creation, metrics tracking, and test management operations.

Author: Development Team
Version: 1.0.1
"""

import os
import sys
import pytest
import tempfile
import json
import shutil
from unittest.mock import MagicMock, patch
from PyQt6.QtWidgets import QApplication

# Add parent directory to path for imports
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

# Import module to test
from ab_testing import ABTestingManager

# Fixtures
@pytest.fixture
def app():
    """
    Create a QApplication instance for tests
    
    Returns:
        QApplication: The application instance
    """
    app = QApplication.instance()
    if app is None:
        app = QApplication([])
    yield app
    # Don't call app.quit() as it might affect other tests

@pytest.fixture
def temp_dir():
    """
    Create a temporary directory for test files
    
    Returns:
        str: Path to the temporary directory
    """
    temp_dir = tempfile.mkdtemp()
    yield temp_dir
    # Clean up
    shutil.rmtree(temp_dir)

@pytest.fixture
def mock_main_window():
    """
    Create a mock main window object
    
    Returns:
        MagicMock: Mock main window with required attributes
    """
    main_window = MagicMock()
    main_window.log_text = MagicMock()
    return main_window

@pytest.fixture
def ab_manager(mock_main_window, temp_dir):
    """
    Create an ABTestingManager with a temporary test file
    
    Args:
        mock_main_window: Mock main window object
        temp_dir: Temporary directory path
        
    Returns:
        ABTestingManager: Configured manager instance for testing
    """
    manager = ABTestingManager(mock_main_window)
    # Set the tests_file attribute directly on the instance
    manager.tests_file = os.path.join(temp_dir, "ab_tests.json")
    # Initialize with empty tests
    manager.tests = []
    manager.save_tests()
    return manager

# Test data for reuse
@pytest.fixture
def test_data():
    """
    Standard test data for A/B test creation
    
    Returns:
        dict: Test configuration data
    """
    return {
        "name": "Test AB Test",
        "original_site": "https://example.com",
        "variant_dir": "./test/variant",
        "traffic_split": "50/50",
        "conversion_goal": "Test Conversion"
    }

# Tests
def test_add_test(ab_manager, test_data):
    """
    Test adding a new AB test
    
    Verifies that:
    - Test is added to the list
    - Test has correct properties
    - Test ID is returned
    """
    # Add test
    test_id = ab_manager.add_test(test_data)
    
    # Verify test was added
    assert len(ab_manager.tests) == 1
    assert ab_manager.tests[0]["name"] == "Test AB Test"
    assert ab_manager.tests[0]["status"] == "Active"
    assert "id" in ab_manager.tests[0]
    assert ab_manager.tests[0]["id"] == test_id

def test_update_test_status(ab_manager, test_data):
    """
    Test updating test status
    
    Verifies that:
    - Test status is updated
    - Status change timestamp is added
    """
    # Add a test
    test_id = ab_manager.add_test(test_data)
    
    # Update status
    ab_manager.update_test_status(test_id, "Paused")
    
    # Verify status was updated
    assert ab_manager.tests[0]["status"] == "Paused"
    assert "paused_date" in ab_manager.tests[0]

def test_delete_test(ab_manager, test_data):
    """
    Test deleting a test
    
    Verifies that:
    - Test is removed from the list
    - Function returns True for success
    """
    # Add a test
    test_id = ab_manager.add_test(test_data)
    
    # Delete test
    result = ab_manager.delete_test(test_id)
    
    # Verify test was deleted
    assert result is True
    assert len(ab_manager.tests) == 0

def test_record_metrics(ab_manager, test_data):
    """
    Test recording visitors and conversions
    
    Verifies that:
    - Visitor counts are recorded correctly
    - Conversion counts are recorded correctly
    - Conversion rates are calculated properly
    """
    # Add a test
    test_id = ab_manager.add_test(test_data)
    
    # Record visitors
    ab_manager.record_visitor(test_id, "a")
    ab_manager.record_visitor(test_id, "a")
    ab_manager.record_visitor(test_id, "b")
    
    # Record conversions
    ab_manager.record_conversion(test_id, "a")
    ab_manager.record_conversion(test_id, "b")
    
    # Get conversion rates
    rates = ab_manager.get_conversion_rates(test_id)
    
    # Verify metrics
    test = ab_manager.tests[0]
    assert test["metrics"]["a_visitors"] == 2
    assert test["metrics"]["b_visitors"] == 1
    assert test["metrics"]["a_conversions"] == 1
    assert test["metrics"]["b_conversions"] == 1
    
    # Verify conversion rates
    assert rates["a_rate"] == 50.0  # 1/2 * 100
    assert rates["b_rate"] == 100.0  # 1/1 * 100
    assert rates["improvement"] == 50.0  # b_rate - a_rate
    
    # Verify last_updated field
    assert "last_updated" in test

def test_invalid_test_id(ab_manager):
    """
    Test operations with invalid test ID
    
    Verifies that all operations gracefully handle invalid IDs:
    - Updating status returns False
    - Deleting returns False
    - Recording metrics returns False
    - Getting conversion rates returns None
    """
    # Try operations with invalid ID
    invalid_id = "non-existent-id"
    
    # Update status
    result_update = ab_manager.update_test_status(invalid_id, "Paused")
    assert result_update is False
    
    # Delete test
    result_delete = ab_manager.delete_test(invalid_id)
    assert result_delete is False
    
    # Record visitor
    result_visitor = ab_manager.record_visitor(invalid_id, "a")
    assert result_visitor is False
    
    # Record conversion
    result_conversion = ab_manager.record_conversion(invalid_id, "a")
    assert result_conversion is False
    
    # Get conversion rates
    rates = ab_manager.get_conversion_rates(invalid_id)
    assert rates is None

def test_zero_division_handling(ab_manager, test_data):
    """
    Test handling of zero division in conversion rate calculation
    
    Verifies that:
    - No exceptions are thrown with zero visitors
    - Conversion rates are calculated as 0.0 when no visitors
    """
    # Add a test
    test_id = ab_manager.add_test(test_data)
    
    # Record only conversions without visitors
    ab_manager.record_conversion(test_id, "a")
    
    # Get conversion rates
    rates = ab_manager.get_conversion_rates(test_id)
    
    # Verify no division by zero error occurred
    assert rates is not None
    assert rates["a_rate"] == 0.0 

if __name__ == "__main__":
    # Allow running tests directly without pytest
    pytest.main(["-v", __file__]) 