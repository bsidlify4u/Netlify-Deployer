"""
Terms of Service dialog for Netlify Deployer application.
"""

from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QTextEdit, QCheckBox, QHBoxLayout, QPushButton, QLabel
)
from PyQt6.QtCore import Qt

class TermsOfServiceDialog(QDialog):
    """Dialog for displaying and accepting Terms of Service"""
    
    def __init__(self, tos_text, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Terms of Service")
        self.setMinimumSize(600, 400)
        self.accepted_tos = False
        
        # Create layout
        layout = QVBoxLayout(self)
        
        # Add title
        title = QLabel("Terms of Service")
        title.setStyleSheet("font-size: 16px; font-weight: bold; color: #0078D4;")
        layout.addWidget(title)
        
        # Add explanation
        explanation = QLabel("Please read and accept the following Terms of Service to continue:")
        explanation.setWordWrap(True)
        layout.addWidget(explanation)
        
        # Add TOS text
        self.tos_edit = QTextEdit()
        self.tos_edit.setReadOnly(True)
        self.tos_edit.setPlainText(tos_text)
        self.tos_edit.setStyleSheet("""
            QTextEdit {
                background-color: #f5f5f5;
                border: 1px solid #ddd;
                padding: 10px;
                color: #333;
            }
        """)
        layout.addWidget(self.tos_edit)
        
        # Add checkbox for acceptance
        self.accept_checkbox = QCheckBox("I have read and agree to the Terms of Service")
        self.accept_checkbox.clicked.connect(self.update_accept_button)
        layout.addWidget(self.accept_checkbox)
        
        # Create button layout
        button_layout = QHBoxLayout()
        
        # Add cancel button
        self.cancel_button = QPushButton("Cancel")
        self.cancel_button.clicked.connect(self.reject)
        
        # Add accept button
        self.accept_button = QPushButton("I Accept")
        self.accept_button.clicked.connect(self.on_accept)
        self.accept_button.setEnabled(False)  # Initially disabled
        self.accept_button.setStyleSheet("""
            QPushButton {
                background-color: #0078D4;
                color: white;
                font-weight: bold;
                padding: 8px 20px;
                border: none;
                border-radius: 4px;
                min-width: 100px;
            }
            QPushButton:hover {
                background-color: #1084D9;
            }
            QPushButton:disabled {
                background-color: #cccccc;
                color: #666666;
            }
        """)
        
        # Add buttons to layout
        button_layout.addStretch()
        button_layout.addWidget(self.cancel_button)
        button_layout.addSpacing(10)
        button_layout.addWidget(self.accept_button)
        
        layout.addSpacing(20)
        layout.addLayout(button_layout)
        
        # Set dialog layout
        self.setLayout(layout)
        
    def update_accept_button(self, checked):
        """Update the accept button state based on checkbox"""
        self.accept_button.setEnabled(checked)
        
    def on_accept(self):
        """Handle the accept button click"""
        if self.accept_checkbox.isChecked():
            self.accepted_tos = True
            self.accept()
    
    def was_accepted(self):
        """Check if the terms of service were accepted"""
        return self.accepted_tos

# Standalone test function
def test_dialog():
    """Run a standalone test of the ToS dialog"""
    import sys
    from PyQt6.QtWidgets import QApplication
    
    app = QApplication(sys.argv)
    
    # Sample TOS text
    tos_text = """Terms of Service for Testing

This is a sample Terms of Service for testing the dialog.
1. This is point one
2. This is point two
3. This is point three

Thank you for reviewing these terms."""
    
    # Create and show dialog
    dialog = TermsOfServiceDialog(tos_text)
    result = dialog.exec()
    
    print(f"Dialog result code: {result}")
    print(f"Dialog accepted: {result == 1}")
    print(f"TOS was accepted: {dialog.was_accepted()}")
    
    return result

if __name__ == "__main__":
    test_dialog() 