"""
USB Authentication Handler

This module provides a reliable way to detect and authenticate USB security keys
with the correct serial number.
"""

import os
import platform
import subprocess
import json
import logging
from datetime import datetime
from typing import Optional, List, Tuple, Dict, Any

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("usb_auth")

class USBKeyAuth:
    """USB Security Key Authentication Handler"""
    
    def __init__(self):
        self.CORRECT_SERIAL = ""
        self._is_authenticated = False
        self._was_authenticated_once = False
        self._drive_path = None
        self._usb_serial = None
        self._key_store_path = "usb_key_store.json"
        self._virtual_key_path = ".virtual_key"
        self._env_file = ".env"
        self._last_error = None
        
        # Try to load the serial from environment
        self._load_from_env()
        
        # Try to load from key store
        self._load_from_key_store()

        # Make sure we have a valid serial number
        if not self.CORRECT_SERIAL:
            logger.warning("No USB serial number configured. Authentication will fail.")
    
    def _load_from_env(self) -> None:
        """Load USB serial from .env file"""
        try:
            # Try to use python-dotenv if available
            try:
                from dotenv import load_dotenv
                load_dotenv()
            except ImportError:
                logger.debug("python-dotenv not installed, using os.environ directly")
                
            # Check if environment variable exists
            env_serial = os.getenv('USB_KEY_SERIAL')
            if env_serial:
                self.CORRECT_SERIAL = env_serial
                logger.debug("Loaded USB serial from environment")
        except Exception as e:
            logger.error(f"Error loading from environment: {str(e)}")
            self._last_error = f"Error loading from environment: {str(e)}"
    
    def _load_from_key_store(self) -> None:
        """Load USB key information from key store"""
        try:
            if os.path.exists(self._key_store_path):
                with open(self._key_store_path, 'r') as f:
                    key_data = json.load(f)
                    if "usb_serial" in key_data and key_data["usb_serial"]:
                        self._usb_serial = key_data["usb_serial"]
                        # Only update CORRECT_SERIAL if we don't already have one from env
                        if not self.CORRECT_SERIAL:
                            self.CORRECT_SERIAL = self._usb_serial
                        logger.debug("Loaded USB serial from key store")
                    
                    # Load drive path if available
                    if "drive_path" in key_data and key_data["drive_path"]:
                        self._drive_path = key_data["drive_path"]
        except Exception as e:
            logger.error(f"Error loading from key store: {str(e)}")
            self._last_error = f"Error loading from key store: {str(e)}"
    
    def is_authenticated(self, force_check: bool = False) -> bool:
        """Check if the USB security key is authenticated
        
        Args:
            force_check: If True, perform a physical check even if already authenticated
            
        Returns:
            bool: True if authenticated, False otherwise
        """
        # Return cached result if not forced to check
        if self._is_authenticated and not force_check:
            return True
            
        # Always reset authentication status when doing a forced check
        if force_check:
            self._is_authenticated = False
            
        # Ensure we have a valid serial to check against
        if not self.CORRECT_SERIAL:
            self._last_error = "No USB key serial number configured. Cannot authenticate."
            logger.error(self._last_error)
            return False
            
        # Try multiple detection methods in sequence
        connected_serials = self._get_connected_usb_serials()
        
        # Log all detected serials for debugging
        logger.debug(f"Detected USB serials: {len(connected_serials)} device(s)")
        
        # Check if the correct serial is among the connected drives
        if self.CORRECT_SERIAL in connected_serials:
            logger.info("USB key authentication successful")
            self._is_authenticated = True
            self._was_authenticated_once = True
            
            # Find and set the drive path
            self._update_drive_path()
            
            # Update the virtual key file for future reference
            self._update_virtual_key()
            
            return True
            
        # If we get here, no matching USB drive was found
        self._last_error = "USB key authentication failed. Required key not found."
        logger.error(self._last_error)
        self._is_authenticated = False
        return False
    
    def _update_drive_path(self) -> None:
        """Update the drive path for the authenticated USB key"""
        # Implementation depends on the platform
        try:
            if platform.system() == "Windows":
                # Windows implementation to find drive letter
                ps_command = 'Get-WmiObject Win32_DiskDrive | Where-Object {$_.SerialNumber -eq "' + self.CORRECT_SERIAL + '"} | Get-WmiObject -Association Win32_DiskDriveToDiskPartition | Get-WmiObject -Association Win32_LogicalDiskToPartition | Select-Object DeviceID'
                process = subprocess.run(
                    ["powershell", "-Command", ps_command],
                    capture_output=True, text=True
                )
                
                if process.returncode == 0:
                    output = process.stdout.strip()
                    lines = output.split('\n')
                    for line in lines:
                        if line.startswith("DeviceID") or line.startswith("-"):
                            continue
                        drive_letter = line.strip()
                        if drive_letter:
                            self._drive_path = drive_letter
                            break
            
            # Store the updated drive path in the key store
            if self._drive_path:
                self._update_key_store_drive_path()
                
        except Exception as e:
            logger.error(f"Error updating drive path: {str(e)}")
    
    def _update_key_store_drive_path(self) -> None:
        """Update the drive path in the key store"""
        try:
            if os.path.exists(self._key_store_path):
                with open(self._key_store_path, 'r') as f:
                    key_data = json.load(f)
            else:
                key_data = {}
            
            key_data["drive_path"] = self._drive_path
            key_data["last_updated"] = self._get_timestamp()
            
            with open(self._key_store_path, 'w') as f:
                json.dump(key_data, f)
                
        except Exception as e:
            logger.error(f"Error updating key store drive path: {str(e)}")
    
    def _get_connected_usb_serials(self) -> List[str]:
        """Get serial numbers of all connected USB drives
        
        Returns:
            List of serial numbers
        """
        serials = []
        
        # Windows implementation
        if platform.system() == "Windows":
            # Direct PowerShell method - most reliable
            try:
                ps_command = 'Get-WmiObject Win32_DiskDrive | Where-Object {$_.InterfaceType -eq "USB"} | Select-Object SerialNumber'
                process = subprocess.run(
                    ["powershell", "-Command", ps_command],
                    capture_output=True, text=True
                )
                
                if process.returncode == 0:
                    output = process.stdout.strip()
                    logger.debug("PowerShell USB serials retrieved")
                    
                    # Extract serial numbers (skip header line)
                    lines = output.split('\n')
                    for line in lines:
                        line = line.strip()
                        if line and line != "SerialNumber" and not line.startswith('-'):
                            serials.append(line)
            except Exception as e:
                logger.error(f"Error in PowerShell serial check: {str(e)}")
            
            # Fallback to WMIC
            if not serials:
                try:
                    process = subprocess.run(
                        ["wmic", "diskdrive", "get", "SerialNumber"],
                        capture_output=True, text=True
                    )
                    
                    if process.returncode == 0:
                        output = process.stdout.strip()
                        logger.debug("WMIC diskdrive serials retrieved")
                        
                        # Extract serial numbers (skip header line)
                        lines = output.split('\n')
                        for line in lines[1:]:  # Skip header
                            line = line.strip()
                            if line and not line.isspace() and line != "NULL":
                                serials.append(line)
                except Exception as e:
                    logger.error(f"Error in WMIC check: {str(e)}")
        
        # macOS implementation 
        elif platform.system() == "Darwin":
            try:
                # Use diskutil to get disk info
                process = subprocess.run(
                    ["diskutil", "list", "-plist", "external"],
                    capture_output=True, text=True
                )
                
                if process.returncode == 0:
                    output = process.stdout.strip()
                    logger.debug("diskutil data retrieved")
                    
                    # Try to get disk identifiers
                    disk_ids = []
                    for line in output.split('\n'):
                        if "/dev/disk" in line:
                            disk_id = line.strip().split()[0]
                            disk_ids.append(disk_id)
                    
                    # For each disk, get info
                    for disk_id in disk_ids:
                        process = subprocess.run(
                            ["diskutil", "info", disk_id],
                            capture_output=True, text=True
                        )
                        
                        if process.returncode == 0:
                            info_output = process.stdout.strip()
                            # Look for serial number in output
                            for line in info_output.split('\n'):
                                if "Serial Number" in line:
                                    serial = line.split(':')[1].strip()
                                    if serial:
                                        serials.append(serial)
                
                # Try system_profiler as another option
                if not serials:
                    process = subprocess.run(
                        ["system_profiler", "SPUSBDataType"],
                        capture_output=True, text=True
                    )
                    
                    if process.returncode == 0:
                        output = process.stdout.strip()
                        # Parse the output for Serial Number
                        for line in output.split('\n'):
                            if "Serial Number" in line:
                                serial = line.split(':')[1].strip()
                                if serial:
                                    serials.append(serial)
            except Exception as e:
                logger.error(f"Error in macOS disk detection: {str(e)}")
        
        # Linux implementation
        elif platform.system() == "Linux":
            try:
                # Try lsblk to get removable drives
                process = subprocess.run(
                    ["lsblk", "-d", "-o", "NAME,SERIAL", "-n"],
                    capture_output=True, text=True
                )
                
                if process.returncode == 0:
                    output = process.stdout.strip()
                    logger.debug("lsblk data retrieved")
                    
                    # Extract serial numbers
                    for line in output.split('\n'):
                        parts = line.strip().split()
                        if len(parts) >= 2:
                            serial = parts[1].strip()
                            if serial and serial != "0":
                                serials.append(serial)
                
                # Try udevadm as another option
                if not serials:
                    # First get list of block devices
                    process = subprocess.run(
                        ["ls", "/sys/block/"],
                        capture_output=True, text=True
                    )
                    
                    if process.returncode == 0:
                        devices = process.stdout.strip().split()
                        
                        # For each device, get info
                        for device in devices:
                            if device.startswith(('sd', 'hd')):  # Only consider disk devices
                                process = subprocess.run(
                                    ["udevadm", "info", "-q", "property", f"/dev/{device}"],
                                    capture_output=True, text=True
                                )
                                
                                if process.returncode == 0:
                                    info_output = process.stdout.strip()
                                    
                                    # Check if removable
                                    is_removable = False
                                    for line in info_output.split('\n'):
                                        if "DEVTYPE=disk" in line and "ID_BUS=usb" in info_output:
                                            is_removable = True
                                            break
                                    
                                    # If removable, get serial
                                    if is_removable:
                                        for line in info_output.split('\n'):
                                            if "ID_SERIAL=" in line:
                                                serial = line.split('=')[1].strip()
                                                if serial:
                                                    serials.append(serial)
            except Exception as e:
                logger.error(f"Error in Linux disk detection: {str(e)}")
        
        return serials
    
    def _update_virtual_key(self) -> None:
        """Update the virtual key file with current authentication status"""
        try:
            virtual_key_content = f"""SERIAL={self.CORRECT_SERIAL}
INITIALIZED=true
LAST_AUTH={platform.node()}
TIMESTAMP={self._get_timestamp()}"""
            
            with open(self._virtual_key_path, "w") as f:
                f.write(virtual_key_content)
        except Exception as e:
            logger.error(f"Error updating virtual key file: {str(e)}")
            self._last_error = f"Error updating virtual key file: {str(e)}"
    
    def _get_timestamp(self) -> str:
        """Get current timestamp"""
        return datetime.now().isoformat()
    
    def save_auth_config(self) -> bool:
        """Save the authentication configuration to the key store"""
        key_data = {
            "usb_serial": self.CORRECT_SERIAL,
            "initialized": True,
            "platform": platform.system(),
            "node": platform.node(),
            "drive_path": self._drive_path,
            "last_updated": self._get_timestamp()
        }
        
        try:
            with open(self._key_store_path, 'w') as f:
                json.dump(key_data, f)
            logger.info("Saved authentication config to key store")
            
            # Also ensure the .env file exists
            if not os.path.exists(self._env_file):
                with open(self._env_file, 'w') as f:
                    f.write(f"USB_KEY_SERIAL={self.CORRECT_SERIAL}\n")
                logger.info("Created .env file with USB serial")
                
            return True
        except Exception as e:
            logger.error(f"Error saving auth config: {str(e)}")
            self._last_error = f"Error saving auth config: {str(e)}"
            return False
    
    def set_usb_serial(self, serial: str) -> bool:
        """Set a new USB key serial number
        
        Args:
            serial: The new serial number to use
            
        Returns:
            bool: True if successful, False otherwise
        """
        if not serial:
            self._last_error = "Cannot set empty serial number"
            return False
            
        self.CORRECT_SERIAL = serial
        self._usb_serial = serial
        return self.save_auth_config()
    
    def get_usb_serial(self) -> str:
        """Get the USB key serial number"""
        return self.CORRECT_SERIAL
    
    def get_drive_path(self) -> Optional[str]:
        """Get the drive path of the authenticated USB key"""
        return self._drive_path
    
    def reset_auth(self) -> None:
        """Reset authentication state"""
        self._is_authenticated = False
        self._last_error = None
    
    def get_last_error(self) -> Optional[str]:
        """Get the last error message"""
        return self._last_error

# Singleton instance
usb_key_auth = USBKeyAuth() 