"""
USB Authentication Integration

This module integrates the new USB authentication handler with the existing security features.
"""

import os
import platform
import logging

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("usb_auth_integration")

# Import our custom USB authentication handler
try:
    from usb_auth_handler import usb_key_auth
    HAVE_USB_AUTH = True
except ImportError:
    logger.error("Could not import usb_key_auth handler")
    HAVE_USB_AUTH = False

# Import the security manager but avoid circular imports
try:
    from security_features import security_manager
    HAVE_SECURITY_MANAGER = True
except ImportError:
    logger.error("Could not import security_manager")
    HAVE_SECURITY_MANAGER = False

def integrate_usb_auth():
    """Integrate our new USB authentication handler with the security manager"""
    if not HAVE_USB_AUTH:
        logger.error("USB auth handler not available, integration skipped")
        return False
    
    if not HAVE_SECURITY_MANAGER:
        logger.error("Security manager not available, integration skipped")
        return False
        
    # Replace the old is_authenticated method
    def new_is_authenticated(self, force_check=False):
        """Enhanced authentication that uses our new handler
        
        Args:
            force_check: If True, perform a fresh check instead of using cached results
            
        Returns:
            bool: True if authenticated, False otherwise
        """
        # Always use the new USB key auth handler with strict checking
        result = usb_key_auth.is_authenticated(force_check=force_check)
        
        # Copy over any error messages
        if hasattr(usb_key_auth, 'get_last_error') and callable(getattr(usb_key_auth, 'get_last_error')):
            last_error = usb_key_auth.get_last_error()
            if last_error and hasattr(self, '_last_error'):
                self._last_error = last_error
        
        return result
    
    # Apply the monkey patch if possible
    try:
        from types import MethodType
        if hasattr(security_manager, 'hardware_auth'):
            # Check to avoid applying twice
            original_method_name = getattr(security_manager.hardware_auth.is_authenticated, '__name__', None)
            if original_method_name != 'new_is_authenticated':
                security_manager.hardware_auth.is_authenticated = MethodType(new_is_authenticated, security_manager.hardware_auth)
                logger.info("Successfully integrated enhanced USB authentication")
                return True
            else:
                logger.info("USB authentication already integrated")
                return True
        else:
            logger.error("Security manager has no hardware_auth attribute")
            return False
    except Exception as e:
        logger.error(f"Error during USB authentication integration: {e}")
        return False

# Only apply the integration if explicitly requested
def apply_integration():
    """Apply the integration and return success status"""
    return integrate_usb_auth() 